-- All In One WP Security & Firewall 4.4.2
-- MySQL dump
-- 2019-12-31 16:53:29

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=602 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_aiowps_events` VALUES("1","404","","0","2019-12-17 19:25:09","127.0.0.1","http://dimtepla.com/","/wp-content/themes/dimtepla/js/navigation.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("2","404","","0","2019-12-17 19:25:09","127.0.0.1","http://dimtepla.com/","/wp-content/themes/dimtepla/js/skip-link-focus-fix.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("3","404","","0","2019-12-21 05:33:42","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("4","404","","0","2019-12-21 05:33:43","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("5","404","","0","2019-12-21 05:40:35","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("6","404","","0","2019-12-21 05:40:36","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("7","404","","0","2019-12-21 09:32:38","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("8","404","","0","2019-12-21 09:32:39","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("9","404","","0","2019-12-21 21:31:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("10","404","","0","2019-12-21 21:31:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("11","404","","0","2019-12-22 07:20:26","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=1dd6d730-d4b9-438b-863a-7f2fe9dc0fef&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("12","404","","0","2019-12-22 07:20:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("13","404","","0","2019-12-22 07:20:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("14","404","","0","2019-12-22 07:21:14","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=ea0ac923-8d8b-46ff-a8db-55bbf68b7538&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("15","404","","0","2019-12-22 07:21:15","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("16","404","","0","2019-12-22 07:21:15","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("17","404","","0","2019-12-22 07:50:28","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("18","404","","0","2019-12-22 07:50:28","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("19","404","","0","2019-12-22 23:56:41","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("20","404","","0","2019-12-22 23:56:41","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("21","404","","0","2019-12-22 23:56:47","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("22","404","","0","2019-12-22 23:56:47","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("23","404","","0","2019-12-22 23:57:01","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("24","404","","0","2019-12-22 23:57:01","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("25","404","","0","2019-12-23 00:42:58","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("26","404","","0","2019-12-23 00:42:58","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("27","404","","0","2019-12-23 01:16:35","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("28","404","","0","2019-12-23 01:16:35","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("29","404","","0","2019-12-23 01:51:07","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("30","404","","0","2019-12-23 01:51:07","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("31","404","","0","2019-12-23 03:45:54","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("32","404","","0","2019-12-23 03:45:54","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("33","404","","0","2019-12-23 03:59:35","127.0.0.1","http://dimtepla.com/","/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("34","404","","0","2019-12-23 03:59:36","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("35","404","","0","2019-12-23 03:59:36","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("36","404","","0","2019-12-23 04:02:02","127.0.0.1","http://dimtepla.com/","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("37","404","","0","2019-12-23 04:02:03","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("38","404","","0","2019-12-23 04:02:03","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("39","404","","0","2019-12-23 04:02:13","127.0.0.1","http://dimtepla.com/","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("40","404","","0","2019-12-23 04:02:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("41","404","","0","2019-12-23 04:02:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("42","404","","0","2019-12-23 04:02:27","127.0.0.1","http://dimtepla.com/","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("43","404","","0","2019-12-23 04:02:27","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("44","404","","0","2019-12-23 04:02:27","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("45","404","","0","2019-12-23 04:04:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("46","404","","0","2019-12-23 04:04:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("47","404","","0","2019-12-23 04:05:03","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("48","404","","0","2019-12-23 04:05:03","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("49","404","","0","2019-12-23 04:05:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("50","404","","0","2019-12-23 04:05:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("51","404","","0","2019-12-23 04:05:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/style.css?ver=40eaa2fd3bde164ecbb15047abd02d35","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("52","404","","0","2019-12-23 04:05:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("53","404","","0","2019-12-23 04:05:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("54","404","","0","2019-12-23 04:05:23","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("55","404","","0","2019-12-23 04:05:24","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("56","404","","0","2019-12-23 04:06:05","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("57","404","","0","2019-12-23 04:06:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("58","404","","0","2019-12-23 04:07:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("59","404","","0","2019-12-23 04:07:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("60","404","","0","2019-12-23 04:07:58","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("61","404","","0","2019-12-23 04:07:58","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("62","404","","0","2019-12-23 04:13:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("63","404","","0","2019-12-23 04:13:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("64","404","","0","2019-12-23 04:13:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("65","404","","0","2019-12-23 04:14:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("66","404","","0","2019-12-23 04:14:52","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("67","404","","0","2019-12-23 04:14:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("68","404","","0","2019-12-23 04:14:53","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("69","404","","0","2019-12-23 04:17:07","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("70","404","","0","2019-12-23 04:17:07","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("71","404","","0","2019-12-23 04:17:07","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("72","404","","0","2019-12-23 04:17:07","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("73","404","","0","2019-12-23 04:20:44","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("74","404","","0","2019-12-23 04:20:44","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("75","404","","0","2019-12-23 04:20:44","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("76","404","","0","2019-12-23 04:20:45","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("77","404","","0","2019-12-23 04:21:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("78","404","","0","2019-12-23 04:21:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("79","404","","0","2019-12-23 04:21:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("80","404","","0","2019-12-23 04:21:07","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("81","404","","0","2019-12-23 04:21:40","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("82","404","","0","2019-12-23 04:21:40","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("83","404","","0","2019-12-23 04:21:40","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("84","404","","0","2019-12-23 04:21:40","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("85","404","","0","2019-12-23 04:22:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("86","404","","0","2019-12-23 04:22:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("87","404","","0","2019-12-23 04:22:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("88","404","","0","2019-12-23 04:22:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("89","404","","0","2019-12-23 04:22:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("90","404","","0","2019-12-23 04:22:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("91","404","","0","2019-12-23 04:22:17","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("92","404","","0","2019-12-23 04:22:17","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("93","404","","0","2019-12-23 04:22:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("94","404","","0","2019-12-23 04:22:35","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("95","404","","0","2019-12-23 04:22:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("96","404","","0","2019-12-23 04:22:35","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("97","404","","0","2019-12-23 04:22:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("98","404","","0","2019-12-23 04:22:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("99","404","","0","2019-12-23 04:22:43","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("100","404","","0","2019-12-23 04:22:43","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("101","404","","0","2019-12-23 04:23:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("102","404","","0","2019-12-23 04:23:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("103","404","","0","2019-12-23 04:23:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("104","404","","0","2019-12-23 04:23:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("105","404","","0","2019-12-23 04:23:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("106","404","","0","2019-12-23 04:23:18","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("107","404","","0","2019-12-23 04:23:18","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("108","404","","0","2019-12-23 04:23:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("109","404","","0","2019-12-23 04:23:45","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("110","404","","0","2019-12-23 04:23:45","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("111","404","","0","2019-12-23 04:23:45","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("112","404","","0","2019-12-23 04:23:45","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("113","404","","0","2019-12-23 04:23:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("114","404","","0","2019-12-23 04:23:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("115","404","","0","2019-12-23 04:23:46","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("116","404","","0","2019-12-23 04:23:46","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("117","404","","0","2019-12-23 04:23:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("118","404","","0","2019-12-23 04:23:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("119","404","","0","2019-12-23 04:23:56","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("120","404","","0","2019-12-23 04:23:56","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("121","404","","0","2019-12-23 04:24:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("122","404","","0","2019-12-23 04:24:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("123","404","","0","2019-12-23 04:24:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("124","404","","0","2019-12-23 04:24:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("125","404","","0","2019-12-23 04:24:46","127.0.0.1","http://dimtepla.com/","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("126","404","","0","2019-12-23 04:24:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("127","404","","0","2019-12-23 04:24:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("128","404","","0","2019-12-23 04:24:46","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("129","404","","0","2019-12-23 04:24:46","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("130","404","","0","2019-12-23 04:24:54","127.0.0.1","http://dimtepla.com/","/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("131","404","","0","2019-12-23 04:24:54","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("132","404","","0","2019-12-23 04:24:54","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("133","404","","0","2019-12-23 04:24:55","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("134","404","","0","2019-12-23 04:24:55","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("135","404","","0","2019-12-23 04:25:10","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("136","404","","0","2019-12-23 04:25:10","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("137","404","","0","2019-12-23 04:25:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("138","404","","0","2019-12-23 04:25:11","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("139","404","","0","2019-12-23 04:25:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("140","404","","0","2019-12-23 04:25:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("141","404","","0","2019-12-23 04:25:30","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("142","404","","0","2019-12-23 04:25:30","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("143","404","","0","2019-12-23 04:29:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("144","404","","0","2019-12-23 04:29:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("145","404","","0","2019-12-23 04:29:01","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("146","404","","0","2019-12-23 04:29:01","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("147","404","","0","2019-12-23 04:30:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("148","404","","0","2019-12-23 04:30:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("149","404","","0","2019-12-23 04:30:47","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("150","404","","0","2019-12-23 04:30:48","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("151","404","","0","2019-12-23 04:37:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("152","404","","0","2019-12-23 04:37:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("153","404","","0","2019-12-23 04:37:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("154","404","","0","2019-12-23 04:37:08","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("155","404","","0","2019-12-23 04:39:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("156","404","","0","2019-12-23 04:39:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("157","404","","0","2019-12-23 04:39:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("158","404","","0","2019-12-23 04:39:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("159","404","","0","2019-12-23 04:39:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("160","404","","0","2019-12-23 04:39:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("161","404","","0","2019-12-23 04:39:17","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("162","404","","0","2019-12-23 04:39:17","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("163","404","","0","2019-12-23 04:41:21","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("164","404","","0","2019-12-23 04:41:21","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("165","404","","0","2019-12-23 04:41:21","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("166","404","","0","2019-12-23 04:41:21","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("167","404","","0","2019-12-23 04:46:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("168","404","","0","2019-12-23 04:46:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("169","404","","0","2019-12-23 04:46:42","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("170","404","","0","2019-12-23 04:46:43","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("171","404","","0","2019-12-23 04:47:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("172","404","","0","2019-12-23 04:47:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("173","404","","0","2019-12-23 04:47:05","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("174","404","","0","2019-12-23 04:47:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("175","404","","0","2019-12-23 04:47:19","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("176","404","","0","2019-12-23 04:47:19","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("177","404","","0","2019-12-23 04:47:20","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("178","404","","0","2019-12-23 04:47:20","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("179","404","","0","2019-12-23 04:49:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("180","404","","0","2019-12-23 04:49:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("181","404","","0","2019-12-23 04:49:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("182","404","","0","2019-12-23 04:49:06","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("183","404","","0","2019-12-23 04:49:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("184","404","","0","2019-12-23 04:49:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("185","404","","0","2019-12-23 04:49:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("186","404","","0","2019-12-23 04:49:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("187","404","","0","2019-12-23 04:51:17","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.boot.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("188","404","","0","2019-12-23 04:51:17","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.vendor.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("189","404","","0","2019-12-23 04:51:17","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.core.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("190","404","","0","2019-12-23 04:51:18","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("191","404","","0","2019-12-23 04:51:18","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("192","404","","0","2019-12-23 04:51:18","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("193","404","","0","2019-12-23 04:51:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("194","404","","0","2019-12-23 04:51:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("195","404","","0","2019-12-23 04:51:20","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("196","404","","0","2019-12-23 04:51:20","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("197","404","","0","2019-12-23 04:51:20","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("198","404","","0","2019-12-23 04:51:20","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("199","404","","0","2019-12-23 04:51:20","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("200","404","","0","2019-12-23 04:51:20","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("201","404","","0","2019-12-23 04:52:17","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("202","404","","0","2019-12-23 04:52:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("203","404","","0","2019-12-23 04:52:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("204","404","","0","2019-12-23 04:52:18","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("205","404","","0","2019-12-23 04:52:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("206","404","","0","2019-12-23 04:52:18","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("207","404","","0","2019-12-23 04:52:28","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("208","404","","0","2019-12-23 04:52:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("209","404","","0","2019-12-23 04:52:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("210","404","","0","2019-12-23 04:52:28","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("211","404","","0","2019-12-23 04:52:28","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("212","404","","0","2019-12-23 04:52:28","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("213","404","","0","2019-12-23 04:52:32","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("214","404","","0","2019-12-23 04:52:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("215","404","","0","2019-12-23 04:52:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("216","404","","0","2019-12-23 04:52:32","127.0.0.1","http://dimtepla.com/shop/?customize_changeset_uuid=9a232edd-a23f-4631-9570-40a4221c190a&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("217","404","","0","2019-12-23 04:52:32","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("218","404","","0","2019-12-23 04:52:32","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("219","404","","0","2019-12-23 04:52:54","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("220","404","","0","2019-12-23 04:52:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("221","404","","0","2019-12-23 04:52:55","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("222","404","","0","2019-12-23 04:52:55","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("223","404","","0","2019-12-23 04:52:59","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.vendor.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("224","404","","0","2019-12-23 04:52:59","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.core.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("225","404","","0","2019-12-23 04:52:59","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.boot.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("226","404","","0","2019-12-23 04:53:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("227","404","","0","2019-12-23 04:53:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("228","404","","0","2019-12-23 04:53:05","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("229","404","","0","2019-12-23 04:53:05","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("230","404","","0","2019-12-23 04:54:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("231","404","","0","2019-12-23 04:54:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("232","404","","0","2019-12-23 04:54:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("233","404","","0","2019-12-23 04:54:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("234","404","","0","2019-12-23 04:54:45","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("235","404","","0","2019-12-23 04:54:50","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("236","404","","0","2019-12-23 04:54:50","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("237","404","","0","2019-12-23 04:54:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("238","404","","0","2019-12-23 04:54:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("239","404","","0","2019-12-23 04:54:53","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("240","404","","0","2019-12-23 05:07:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("241","404","","0","2019-12-23 05:07:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("242","404","","0","2019-12-23 05:07:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("243","404","","0","2019-12-23 05:07:26","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("244","404","","0","2019-12-23 05:08:49","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("245","404","","0","2019-12-23 05:08:49","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("246","404","","0","2019-12-23 05:08:49","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("247","404","","0","2019-12-23 05:08:50","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("248","404","","0","2019-12-23 05:09:15","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("249","404","","0","2019-12-23 05:09:15","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("250","404","","0","2019-12-23 05:09:15","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("251","404","","0","2019-12-23 05:09:15","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("252","404","","0","2019-12-23 05:09:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("253","404","","0","2019-12-23 05:09:17","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("254","404","","0","2019-12-23 05:09:17","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("255","404","","0","2019-12-23 05:13:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("256","404","","0","2019-12-23 05:13:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("257","404","","0","2019-12-23 05:13:52","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("258","404","","0","2019-12-23 05:14:14","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("259","404","","0","2019-12-23 05:14:14","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("260","404","","0","2019-12-23 05:14:14","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("261","404","","0","2019-12-23 05:14:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("262","404","","0","2019-12-23 05:14:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("263","404","","0","2019-12-23 05:14:28","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("264","404","","0","2019-12-23 05:15:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("265","404","","0","2019-12-23 05:15:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("266","404","","0","2019-12-23 05:15:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("267","404","","0","2019-12-23 05:15:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("268","404","","0","2019-12-23 05:15:30","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("269","404","","0","2019-12-23 05:15:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("270","404","","0","2019-12-23 05:15:58","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("271","404","","0","2019-12-23 05:15:58","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("272","404","","0","2019-12-23 05:15:58","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("273","404","","0","2019-12-23 05:16:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("274","404","","0","2019-12-23 05:16:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("275","404","","0","2019-12-23 05:16:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("276","404","","0","2019-12-23 05:16:25","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/assets/css/fonts.css","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("277","404","","0","2019-12-23 05:16:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("278","404","","0","2019-12-23 05:16:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("279","404","","0","2019-12-23 05:17:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("280","404","","0","2019-12-23 05:17:25","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("281","404","","0","2019-12-23 05:17:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("282","404","","0","2019-12-23 05:17:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("283","404","","0","2019-12-23 05:18:23","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("284","404","","0","2019-12-23 05:18:23","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("285","404","","0","2019-12-23 05:19:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("286","404","","0","2019-12-23 05:19:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("287","404","","0","2019-12-23 05:19:07","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("288","404","","0","2019-12-23 05:19:07","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("289","404","","0","2019-12-23 05:19:40","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("290","404","","0","2019-12-23 05:19:40","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("291","404","","0","2019-12-23 05:26:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("292","404","","0","2019-12-23 05:26:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("293","404","","0","2019-12-23 05:26:59","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/style.css?ver=40eaa2fd3bde164ecbb15047abd02d35","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("294","404","","0","2019-12-23 05:26:59","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/style.css?ver=40eaa2fd3bde164ecbb15047abd02d35","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("295","404","","0","2019-12-23 05:27:16","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("296","404","","0","2019-12-23 05:27:16","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("297","404","","0","2019-12-23 05:27:16","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/style.css?ver=40eaa2fd3bde164ecbb15047abd02d35","/assets/fonts/GothamPro.woff","","");
INSERT INTO `wp_aiowps_events` VALUES("298","404","","0","2019-12-23 05:27:16","127.0.0.1","http://dimtepla.com/wp-content/themes/dimtepla/style.css?ver=40eaa2fd3bde164ecbb15047abd02d35","/assets/fonts/GothamPro.ttf","","");
INSERT INTO `wp_aiowps_events` VALUES("299","404","","0","2019-12-23 05:27:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("300","404","","0","2019-12-23 05:27:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("301","404","","0","2019-12-23 05:27:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("302","404","","0","2019-12-23 05:27:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("303","404","","0","2019-12-23 05:28:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("304","404","","0","2019-12-23 05:28:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("305","404","","0","2019-12-23 05:40:06","127.0.0.1","http://dimtepla.com/","/dimtepla.com/assets/images/logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("306","404","","0","2019-12-23 05:41:53","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("307","404","","0","2019-12-23 05:41:53","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("308","404","","0","2019-12-23 07:55:38","127.0.0.1","http://dimtepla.com/","/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("309","404","","0","2019-12-23 07:55:38","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("310","404","","0","2019-12-23 07:55:38","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("311","404","","0","2019-12-23 07:55:38","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("312","404","","0","2019-12-23 07:56:58","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("313","404","","0","2019-12-23 07:56:58","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("314","404","","0","2019-12-23 07:56:58","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("315","404","","0","2019-12-23 07:56:58","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("316","404","","0","2019-12-23 07:57:01","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("317","404","","0","2019-12-23 07:57:01","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("318","404","","0","2019-12-23 07:57:01","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("319","404","","0","2019-12-23 07:57:01","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("320","404","","0","2019-12-23 07:57:49","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("321","404","","0","2019-12-23 07:57:49","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("322","404","","0","2019-12-23 07:57:49","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("323","404","","0","2019-12-23 07:57:49","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("324","404","","0","2019-12-23 07:57:51","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("325","404","","0","2019-12-23 07:57:51","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("326","404","","0","2019-12-23 07:57:51","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("327","404","","0","2019-12-23 07:57:51","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("328","404","","0","2019-12-23 07:57:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("329","404","","0","2019-12-23 07:57:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("330","404","","0","2019-12-23 07:58:38","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("331","404","","0","2019-12-23 07:58:38","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("332","404","","0","2019-12-23 07:58:38","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("333","404","","0","2019-12-23 07:58:38","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("334","404","","0","2019-12-23 07:58:38","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("335","404","","0","2019-12-23 07:58:38","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("336","404","","0","2019-12-23 07:58:41","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("337","404","","0","2019-12-23 07:58:41","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("338","404","","0","2019-12-23 07:58:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("339","404","","0","2019-12-23 07:58:42","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("340","404","","0","2019-12-23 07:58:42","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("341","404","","0","2019-12-23 07:58:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("342","404","","0","2019-12-23 08:00:27","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("343","404","","0","2019-12-23 08:00:27","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("344","404","","0","2019-12-23 08:00:28","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("345","404","","0","2019-12-23 08:00:28","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("346","404","","0","2019-12-23 08:00:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("347","404","","0","2019-12-23 08:00:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("348","404","","0","2019-12-23 08:00:35","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("349","404","","0","2019-12-23 08:00:35","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("350","404","","0","2019-12-23 08:00:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("351","404","","0","2019-12-23 08:00:35","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("352","404","","0","2019-12-23 08:00:35","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("353","404","","0","2019-12-23 08:00:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("354","404","","0","2019-12-23 08:00:44","127.0.0.1","http://dimtepla.com/","/assets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("355","404","","0","2019-12-23 08:00:44","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("356","404","","0","2019-12-23 08:00:44","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("357","404","","0","2019-12-23 08:00:44","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("358","404","","0","2019-12-23 08:00:44","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("359","404","","0","2019-12-23 08:00:44","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("360","404","","0","2019-12-23 08:02:49","127.0.0.1","http://dimtepla.com/","/wp-content/themes/dimteplaassets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("361","404","","0","2019-12-23 08:02:49","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("362","404","","0","2019-12-23 08:02:50","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("363","404","","0","2019-12-23 08:02:50","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("364","404","","0","2019-12-23 08:02:50","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("365","404","","0","2019-12-23 08:02:50","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("366","404","","0","2019-12-23 08:02:52","127.0.0.1","http://dimtepla.com/","/wp-content/themes/dimteplaassets/images/fb.png","","");
INSERT INTO `wp_aiowps_events` VALUES("367","404","","0","2019-12-23 08:02:52","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("368","404","","0","2019-12-23 08:02:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("369","404","","0","2019-12-23 08:02:52","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("370","404","","0","2019-12-23 08:02:52","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("371","404","","0","2019-12-23 08:02:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("372","404","","0","2019-12-23 08:03:05","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("373","404","","0","2019-12-23 08:03:05","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("374","404","","0","2019-12-23 08:03:05","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("375","404","","0","2019-12-23 08:03:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("376","404","","0","2019-12-23 08:03:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("377","404","","0","2019-12-23 08:04:34","127.0.0.1","http://dimtepla.com/","/images/inst.png","","");
INSERT INTO `wp_aiowps_events` VALUES("378","404","","0","2019-12-23 08:04:34","127.0.0.1","http://dimtepla.com/","/images/vk.png","","");
INSERT INTO `wp_aiowps_events` VALUES("379","404","","0","2019-12-23 08:04:34","127.0.0.1","http://dimtepla.com/","/images/footer-logo.png","","");
INSERT INTO `wp_aiowps_events` VALUES("380","404","","0","2019-12-23 08:04:34","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("381","404","","0","2019-12-23 08:04:34","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("382","404","","0","2019-12-23 08:05:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("383","404","","0","2019-12-23 08:05:12","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("384","404","","0","2019-12-23 08:10:41","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("385","404","","0","2019-12-23 08:10:41","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("386","404","","0","2019-12-23 08:11:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("387","404","","0","2019-12-23 08:11:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("388","404","","0","2019-12-23 08:12:09","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("389","404","","0","2019-12-23 08:12:09","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("390","404","","0","2019-12-23 08:14:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("391","404","","0","2019-12-23 08:14:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("392","404","","0","2019-12-23 08:14:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("393","404","","0","2019-12-23 08:14:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("394","404","","0","2019-12-23 08:15:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("395","404","","0","2019-12-23 08:15:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("396","404","","0","2019-12-23 08:15:10","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("397","404","","0","2019-12-23 08:15:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("398","404","","0","2019-12-23 08:15:23","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("399","404","","0","2019-12-23 08:15:23","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("400","404","","0","2019-12-23 08:15:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("401","404","","0","2019-12-23 08:15:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("402","404","","0","2019-12-23 08:16:15","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("403","404","","0","2019-12-23 08:16:15","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("404","404","","0","2019-12-23 08:17:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("405","404","","0","2019-12-23 08:17:26","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("406","404","","0","2019-12-23 08:17:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("407","404","","0","2019-12-23 08:17:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("408","404","","0","2019-12-23 08:18:03","127.0.0.1","http://dimtepla.com/","/images/tovar/arrow.png","","");
INSERT INTO `wp_aiowps_events` VALUES("409","404","","0","2019-12-23 08:18:03","127.0.0.1","http://dimtepla.com/","/images/tovar/tovar.png","","");
INSERT INTO `wp_aiowps_events` VALUES("410","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/shit.png","","");
INSERT INTO `wp_aiowps_events` VALUES("411","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/fire.png","","");
INSERT INTO `wp_aiowps_events` VALUES("412","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/kotl1.png","","");
INSERT INTO `wp_aiowps_events` VALUES("413","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/arrows.png","","");
INSERT INTO `wp_aiowps_events` VALUES("414","404","","0","2019-12-23 08:18:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("415","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/kotl2.png","","");
INSERT INTO `wp_aiowps_events` VALUES("416","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/tovar.png","","");
INSERT INTO `wp_aiowps_events` VALUES("417","404","","0","2019-12-23 08:18:04","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("418","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/kotl3.png","","");
INSERT INTO `wp_aiowps_events` VALUES("419","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/download.png","","");
INSERT INTO `wp_aiowps_events` VALUES("420","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/to-top.png","","");
INSERT INTO `wp_aiowps_events` VALUES("421","404","","0","2019-12-23 08:18:04","127.0.0.1","http://dimtepla.com/","/images/tovar/arrow.png","","");
INSERT INTO `wp_aiowps_events` VALUES("422","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/home.png","","");
INSERT INTO `wp_aiowps_events` VALUES("423","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/image1.png","","");
INSERT INTO `wp_aiowps_events` VALUES("424","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/image2.png","","");
INSERT INTO `wp_aiowps_events` VALUES("425","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/3actor.png","","");
INSERT INTO `wp_aiowps_events` VALUES("426","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/2actor.png","","");
INSERT INTO `wp_aiowps_events` VALUES("427","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/image3.png","","");
INSERT INTO `wp_aiowps_events` VALUES("428","404","","0","2019-12-23 08:18:53","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("429","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/1actor.png","","");
INSERT INTO `wp_aiowps_events` VALUES("430","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/map.png","","");
INSERT INTO `wp_aiowps_events` VALUES("431","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/shield.png","","");
INSERT INTO `wp_aiowps_events` VALUES("432","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/image1.png","","");
INSERT INTO `wp_aiowps_events` VALUES("433","404","","0","2019-12-23 08:18:53","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("434","404","","0","2019-12-23 08:18:53","127.0.0.1","http://dimtepla.com/","/images/to-top.png","","");
INSERT INTO `wp_aiowps_events` VALUES("435","404","","0","2019-12-23 08:21:20","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("436","404","","0","2019-12-23 08:21:20","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("437","404","","0","2019-12-23 08:22:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("438","404","","0","2019-12-23 08:22:55","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("439","404","","0","2019-12-23 08:23:24","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("440","404","","0","2019-12-23 08:23:24","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("441","404","","0","2019-12-23 08:23:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("442","404","","0","2019-12-23 08:23:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("443","404","","0","2019-12-23 08:29:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("444","404","","0","2019-12-23 08:29:46","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("445","404","","0","2019-12-23 08:31:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("446","404","","0","2019-12-23 08:31:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("447","404","","0","2019-12-23 08:38:45","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=4a4f077e-05ca-4d38-8f6e-8e9c57fa9989&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("448","404","","0","2019-12-24 01:13:50","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.core.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("449","404","","0","2019-12-24 01:13:50","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.boot.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("450","404","","0","2019-12-24 01:13:50","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.vendor.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("451","404","","0","2019-12-24 01:13:50","127.0.0.1","","/wp-includes/js/tinymce/skins/lightgray/skin.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("452","404","","0","2019-12-24 02:11:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("453","404","","0","2019-12-24 02:11:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("454","404","","0","2019-12-24 02:11:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("455","404","","0","2019-12-24 02:11:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("456","404","","0","2019-12-24 02:15:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("457","404","","0","2019-12-24 02:15:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("458","404","","0","2019-12-25 05:31:10","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("459","404","","0","2019-12-25 05:31:58","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("460","404","","0","2019-12-25 05:31:58","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("461","404","","0","2019-12-25 05:32:01","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("462","404","","0","2019-12-25 05:33:06","127.0.0.1","http://dimtepla.com/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("463","404","","0","2019-12-25 05:33:25","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?url=http%3A%2F%2Fdimtepla.com%2F","/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("464","404","","0","2019-12-25 05:33:25","127.0.0.1","http://dimtepla.com/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("465","404","","0","2019-12-25 05:33:30","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?url=http%3A%2F%2Fdimtepla.com%2F","/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("466","404","","0","2019-12-25 05:33:30","127.0.0.1","http://dimtepla.com/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("467","404","","0","2019-12-25 05:33:31","127.0.0.1","http://dimtepla.com/page/2/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("468","404","","0","2019-12-25 05:33:33","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=fc26ffe8-a07a-4550-81f8-efca2e60eacc&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-6&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("469","404","","0","2019-12-25 07:50:22","127.0.0.1","","/store","","");
INSERT INTO `wp_aiowps_events` VALUES("470","404","","0","2019-12-25 07:51:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("471","404","","0","2019-12-25 07:51:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("472","404","","0","2019-12-25 07:58:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("473","404","","0","2019-12-25 07:58:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("474","404","","0","2019-12-26 07:45:58","127.0.0.1","","/shop/","","");
INSERT INTO `wp_aiowps_events` VALUES("475","404","","0","2019-12-26 07:46:03","127.0.0.1","","/shop/","","");
INSERT INTO `wp_aiowps_events` VALUES("476","404","","0","2019-12-26 19:45:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("477","404","","0","2019-12-26 19:45:30","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("478","404","","0","2019-12-26 19:49:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("479","404","","0","2019-12-26 19:49:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("480","404","","0","2019-12-26 19:49:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("481","404","","0","2019-12-26 19:49:29","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("482","404","","0","2019-12-26 20:01:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("483","404","","0","2019-12-26 20:01:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("484","404","","0","2019-12-26 20:02:03","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("485","404","","0","2019-12-26 20:02:03","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("486","404","","0","2019-12-26 20:02:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("487","404","","0","2019-12-26 20:02:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("488","404","","0","2019-12-26 20:02:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("489","404","","0","2019-12-26 20:02:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("490","404","","0","2019-12-26 20:12:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("491","404","","0","2019-12-26 20:12:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("492","404","","0","2019-12-26 20:12:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("493","404","","0","2019-12-26 20:12:53","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("494","404","","0","2019-12-26 20:16:57","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("495","404","","0","2019-12-26 20:16:57","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("496","404","","0","2019-12-26 20:17:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("497","404","","0","2019-12-26 20:17:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("498","404","","0","2019-12-26 20:19:29","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("499","404","","0","2019-12-26 20:19:29","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("500","404","","0","2019-12-26 20:22:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("501","404","","0","2019-12-26 20:22:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("502","404","","0","2019-12-26 20:27:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("503","404","","0","2019-12-26 20:27:05","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("504","404","","0","2019-12-26 20:27:15","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("505","404","","0","2019-12-26 20:27:16","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("506","404","","0","2019-12-26 20:30:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("507","404","","0","2019-12-26 20:30:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("508","404","","0","2019-12-26 20:39:19","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("509","404","","0","2019-12-26 20:39:19","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("510","404","","0","2019-12-26 20:40:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("511","404","","0","2019-12-26 20:40:39","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("512","404","","0","2019-12-26 23:51:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("513","404","","0","2019-12-26 23:51:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("514","404","","0","2019-12-26 23:51:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("515","404","","0","2019-12-26 23:51:28","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("516","404","","0","2019-12-26 23:52:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("517","404","","0","2019-12-26 23:52:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("518","404","","0","2019-12-26 23:53:13","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("519","404","","0","2019-12-26 23:53:13","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("520","404","","0","2019-12-26 23:53:38","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("521","404","","0","2019-12-26 23:53:38","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("522","404","","0","2019-12-26 23:54:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("523","404","","0","2019-12-26 23:54:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("524","404","","0","2019-12-26 23:55:07","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("525","404","","0","2019-12-26 23:55:34","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?return=%2Fwp-admin%2Fedit.php%3Fpost_type%3Dproduct","/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","","");
INSERT INTO `wp_aiowps_events` VALUES("526","404","","0","2019-12-26 23:55:34","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("527","404","","0","2019-12-26 23:55:34","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("528","404","","0","2019-12-26 23:55:38","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?return=%2Fwp-admin%2Fedit.php%3Fpost_type%3Dproduct","/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("529","404","","0","2019-12-26 23:55:38","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("530","404","","0","2019-12-26 23:55:38","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-2&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("531","404","","0","2019-12-26 23:55:41","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?return=%2Fwp-admin%2Fedit.php%3Fpost_type%3Dproduct","/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("532","404","","0","2019-12-26 23:55:41","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("533","404","","0","2019-12-26 23:55:41","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-3&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("534","404","","0","2019-12-26 23:55:43","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?return=%2Fwp-admin%2Fedit.php%3Fpost_type%3Dproduct","/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("535","404","","0","2019-12-26 23:55:43","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-4&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("536","404","","0","2019-12-26 23:55:45","127.0.0.1","http://dimtepla.com/wp-admin/customize.php?return=%2Fwp-admin%2Fedit.php%3Fpost_type%3Dproduct","/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","","");
INSERT INTO `wp_aiowps_events` VALUES("537","404","","0","2019-12-26 23:55:45","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("538","404","","0","2019-12-26 23:55:45","127.0.0.1","http://dimtepla.com/checkout__trashed/?customize_changeset_uuid=49990ebf-669b-409c-a85c-43bab00edb85&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-5&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("539","404","","0","2019-12-26 23:56:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("540","404","","0","2019-12-26 23:56:06","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("541","404","","0","2019-12-26 23:56:10","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.core.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("542","404","","0","2019-12-26 23:56:10","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.boot.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("543","404","","0","2019-12-26 23:56:10","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.vendor.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("544","404","","0","2019-12-26 23:56:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("545","404","","0","2019-12-26 23:56:11","127.0.0.1","http://dimtepla.com/product/boiler/?customize_changeset_uuid=eadcb111-e77f-4012-bce0-dca6a0a12ca0&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("546","404","","0","2019-12-26 23:56:11","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("547","404","","0","2019-12-26 23:56:37","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("548","404","","0","2019-12-26 23:56:38","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=eadcb111-e77f-4012-bce0-dca6a0a12ca0&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("549","404","","0","2019-12-26 23:56:38","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("550","404","","0","2019-12-26 23:56:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("551","404","","0","2019-12-26 23:56:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("552","404","","0","2019-12-26 23:56:46","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.boot.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("553","404","","0","2019-12-26 23:56:46","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.vendor.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("554","404","","0","2019-12-26 23:56:46","127.0.0.1","","/wp-content/themes/dimtepla/includes/carbon-fields/vendor/htmlburger/carbon-fields/assets/dist/carbon.core.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("555","404","","0","2019-12-26 23:56:47","127.0.0.1","http://dimtepla.com/product/boiler/?customize_changeset_uuid=36e00f25-1f81-4d63-a332-db64132208e7&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("556","404","","0","2019-12-26 23:56:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("557","404","","0","2019-12-26 23:56:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("558","404","","0","2019-12-26 23:56:47","127.0.0.1","http://dimtepla.com/product/boiler/?customize_changeset_uuid=36e00f25-1f81-4d63-a332-db64132208e7&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("559","404","","0","2019-12-26 23:57:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("560","404","","0","2019-12-26 23:57:01","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("561","404","","0","2019-12-27 00:00:31","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("562","404","","0","2019-12-27 00:00:31","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("563","404","","0","2019-12-27 00:45:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("564","404","","0","2019-12-27 00:45:59","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("565","404","","0","2019-12-27 00:48:16","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("566","404","","0","2019-12-27 00:48:16","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("567","404","","0","2019-12-27 00:54:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("568","404","","0","2019-12-27 00:54:08","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("569","404","","0","2019-12-27 00:54:36","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("570","404","","0","2019-12-27 00:54:36","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("571","404","","0","2019-12-27 00:56:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("572","404","","0","2019-12-27 00:56:56","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("573","404","","0","2019-12-27 00:57:29","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("574","404","","0","2019-12-27 00:57:29","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("575","404","","0","2019-12-27 00:58:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("576","404","","0","2019-12-27 00:58:02","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("577","404","","0","2019-12-27 00:58:57","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("578","404","","0","2019-12-27 00:58:57","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("579","404","","0","2019-12-27 00:59:19","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("580","404","","0","2019-12-27 00:59:19","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("581","404","","0","2019-12-29 09:38:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("582","404","","0","2019-12-29 09:38:51","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("583","404","","0","2019-12-29 09:42:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("584","404","","0","2019-12-29 09:42:43","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("585","404","","0","2019-12-29 09:43:27","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=7de35e68-66d2-4819-b6bf-7082b0545cf4&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-0","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("586","404","","0","2019-12-29 09:44:06","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=7de35e68-66d2-4819-b6bf-7082b0545cf4&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("587","404","","0","2019-12-29 09:44:07","127.0.0.1","http://dimtepla.com/?customize_changeset_uuid=7de35e68-66d2-4819-b6bf-7082b0545cf4&amp;customize_theme=dimtepla&amp;customize_messenger_channel=preview-1&amp;customize_autosaved=on","/wp-content/themes/dimtepla/js/customizer.js?ver=20151215","","");
INSERT INTO `wp_aiowps_events` VALUES("588","404","","0","2019-12-29 09:44:12","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("589","404","","0","2019-12-29 09:44:12","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("590","404","","0","2019-12-29 09:45:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("591","404","","0","2019-12-29 09:45:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("592","404","","0","2019-12-29 09:45:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("593","404","","0","2019-12-29 09:45:42","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("594","404","","0","2019-12-29 09:47:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("595","404","","0","2019-12-29 09:47:52","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("596","404","","0","2019-12-29 10:04:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("597","404","","0","2019-12-29 10:04:47","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("598","404","","0","2019-12-29 10:06:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("599","404","","0","2019-12-29 10:06:32","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");
INSERT INTO `wp_aiowps_events` VALUES("600","404","","0","2019-12-29 10:06:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/js/bootstrap.min.js.map","","");
INSERT INTO `wp_aiowps_events` VALUES("601","404","","0","2019-12-29 10:06:35","127.0.0.1","","/wp-content/themes/dimtepla/assets/css/bootstrap.min.css.map","","");


DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_commentmeta` VALUES("1","1","_wp_trash_meta_status","1");
INSERT INTO `wp_commentmeta` VALUES("2","1","_wp_trash_meta_time","1577335400");


DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2019-12-17 17:41:23","2019-12-17 14:41:23","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","post-trashed","","","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=3820 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("2","home","http://dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("3","blogname","dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","Email@mail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:4:{i:0;s:31:\"query-monitor/query-monitor.php\";i:1;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:2;s:21:\"imsanity/imsanity.php\";i:3;s:27:\"woocommerce/woocommerce.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","a:3:{i:0;s:69:\"/var/www/dimtepla.com/wp-content/themes/dimtepla/assets/css/style.css\";i:1;s:58:\"/var/www/dimtepla.com/wp-content/themes/dimtepla/style.css\";i:2;s:0:\"\";}","no");
INSERT INTO `wp_options` VALUES("40","template","dimtepla","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","dimtepla","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","45805","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:3:{i:2;a:4:{s:5:\"title\";s:13:\"О сайте\";s:4:\"text\";s:205:\"Здесь может быть отличное место для того, чтобы представить себя, свой сайт или выразить какие-то благодарности.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:21:\"Найдите нас\";s:4:\"text\";s:226:\"<strong>Адрес</strong>
123 Мейн стрит
Нью Йорк, NY 10001

<strong>Часы</strong>
Понедельник&mdash;пятница: 9:00&ndash;17:00
Суббота и воскресенье: 11:00&ndash;15:00\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","140","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("93","admin_email_lifespan","1592145683","yes");
INSERT INTO `wp_options` VALUES("94","initial_db_version","45805","yes");
INSERT INTO `wp_options` VALUES("95","wp_user_roles","a:7:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:114:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("96","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("97","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("98","widget_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-posts","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_recent-comments","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_archives","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_meta","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","sidebars_widgets","a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:0:{}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("104","cron","a:17:{i:1577805226;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577806145;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1577806884;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1577811263;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1577812172;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1577822978;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1577826000;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577844578;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577844588;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577846484;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1577855378;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577889683;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577889696;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577889697;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1577891372;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1578355200;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("115","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("119","theme_mods_twentytwenty","a:4:{s:18:\"custom_css_post_id\";i:-1;s:16:\"background_color\";s:3:\"fff\";s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1576599673;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}s:18:\"nav_menu_locations\";a:0:{}}","yes");
INSERT INTO `wp_options` VALUES("131","can_compress_scripts","0","no");
INSERT INTO `wp_options` VALUES("146","recently_activated","a:1:{s:24:\"wordpress-seo/wp-seo.php\";i:1577235065;}","yes");
INSERT INTO `wp_options` VALUES("147","ftp_credentials","a:3:{s:8:\"hostname\";s:9:\"127.0.1.1\";s:8:\"username\";s:5:\"admin\";s:15:\"connection_type\";s:3:\"ftp\";}","yes");
INSERT INTO `wp_options` VALUES("157","new_admin_email","Email@mail.com","yes");
INSERT INTO `wp_options` VALUES("168","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("169","aio_wp_security_configs","a:94:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"aew2zhy60o1lbci0frvd\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:1:\"1\";s:28:\"aiowps_enable_404_IP_lockout\";s:1:\"1\";s:30:\"aiowps_404_lockout_time_length\";i:60;s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:61:\"This site is currently not available. Please try again later.\";s:30:\"aiowps_enable_spambot_blocking\";s:1:\"1\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:1:\"1\";s:33:\"aiowps_spam_ip_min_comments_block\";i:3;s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-12-17 19:10:45\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_woo_register_captcha\";s:1:\"1\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("183","wpseo","a:20:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:6:\"12.7.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1576595626;s:13:\"myyoast-oauth\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("184","wpseo_titles","a:71:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:45:\"%%name%%, Автор в %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:64:\"Вы искали %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:57:\"Страница не найдена %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:84:\"Сообщение %%POSTLINK%% появились сначала на %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:54:\"Ошибка 404: страница не найдена\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:19:\"Архивы для\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:31:\"Главная страница\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:17:\"Вы искали\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:18:\"title-tax-category\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("185","wpseo_social","a:19:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("186","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("187","_transient_timeout_wpseo_link_table_inaccessible","1608131626","no");
INSERT INTO `wp_options` VALUES("188","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("189","_transient_timeout_wpseo_meta_table_inaccessible","1608131626","no");
INSERT INTO `wp_options` VALUES("190","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("206","woocommerce_store_address","dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("207","woocommerce_store_address_2","","yes");
INSERT INTO `wp_options` VALUES("208","woocommerce_store_city","dnepr","yes");
INSERT INTO `wp_options` VALUES("209","woocommerce_default_country","UA","yes");
INSERT INTO `wp_options` VALUES("210","woocommerce_store_postcode","","yes");
INSERT INTO `wp_options` VALUES("211","woocommerce_allowed_countries","all","yes");
INSERT INTO `wp_options` VALUES("212","woocommerce_all_except_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("213","woocommerce_specific_allowed_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("214","woocommerce_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("215","woocommerce_specific_ship_to_countries","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("216","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO `wp_options` VALUES("217","woocommerce_calc_taxes","no","yes");
INSERT INTO `wp_options` VALUES("218","woocommerce_enable_coupons","no","yes");
INSERT INTO `wp_options` VALUES("219","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `wp_options` VALUES("220","woocommerce_currency","UAH","yes");
INSERT INTO `wp_options` VALUES("221","woocommerce_currency_pos","left","yes");
INSERT INTO `wp_options` VALUES("222","woocommerce_price_thousand_sep","","yes");
INSERT INTO `wp_options` VALUES("223","woocommerce_price_decimal_sep","","yes");
INSERT INTO `wp_options` VALUES("224","woocommerce_price_num_decimals","0","yes");
INSERT INTO `wp_options` VALUES("225","woocommerce_shop_page_id","","yes");
INSERT INTO `wp_options` VALUES("226","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `wp_options` VALUES("227","woocommerce_enable_ajax_add_to_cart","no","yes");
INSERT INTO `wp_options` VALUES("228","woocommerce_placeholder_image","11","yes");
INSERT INTO `wp_options` VALUES("229","woocommerce_weight_unit","kg","yes");
INSERT INTO `wp_options` VALUES("230","woocommerce_dimension_unit","cm","yes");
INSERT INTO `wp_options` VALUES("231","woocommerce_enable_reviews","no","yes");
INSERT INTO `wp_options` VALUES("232","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO `wp_options` VALUES("233","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `wp_options` VALUES("234","woocommerce_enable_review_rating","yes","yes");
INSERT INTO `wp_options` VALUES("235","woocommerce_review_rating_required","yes","no");
INSERT INTO `wp_options` VALUES("236","woocommerce_manage_stock","yes","yes");
INSERT INTO `wp_options` VALUES("237","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `wp_options` VALUES("238","woocommerce_notify_low_stock","yes","no");
INSERT INTO `wp_options` VALUES("239","woocommerce_notify_no_stock","yes","no");
INSERT INTO `wp_options` VALUES("240","woocommerce_stock_email_recipient","Email@mail.com","no");
INSERT INTO `wp_options` VALUES("241","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `wp_options` VALUES("242","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `wp_options` VALUES("243","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `wp_options` VALUES("244","woocommerce_stock_format","","yes");
INSERT INTO `wp_options` VALUES("245","woocommerce_file_download_method","force","no");
INSERT INTO `wp_options` VALUES("246","woocommerce_downloads_require_login","no","no");
INSERT INTO `wp_options` VALUES("247","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `wp_options` VALUES("248","woocommerce_prices_include_tax","no","yes");
INSERT INTO `wp_options` VALUES("249","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `wp_options` VALUES("250","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `wp_options` VALUES("251","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `wp_options` VALUES("252","woocommerce_tax_classes","","yes");
INSERT INTO `wp_options` VALUES("253","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `wp_options` VALUES("254","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `wp_options` VALUES("255","woocommerce_price_display_suffix","","yes");
INSERT INTO `wp_options` VALUES("256","woocommerce_tax_total_display","itemized","no");
INSERT INTO `wp_options` VALUES("257","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `wp_options` VALUES("258","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `wp_options` VALUES("259","woocommerce_ship_to_destination","billing","no");
INSERT INTO `wp_options` VALUES("260","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `wp_options` VALUES("261","woocommerce_enable_guest_checkout","no","no");
INSERT INTO `wp_options` VALUES("262","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO `wp_options` VALUES("263","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `wp_options` VALUES("264","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO `wp_options` VALUES("265","woocommerce_registration_generate_username","no","no");
INSERT INTO `wp_options` VALUES("266","woocommerce_registration_generate_password","no","no");
INSERT INTO `wp_options` VALUES("267","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `wp_options` VALUES("268","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `wp_options` VALUES("269","woocommerce_allow_bulk_remove_personal_data","no","no");
INSERT INTO `wp_options` VALUES("270","woocommerce_registration_privacy_policy_text","Ваши личные данные будут использоваться для упрощения вашей работы с сайтом, управления доступом к вашей учётной записи и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("271","woocommerce_checkout_privacy_policy_text","Ваши личные данные будут использоваться для обработки ваших заказов, упрощения вашей работы с сайтом и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("272","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("273","woocommerce_trash_pending_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("274","woocommerce_trash_failed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("275","woocommerce_trash_cancelled_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:4:\"days\";}","no");
INSERT INTO `wp_options` VALUES("276","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("277","woocommerce_email_from_name","dimtepla.com","no");
INSERT INTO `wp_options` VALUES("278","woocommerce_email_from_address","Email@mail.com","no");
INSERT INTO `wp_options` VALUES("279","woocommerce_email_header_image","","no");
INSERT INTO `wp_options` VALUES("280","woocommerce_email_footer_text","{site_title} &mdash; Built with {WooCommerce}","no");
INSERT INTO `wp_options` VALUES("281","woocommerce_email_base_color","#96588a","no");
INSERT INTO `wp_options` VALUES("282","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `wp_options` VALUES("283","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `wp_options` VALUES("284","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `wp_options` VALUES("285","woocommerce_cart_page_id","13","no");
INSERT INTO `wp_options` VALUES("286","woocommerce_checkout_page_id","14","no");
INSERT INTO `wp_options` VALUES("287","woocommerce_myaccount_page_id","15","no");
INSERT INTO `wp_options` VALUES("288","woocommerce_terms_page_id","","no");
INSERT INTO `wp_options` VALUES("289","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("290","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("291","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `wp_options` VALUES("292","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `wp_options` VALUES("293","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `wp_options` VALUES("294","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `wp_options` VALUES("295","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `wp_options` VALUES("296","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `wp_options` VALUES("297","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `wp_options` VALUES("298","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO `wp_options` VALUES("299","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `wp_options` VALUES("300","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `wp_options` VALUES("301","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `wp_options` VALUES("302","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `wp_options` VALUES("303","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `wp_options` VALUES("304","woocommerce_api_enabled","no","yes");
INSERT INTO `wp_options` VALUES("305","woocommerce_allow_tracking","no","no");
INSERT INTO `wp_options` VALUES("306","woocommerce_show_marketplace_suggestions","yes","no");
INSERT INTO `wp_options` VALUES("307","woocommerce_single_image_width","600","yes");
INSERT INTO `wp_options` VALUES("308","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `wp_options` VALUES("309","woocommerce_checkout_highlight_required_fields","no","yes");
INSERT INTO `wp_options` VALUES("310","woocommerce_demo_store","no","no");
INSERT INTO `wp_options` VALUES("311","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("312","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `wp_options` VALUES("313","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `wp_options` VALUES("314","rewrite_rules","a:157:{s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("317","default_product_cat","15","yes");
INSERT INTO `wp_options` VALUES("322","woocommerce_admin_notices","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("323","_transient_woocommerce_webhook_ids_status_active","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("324","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("325","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("326","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("327","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("328","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("329","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("330","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("331","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("332","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("333","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("334","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("335","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("342","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("346","woocommerce_product_type","both","yes");
INSERT INTO `wp_options` VALUES("380","current_theme","dimtepla","yes");
INSERT INTO `wp_options` VALUES("381","theme_mods_dimtepla","a:5:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1576599050;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:8:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:8:\"search-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";i:5;s:10:\"archives-2\";i:6;s:12:\"categories-2\";i:7;s:6:\"meta-2\";}}}s:18:\"custom_css_post_id\";i:-1;s:16:\"header_textcolor\";s:5:\"blank\";}","yes");
INSERT INTO `wp_options` VALUES("382","theme_switched","","yes");
INSERT INTO `wp_options` VALUES("383","woocommerce_maybe_regenerate_images_hash","991b1ca641921cf0f5baf7a2fe85861b","yes");
INSERT INTO `wp_options` VALUES("397","theme_mods_dimtepla-theme","a:3:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1576599633;s:4:\"data\";a:1:{s:19:\"wp_inactive_widgets\";a:8:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";i:2;s:8:\"search-2\";i:3;s:14:\"recent-posts-2\";i:4;s:17:\"recent-comments-2\";i:5;s:10:\"archives-2\";i:6;s:12:\"categories-2\";i:7;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `wp_options` VALUES("398","recovery_mode_email_last_sent","1577233365","yes");
INSERT INTO `wp_options` VALUES("416","category_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("435","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:14:\"Email@mail.com\";s:7:\"version\";s:5:\"5.3.2\";s:9:\"timestamp\";i:1576771008;}","no");
INSERT INTO `wp_options` VALUES("862","imsanity_max_width","1920","no");
INSERT INTO `wp_options` VALUES("863","imsanity_max_height","1920","no");
INSERT INTO `wp_options` VALUES("864","imsanity_max_width_library","1920","no");
INSERT INTO `wp_options` VALUES("865","imsanity_max_height_library","1920","no");
INSERT INTO `wp_options` VALUES("866","imsanity_max_width_other","1920","no");
INSERT INTO `wp_options` VALUES("867","imsanity_max_height_other","1920","no");
INSERT INTO `wp_options` VALUES("868","imsanity_png_to_jpg","0","no");
INSERT INTO `wp_options` VALUES("869","imsanity_bmp_to_jpg","1","no");
INSERT INTO `wp_options` VALUES("870","imsanity_quality","82","no");
INSERT INTO `wp_options` VALUES("871","imsanity_deep_scan","","no");
INSERT INTO `wp_options` VALUES("872","imsanity_version","2.5.0","yes");
INSERT INTO `wp_options` VALUES("903","_dim_header_logo","","no");
INSERT INTO `wp_options` VALUES("904","_crb_email","","no");
INSERT INTO `wp_options` VALUES("905","_crb_phone","","no");
INSERT INTO `wp_options` VALUES("1165","_transient_product_query-transient-version","1577799269","yes");
INSERT INTO `wp_options` VALUES("1166","_transient_product-transient-version","1577397778","yes");
INSERT INTO `wp_options` VALUES("1180","pa_size_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("1182","pa_color_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("1318","_transient_wc_attribute_taxonomies","a:2:{i:0;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"1\";s:14:\"attribute_name\";s:5:\"color\";s:15:\"attribute_label\";s:5:\"Color\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}i:1;O:8:\"stdClass\":6:{s:12:\"attribute_id\";s:1:\"2\";s:14:\"attribute_name\";s:4:\"size\";s:15:\"attribute_label\";s:4:\"Size\";s:14:\"attribute_type\";s:6:\"select\";s:17:\"attribute_orderby\";s:10:\"menu_order\";s:16:\"attribute_public\";s:1:\"0\";}}","yes");
INSERT INTO `wp_options` VALUES("1319","woocommerce_version","3.8.1","yes");
INSERT INTO `wp_options` VALUES("1320","woocommerce_db_version","3.8.1","yes");
INSERT INTO `wp_options` VALUES("2078","_transient_shipping-transient-version","1577227543","yes");
INSERT INTO `wp_options` VALUES("2079","_transient_timeout_wc_shipping_method_count","1579819543","no");
INSERT INTO `wp_options` VALUES("2080","_transient_wc_shipping_method_count","a:2:{s:7:\"version\";s:10:\"1577227543\";s:5:\"value\";i:0;}","no");
INSERT INTO `wp_options` VALUES("2088","_transient_timeout_wc_addons_sections","1577832421","no");
INSERT INTO `wp_options` VALUES("2089","_transient_wc_addons_sections","a:9:{i:0;O:8:\"stdClass\":2:{s:4:\"slug\";s:9:\"_featured\";s:5:\"label\";s:8:\"Featured\";}i:1;O:8:\"stdClass\":2:{s:4:\"slug\";s:4:\"_all\";s:5:\"label\";s:3:\"All\";}i:2;O:8:\"stdClass\":2:{s:4:\"slug\";s:18:\"product-extensions\";s:5:\"label\";s:12:\"Enhancements\";}i:3;O:8:\"stdClass\":2:{s:4:\"slug\";s:15:\"free-extensions\";s:5:\"label\";s:4:\"Free\";}i:4;O:8:\"stdClass\":2:{s:4:\"slug\";s:20:\"marketing-extensions\";s:5:\"label\";s:9:\"Marketing\";}i:5;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"payment-gateways\";s:5:\"label\";s:8:\"Payments\";}i:6;O:8:\"stdClass\":2:{s:4:\"slug\";s:12:\"product-type\";s:5:\"label\";s:12:\"Product Type\";}i:7;O:8:\"stdClass\":2:{s:4:\"slug\";s:16:\"shipping-methods\";s:5:\"label\";s:8:\"Shipping\";}i:8;O:8:\"stdClass\":2:{s:4:\"slug\";s:10:\"operations\";s:5:\"label\";s:16:\"Store Management\";}}","no");
INSERT INTO `wp_options` VALUES("2090","_transient_timeout_wc_addons_featured","1577832421","no");
INSERT INTO `wp_options` VALUES("2091","_transient_wc_addons_featured","O:8:\"stdClass\":1:{s:8:\"sections\";a:11:{i:0;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:50:\"Take your store beyond the typical - sell anything\";s:11:\"description\";s:81:\"From services to content, there\'s no limit to what you can sell with WooCommerce.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:128:\"https://woocommerce.com/products/woocommerce-subscriptions/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Subscriptions\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/subscriptions-icon@2x.png\";s:11:\"description\";s:98:\"Let customers subscribe to your products or services and pay on a weekly, monthly or annual basis.\";s:6:\"button\";s:10:\"From: $199\";s:6:\"plugin\";s:55:\"woocommerce-subscriptions/woocommerce-subscriptions.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:123:\"https://woocommerce.com/products/woocommerce-bookings/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:8:\"Bookings\";s:5:\"image\";s:66:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/bookings-icon@2x.png\";s:11:\"description\";s:76:\"Allow customers to book appointments for services without leaving your site.\";s:6:\"button\";s:10:\"From: $249\";s:6:\"plugin\";s:45:\"woocommerce-bookings/woocommerce-bookings.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/woocommerce-memberships/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:11:\"Memberships\";s:5:\"image\";s:69:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/memberships-icon@2x.png\";s:11:\"description\";s:76:\"Give members access to restricted content or products, for a fee or for free\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:51:\"woocommerce-memberships/woocommerce-memberships.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-bundles/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Bundles\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:50:\"Offer customizable bundles and assembled products.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:59:\"woocommerce-product-bundles/woocommerce-product-bundles.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:121:\"https://woocommerce.com/products/composite-products/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:18:\"Composite Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:59:\"Create and offer product kits with configurable components.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:65:\"woocommerce-composite-products/woocommerce-composite-products.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-vendors/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Vendors\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:47:\"Turn your store into a multi-vendor marketplace\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:59:\"woocommerce-product-vendors/woocommerce-product-vendors.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:121:\"https://woocommerce.com/products/groups-woocommerce/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:22:\"Groups for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:94:\"Sell memberships using the free &#039;Groups&#039; plugin, Groups integration and WooCommerce.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:41:\"groups-woocommerce/groups-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:125:\"https://woocommerce.com/products/woocommerce-pre-orders/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:22:\"WooCommerce Pre-Orders\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:60:\"Allow customers to order products before they are available.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:49:\"woocommerce-pre-orders/woocommerce-pre-orders.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:119:\"https://woocommerce.com/products/chained-products/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Chained Products\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:69:\"Create and sell pre-configured product bundles and discounted combos.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-chained-products/woocommerce-chained-products.php\";}}}i:1;O:8:\"stdClass\":1:{s:6:\"module\";s:16:\"wcs_banner_block\";}i:2;O:8:\"stdClass\":2:{s:6:\"module\";s:12:\"column_start\";s:9:\"container\";s:22:\"column_container_start\";}i:3;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:46:\"Improve the main features of your online store\";s:11:\"description\";s:71:\"Sell more by helping customers find the products and options they want.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/product-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Product Add-ons\";s:5:\"image\";s:73:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-add-ons-icon@2x.png\";s:11:\"description\";s:82:\"Give your customers the option to customize their purchase or add personalization.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-addons/woocommerce-product-addons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:129:\"https://woocommerce.com/products/woocommerce-product-search/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:14:\"Product Search\";s:5:\"image\";s:72:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/product-search-icon@2x.png\";s:11:\"description\";s:67:\"Make sure customers find what they want when they search your site.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:57:\"woocommerce-product-search/woocommerce-product-search.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-checkout-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Checkout Add-ons\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/checkout-add-ons-icon@2x.png\";s:11:\"description\";s:89:\"Highlight relevant products, offers like free shipping and other upsells during checkout.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:61:\"woocommerce-checkout-add-ons/woocommerce-checkout-add-ons.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:136:\"https://woocommerce.com/products/woocommerce-checkout-field-editor/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:21:\"Checkout Field Editor\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:128:\"The checkout field editor provides you with an interface to add, edit and remove fields shown on your WooCommerce checkout page.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:71:\"woocommerce-checkout-field-editor/woocommerce-checkout-field-editor.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:127:\"https://woocommerce.com/products/woocommerce-social-login/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"WooCommerce Social Login\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:62:\"Enable Social Login for Seamless Checkout and Account Creation\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-social-login/woocommerce-social-login.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:124:\"https://woocommerce.com/products/woocommerce-wishlists/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:21:\"WooCommerce Wishlists\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:113:\"WooCommerce Wishlists allows guests and customers to create and add products to an unlimited number of Wishlists.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:47:\"woocommerce-wishlists/woocommerce-wishlists.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/cart-notices/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart Notices\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:73:\"Display dynamic, actionable messages to your customers as they check out.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:53:\"woocommerce-cart-notices/woocommerce-cart-notices.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/cart-add-ons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart Add-ons\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:109:\"A powerful tool for driving incremental and impulse purchases by customers once they are in the shopping cart\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-cart-add-ons/woocommerce-cart-add-ons.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:123:\"https://woocommerce.com/products/woocommerce-waitlist/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:20:\"WooCommerce Waitlist\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:117:\"With WooCommerce Waitlist customers can register for email notifications when out-of-stock products become available.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:45:\"woocommerce-waitlist/woocommerce-waitlist.php\";}}}i:4;O:8:\"stdClass\":5:{s:6:\"module\";s:17:\"small_light_block\";s:5:\"title\";s:34:\"Get the official WooCommerce theme\";s:11:\"description\";s:128:\"Storefront is the lean, flexible, and free theme, built by the people who make WooCommerce - everything you need to get started.\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/storefront-screen@2x.png\";s:7:\"buttons\";a:2:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:44:\"/wp-admin/theme-install.php?theme=storefront\";s:4:\"text\";s:7:\"Install\";}i:1;O:8:\"stdClass\":2:{s:4:\"href\";s:104:\"https://woocommerce.com/storefront/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:4:\"text\";s:9:\"Read More\";}}}i:5;O:8:\"stdClass\":1:{s:6:\"module\";s:10:\"column_end\";}i:6;O:8:\"stdClass\":1:{s:6:\"module\";s:12:\"column_start\";}i:7;O:8:\"stdClass\":4:{s:6:\"module\";s:16:\"small_dark_block\";s:5:\"title\";s:20:\"WooCommerce + Zapier\";s:11:\"description\";s:88:\"Save time and increase productivity by connecting your store to more than 1000+ services\";s:5:\"items\";a:1:{i:0;O:8:\"stdClass\":2:{s:4:\"href\";s:121:\"https://woocommerce.com/products/woocommerce-zapier/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:6:\"button\";s:9:\"From: $59\";}}}i:8;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"column_block\";s:5:\"title\";s:19:\"Get deeper insights\";s:11:\"description\";s:58:\"Learn how your store is performing with enhanced reporting\";s:5:\"items\";a:8:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-google-analytics/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Google Analytics\";s:5:\"image\";s:60:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/ga-icon@2x.png\";s:11:\"description\";s:93:\"Understand your customers and increase revenue with the world’s leading analytics platform.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:85:\"woocommerce-google-analytics-integration/woocommerce-google-analytics-integration.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:127:\"https://woocommerce.com/products/woocommerce-cart-reports/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:12:\"Cart reports\";s:5:\"image\";s:70:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cart-reports-icon@2x.png\";s:11:\"description\";s:66:\"Get real-time reports on what customers are leaving in their cart.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:53:\"woocommerce-cart-reports/woocommerce-cart-reports.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:128:\"https://woocommerce.com/products/woocommerce-cost-of-goods/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Cost of Goods\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/cost-of-goods-icon@2x.png\";s:11:\"description\";s:64:\"Easily track profit by including  cost of goods in your reports.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:55:\"woocommerce-cost-of-goods/woocommerce-cost-of-goods.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:135:\"https://woocommerce.com/products/woocommerce-google-analytics-pro/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:32:\"WooCommerce Google Analytics Pro\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:85:\"Add advanced event tracking and enhanced eCommerce tracking to your WooCommerce site.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:69:\"woocommerce-google-analytics-pro/woocommerce-google-analytics-pro.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-customer-history/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:28:\"WooCommerce Customer History\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Observe how your customers use your store, keep a full purchase history log, and calculate the total customer lifetime value.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:61:\"woocommerce-customer-history/woocommerce-customer-history.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/kiss-metrics/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:11:\"Kissmetrics\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:79:\"Easily add Kissmetrics event tracking to your WooCommerce store with one click.\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:52:\"woocommerce-kiss-metrics/woocommerce-kissmetrics.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:111:\"https://woocommerce.com/products/mixpanel/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:8:\"Mixpanel\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:65:\"Add event tracking powered by Mixpanel to your WooCommerce store.\";s:6:\"button\";s:10:\"From: $149\";s:6:\"plugin\";s:45:\"woocommerce-mixpanel/woocommerce-mixpanel.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:133:\"https://woocommerce.com/products/woocommerce-sales-report-email/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:30:\"WooCommerce Sales Report Email\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:107:\"Receive emails daily, weekly or monthly with meaningful information about how your products are performing.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:65:\"woocommerce-sales-report-email/woocommerce-sales-report-email.php\";}}}i:9;O:8:\"stdClass\":2:{s:6:\"module\";s:10:\"column_end\";s:9:\"container\";s:20:\"column_container_end\";}i:10;O:8:\"stdClass\":4:{s:6:\"module\";s:12:\"banner_block\";s:5:\"title\";s:40:\"Promote your products and increase sales\";s:11:\"description\";s:77:\"From coupons to emails, these extensions can power up your marketing efforts.\";s:5:\"items\";a:9:{i:0;O:8:\"stdClass\":6:{s:4:\"href\";s:116:\"https://woocommerce.com/products/smart-coupons/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:13:\"Smart Coupons\";s:5:\"image\";s:71:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/smart-coupons-icon@2x.png\";s:11:\"description\";s:106:\"Enhance your coupon options - create gift certificates, store credit, coupons based on purchases and more.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:55:\"woocommerce-smart-coupons/woocommerce-smart-coupons.php\";}i:1;O:8:\"stdClass\":6:{s:4:\"href\";s:119:\"https://woocommerce.com/products/follow-up-emails/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:16:\"Follow Up Emails\";s:5:\"image\";s:74:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/follow-up-emails-icon@2x.png\";s:11:\"description\";s:140:\"Automatically contact customers after purchase - be it everyone, your most loyal or your biggest spenders - and keep your store top-of-mind.\";s:6:\"button\";s:9:\"From: $99\";s:6:\"plugin\";s:61:\"woocommerce-follow-up-emails/woocommerce-follow-up-emails.php\";}i:2;O:8:\"stdClass\":6:{s:4:\"href\";s:122:\"https://woocommerce.com/products/google-product-feed/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:19:\"Google Product Feed\";s:5:\"image\";s:77:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/google-product-feed-icon@2x.png\";s:11:\"description\";s:61:\"Let customers find you when shopping for products via Google.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:45:\"woocommerce-product-feeds/woocommerce-gpf.php\";}i:3;O:8:\"stdClass\":6:{s:4:\"href\";s:118:\"https://woocommerce.com/products/dynamic-pricing/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:15:\"Dynamic Pricing\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:48:\"Bulk discounts, role-based pricing and much more\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:59:\"woocommerce-dynamic-pricing/woocommerce-dynamic-pricing.php\";}i:4;O:8:\"stdClass\":6:{s:4:\"href\";s:133:\"https://woocommerce.com/products/woocommerce-points-and-rewards/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:30:\"WooCommerce Points and Rewards\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:102:\"Reward your customers for purchases and other actions with points which can be redeemed for discounts.\";s:6:\"button\";s:10:\"From: $129\";s:6:\"plugin\";s:65:\"woocommerce-points-and-rewards/woocommerce-points-and-rewards.php\";}i:5;O:8:\"stdClass\":6:{s:4:\"href\";s:115:\"https://woocommerce.com/products/store-credit/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"WooCommerce Store Credit\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:152:\"Generate store credit coupons that enable customers to make multiple purchases until the total value specified is exhausted or the coupons life expires.\";s:6:\"button\";s:9:\"From: $29\";s:6:\"plugin\";s:53:\"woocommerce-store-credit/woocommerce-store-credit.php\";}i:6;O:8:\"stdClass\":6:{s:4:\"href\";s:111:\"https://woocommerce.com/products/facebook/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:24:\"Facebook for WooCommerce\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:89:\"Get the Facebook for WooCommerce plugin for two powerful ways to help grow your business.\";s:6:\"button\";s:4:\"Free\";s:6:\"plugin\";s:53:\"facebook-for-woocommerce/facebook-for-woocommerce.php\";}i:7;O:8:\"stdClass\":6:{s:4:\"href\";s:126:\"https://woocommerce.com/products/newsletter-subscription/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:23:\"Newsletter Subscription\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:127:\"Allow customers to subscribe to your MailChimp or CampaignMonitor mailing list(s) via a widget or by opting in during checkout.\";s:6:\"button\";s:9:\"From: $49\";s:6:\"plugin\";s:63:\"woocommerce-subscribe-to-newsletter/subscribe-to-newsletter.php\";}i:8;O:8:\"stdClass\":6:{s:4:\"href\";s:131:\"https://woocommerce.com/products/woocommerce-email-customizer/?utm_source=extensionsscreen&utm_medium=product&utm_campaign=wcaddons\";s:5:\"title\";s:28:\"WooCommerce Email Customizer\";s:5:\"image\";s:57:\"https://d3t0oesq8995hv.cloudfront.net/add-ons/generic.png\";s:11:\"description\";s:125:\"Connect with your customers with each email you send by visually modifying your email templates via the WordPress Customizer.\";s:6:\"button\";s:9:\"From: $79\";s:6:\"plugin\";s:61:\"woocommerce-email-customizer/woocommerce-email-customizer.php\";}}}}}","no");
INSERT INTO `wp_options` VALUES("2310","_site_transient_timeout_browser_8270b176b8adf5164bf2d08d8d8b4709","1577940139","no");
INSERT INTO `wp_options` VALUES("2311","_site_transient_browser_8270b176b8adf5164bf2d08d8d8b4709","a:10:{s:4:\"name\";s:5:\"Opera\";s:7:\"version\";s:12:\"65.0.3467.69\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:22:\"https://www.opera.com/\";s:7:\"img_src\";s:42:\"http://s.w.org/images/browsers/opera.png?1\";s:11:\"img_src_ssl\";s:43:\"https://s.w.org/images/browsers/opera.png?1\";s:15:\"current_version\";s:5:\"12.18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("2312","_site_transient_timeout_php_check_4a92d092353000abbac8f8457be4571f","1577940140","no");
INSERT INTO `wp_options` VALUES("2313","_site_transient_php_check_4a92d092353000abbac8f8457be4571f","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("2335","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:5:\"trash\";s:1:\"1\";s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("2336","_transient_as_comment_count","O:8:\"stdClass\":7:{s:5:\"trash\";s:1:\"1\";s:14:\"total_comments\";i:0;s:3:\"all\";i:0;s:9:\"moderated\";i:0;s:8:\"approved\";i:0;s:4:\"spam\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("2422","product_cat_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("2483","woocommerce_checkout_company_field","hidden","yes");
INSERT INTO `wp_options` VALUES("2484","woocommerce_checkout_address_2_field","hidden","yes");
INSERT INTO `wp_options` VALUES("2485","woocommerce_checkout_phone_field","hidden","yes");
INSERT INTO `wp_options` VALUES("2486","_transient_timeout_wc_shipping_method_count_legacy","1579985776","no");
INSERT INTO `wp_options` VALUES("2487","_transient_wc_shipping_method_count_legacy","a:2:{s:7:\"version\";s:10:\"1577227543\";s:5:\"value\";i:0;}","no");
INSERT INTO `wp_options` VALUES("3715","_transient_timeout_users_online","1577804585","no");
INSERT INTO `wp_options` VALUES("3716","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1577813585;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");
INSERT INTO `wp_options` VALUES("3803","_transient_timeout_aiowps_captcha_string_info_i17w4cowig","1577805189","no");
INSERT INTO `wp_options` VALUES("3804","_transient_aiowps_captcha_string_info_i17w4cowig","MTU3NzgwMzM4OWFldzJ6aHk2MG8xbGJjaTBmcnZkOQ==","no");
INSERT INTO `wp_options` VALUES("3806","_transient_timeout__woocommerce_helper_subscriptions","1577804294","no");
INSERT INTO `wp_options` VALUES("3807","_transient__woocommerce_helper_subscriptions","a:0:{}","no");
INSERT INTO `wp_options` VALUES("3808","_site_transient_timeout_theme_roots","1577805194","no");
INSERT INTO `wp_options` VALUES("3809","_site_transient_theme_roots","a:4:{s:8:\"dimtepla\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("3810","_transient_timeout__woocommerce_helper_updates","1577846594","no");
INSERT INTO `wp_options` VALUES("3811","_transient__woocommerce_helper_updates","a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1577803394;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}","no");
INSERT INTO `wp_options` VALUES("3812","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.3.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1577803396;s:15:\"version_checked\";s:5:\"5.3.2\";s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:4:\"core\";s:4:\"slug\";s:7:\"default\";s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.3.2\";s:7:\"updated\";s:19:\"2019-12-30 14:10:55\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.2/ru_RU.zip\";s:10:\"autoupdate\";b:1;}}}","no");
INSERT INTO `wp_options` VALUES("3813","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1577803397;s:7:\"checked\";a:4:{s:8:\"dimtepla\";s:5:\"1.0.0\";s:14:\"twentynineteen\";s:3:\"1.4\";s:15:\"twentyseventeen\";s:3:\"2.2\";s:12:\"twentytwenty\";s:3:\"1.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("3814","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1577803398;s:7:\"checked\";a:6:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.2\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.5\";s:21:\"imsanity/imsanity.php\";s:5:\"2.5.0\";s:31:\"query-monitor/query-monitor.php\";s:5:\"3.5.2\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.8.1\";s:24:\"wordpress-seo/wp-seo.php\";s:6:\"12.7.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:13:\"wordpress-seo\";s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:6:\"12.7.1\";s:7:\"updated\";s:19:\"2019-12-29 23:19:27\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/wordpress-seo/12.7.1/ru_RU.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:6:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.5.0\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/imsanity.2.5.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=1094749\";s:2:\"1x\";s:61:\"https://ps.w.org/imsanity/assets/icon-128x128.png?rev=1170755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=900541\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:5:\"3.5.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/query-monitor.3.5.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2056073\";s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=1731469\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.8.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.8.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2075035\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2075035\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2075035\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2075035\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"12.7.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.12.7.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `wp_options` VALUES("3817","_transient_timeout_external_ip_address_127.0.0.1","1578416009","no");
INSERT INTO `wp_options` VALUES("3818","_transient_external_ip_address_127.0.0.1","93.78.11.154","no");
INSERT INTO `wp_options` VALUES("3819","_transient_doing_cron","1577811209.2671129703521728515625","yes");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1010 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("16","11","_wp_attached_file","woocommerce-placeholder.png");
INSERT INTO `wp_postmeta` VALUES("17","11","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:7:{s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("18","16","_wp_attached_file","2019/12/logo.png");
INSERT INTO `wp_postmeta` VALUES("19","16","_wp_attachment_metadata","a:5:{s:5:\"width\";i:426;s:6:\"height\";i:155;s:4:\"file\";s:16:\"2019/12/logo.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"logo-300x109.png\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:16:\"logo-300x155.png\";s:5:\"width\";i:300;s:6:\"height\";i:155;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:16:\"logo-300x155.png\";s:5:\"width\";i:300;s:6:\"height\";i:155;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("447","43","_wp_attached_file","2019/12/vneck-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("448","43","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:23:\"2019/12/vneck-tee-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:23:\"vneck-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("449","43","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vneck-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("450","44","_wp_attached_file","2019/12/vnech-tee-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("451","44","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:29:\"2019/12/vnech-tee-green-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"vnech-tee-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("452","44","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("453","45","_wp_attached_file","2019/12/vnech-tee-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("454","45","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:28:\"2019/12/vnech-tee-blue-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:28:\"vnech-tee-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("455","45","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/vnech-tee-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("461","46","_wp_attached_file","2019/12/hoodie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("462","46","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/12/hoodie-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"hoodie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"hoodie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"hoodie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"hoodie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("463","46","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("464","47","_wp_attached_file","2019/12/hoodie-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("465","47","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:25:\"2019/12/hoodie-blue-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:25:\"hoodie-blue-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("466","47","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-blue-1.jpg");
INSERT INTO `wp_postmeta` VALUES("467","48","_wp_attached_file","2019/12/hoodie-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("468","48","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:26:\"2019/12/hoodie-green-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:26:\"hoodie-green-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("469","48","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-green-1.jpg");
INSERT INTO `wp_postmeta` VALUES("470","49","_wp_attached_file","2019/12/hoodie-with-logo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("471","49","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:30:\"2019/12/hoodie-with-logo-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"hoodie-with-logo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("472","49","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-logo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("484","50","_wp_attached_file","2019/12/tshirt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("485","50","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/12/tshirt-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"tshirt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"tshirt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"tshirt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"tshirt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("486","50","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/tshirt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("493","51","_wp_attached_file","2019/12/beanie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("494","51","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:20:\"2019/12/beanie-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"beanie-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"beanie-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"beanie-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"beanie-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("495","51","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-2.jpg");
INSERT INTO `wp_postmeta` VALUES("503","52","_wp_attached_file","2019/12/belt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("504","52","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:18:\"2019/12/belt-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"belt-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"belt-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"belt-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"belt-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("505","52","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/belt-2.jpg");
INSERT INTO `wp_postmeta` VALUES("512","53","_wp_attached_file","2019/12/cap-2.jpg");
INSERT INTO `wp_postmeta` VALUES("513","53","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:17:\"2019/12/cap-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:17:\"cap-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"cap-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:17:\"cap-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"cap-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("514","53","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/cap-2.jpg");
INSERT INTO `wp_postmeta` VALUES("522","54","_wp_attached_file","2019/12/sunglasses-2.jpg");
INSERT INTO `wp_postmeta` VALUES("523","54","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:24:\"2019/12/sunglasses-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:24:\"sunglasses-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("524","54","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/sunglasses-2.jpg");
INSERT INTO `wp_postmeta` VALUES("530","55","_wp_attached_file","2019/12/hoodie-with-pocket-2.jpg");
INSERT INTO `wp_postmeta` VALUES("531","55","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:32:\"2019/12/hoodie-with-pocket-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-pocket-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("532","55","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-pocket-2.jpg");
INSERT INTO `wp_postmeta` VALUES("540","56","_wp_attached_file","2019/12/hoodie-with-zipper-2.jpg");
INSERT INTO `wp_postmeta` VALUES("541","56","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:32:\"2019/12/hoodie-with-zipper-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:32:\"hoodie-with-zipper-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("542","56","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/hoodie-with-zipper-2.jpg");
INSERT INTO `wp_postmeta` VALUES("548","57","_wp_attached_file","2019/12/long-sleeve-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("549","57","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:801;s:4:\"file\";s:29:\"2019/12/long-sleeve-tee-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:29:\"long-sleeve-tee-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("550","57","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/long-sleeve-tee-2.jpg");
INSERT INTO `wp_postmeta` VALUES("557","58","_wp_attached_file","2019/12/polo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("558","58","_wp_attachment_metadata","a:5:{s:5:\"width\";i:801;s:6:\"height\";i:800;s:4:\"file\";s:18:\"2019/12/polo-2.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"polo-2-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"polo-2-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"polo-2-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"polo-2-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("559","58","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/polo-2.jpg");
INSERT INTO `wp_postmeta` VALUES("566","59","_wp_attached_file","2019/12/album-1.jpg");
INSERT INTO `wp_postmeta` VALUES("567","59","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:19:\"2019/12/album-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"album-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:19:\"album-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:19:\"album-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:19:\"album-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("568","59","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/album-1.jpg");
INSERT INTO `wp_postmeta` VALUES("575","60","_wp_attached_file","2019/12/single-1.jpg");
INSERT INTO `wp_postmeta` VALUES("576","60","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:20:\"2019/12/single-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"single-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:20:\"single-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:20:\"single-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:20:\"single-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("577","60","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/single-1.jpg");
INSERT INTO `wp_postmeta` VALUES("634","61","_wp_attached_file","2019/12/t-shirt-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("635","61","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:31:\"2019/12/t-shirt-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:31:\"t-shirt-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("636","61","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/t-shirt-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("647","62","_wp_attached_file","2019/12/beanie-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("648","62","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:30:\"2019/12/beanie-with-logo-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:30:\"beanie-with-logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("649","62","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/beanie-with-logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("657","63","_wp_attached_file","2019/12/logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("658","63","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:799;s:4:\"file\";s:18:\"2019/12/logo-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"logo-1-768x767.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:767;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"logo-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"logo-1-600x599.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:599;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"logo-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("659","63","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/logo-1.jpg");
INSERT INTO `wp_postmeta` VALUES("667","64","_wp_attached_file","2019/12/pennant-1.jpg");
INSERT INTO `wp_postmeta` VALUES("668","64","_wp_attachment_metadata","a:5:{s:5:\"width\";i:800;s:6:\"height\";i:800;s:4:\"file\";s:21:\"2019/12/pennant-1.jpg\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:21:\"pennant-1-768x768.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:21:\"pennant-1-300x300.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:21:\"pennant-1-600x600.jpg\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:21:\"pennant-1-100x100.jpg\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("669","64","_wc_attachment_source","https://woocommercecore.mystagingwebsite.com/wp-content/uploads/2017/12/pennant-1.jpg");
INSERT INTO `wp_postmeta` VALUES("689","66","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("690","66","_wp_trash_meta_time","1577079550");
INSERT INTO `wp_postmeta` VALUES("710","115","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("711","115","_edit_lock","1577236750:1");
INSERT INTO `wp_postmeta` VALUES("735","13","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("736","13","_wp_trash_meta_time","1577335350");
INSERT INTO `wp_postmeta` VALUES("737","13","_wp_desired_post_slug","cart");
INSERT INTO `wp_postmeta` VALUES("738","12","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("739","12","_wp_trash_meta_time","1577335353");
INSERT INTO `wp_postmeta` VALUES("740","12","_wp_desired_post_slug","shop");
INSERT INTO `wp_postmeta` VALUES("741","15","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("742","15","_wp_trash_meta_time","1577335356");
INSERT INTO `wp_postmeta` VALUES("743","15","_wp_desired_post_slug","my-account");
INSERT INTO `wp_postmeta` VALUES("744","14","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("745","14","_wp_trash_meta_time","1577335359");
INSERT INTO `wp_postmeta` VALUES("746","14","_wp_desired_post_slug","checkout");
INSERT INTO `wp_postmeta` VALUES("747","3","_wp_trash_meta_status","draft");
INSERT INTO `wp_postmeta` VALUES("748","3","_wp_trash_meta_time","1577335365");
INSERT INTO `wp_postmeta` VALUES("749","3","_wp_desired_post_slug","privacy-policy");
INSERT INTO `wp_postmeta` VALUES("750","1","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("751","1","_wp_trash_meta_time","1577335407");
INSERT INTO `wp_postmeta` VALUES("752","1","_wp_desired_post_slug","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80");
INSERT INTO `wp_postmeta` VALUES("753","1","_wp_trash_meta_comments_status","a:1:{i:1;s:5:\"trash\";}");
INSERT INTO `wp_postmeta` VALUES("834","127","_wp_attached_file","2019/12/kotl1.png");
INSERT INTO `wp_postmeta` VALUES("835","127","_wp_attachment_metadata","a:5:{s:5:\"width\";i:467;s:6:\"height\";i:623;s:4:\"file\";s:17:\"2019/12/kotl1.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:17:\"kotl1-225x300.png\";s:5:\"width\";i:225;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:17:\"kotl1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:17:\"kotl1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:17:\"kotl1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:17:\"kotl1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:17:\"kotl1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("836","128","_wp_attached_file","2019/12/image1.png");
INSERT INTO `wp_postmeta` VALUES("837","128","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:4:\"file\";s:18:\"2019/12/image1.png\";s:5:\"sizes\";a:9:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"image1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"image1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"image1-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"image1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:18:\"woocommerce_single\";a:4:{s:4:\"file\";s:18:\"image1-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"image1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"image1-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:11:\"shop_single\";a:4:{s:4:\"file\";s:18:\"image1-600x600.png\";s:5:\"width\";i:600;s:6:\"height\";i:600;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"image1-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("857","117","_customize_restore_dismissed","1");
INSERT INTO `wp_postmeta` VALUES("858","130","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("859","130","_wp_trash_meta_time","1577393759");
INSERT INTO `wp_postmeta` VALUES("860","131","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("861","131","_edit_lock","1577396776:1");
INSERT INTO `wp_postmeta` VALUES("862","131","_thumbnail_id","128");
INSERT INTO `wp_postmeta` VALUES("863","131","custom_test","zxccvbbnnmnmu");
INSERT INTO `wp_postmeta` VALUES("864","131","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("865","131","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("866","131","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("867","131","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("868","131","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("869","131","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("870","131","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("871","131","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("872","131","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("873","131","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("874","131","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("875","131","_stock","");
INSERT INTO `wp_postmeta` VALUES("876","131","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("877","131","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("878","131","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("879","131","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("880","131","_price","2800");
INSERT INTO `wp_postmeta` VALUES("881","132","_wp_attached_file","2019/12/image2.png");
INSERT INTO `wp_postmeta` VALUES("882","132","_wp_attachment_metadata","a:5:{s:5:\"width\";i:600;s:6:\"height\";i:600;s:4:\"file\";s:18:\"2019/12/image2.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"image2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:18:\"image2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:18:\"image2-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"image2-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("883","133","_wp_attached_file","2019/12/image3.png");
INSERT INTO `wp_postmeta` VALUES("884","133","_wp_attachment_metadata","a:5:{s:5:\"width\";i:258;s:6:\"height\";i:257;s:4:\"file\";s:18:\"2019/12/image3.png\";s:5:\"sizes\";a:3:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"image3-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:18:\"image3-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:18:\"image3-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("885","134","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("886","134","_edit_lock","1577396799:1");
INSERT INTO `wp_postmeta` VALUES("887","134","_thumbnail_id","132");
INSERT INTO `wp_postmeta` VALUES("888","134","custom_test","qweeeeee");
INSERT INTO `wp_postmeta` VALUES("889","134","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("890","134","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("891","134","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("892","134","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("893","134","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("894","134","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("895","134","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("896","134","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("897","134","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("898","134","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("899","134","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("900","134","_stock","");
INSERT INTO `wp_postmeta` VALUES("901","134","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("902","134","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("903","134","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("904","134","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("905","134","_price","2800");
INSERT INTO `wp_postmeta` VALUES("906","135","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("907","135","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("908","135","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("909","135","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("910","135","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("911","135","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("912","135","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("913","135","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("914","135","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("915","135","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("916","135","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("917","135","_thumbnail_id","132");
INSERT INTO `wp_postmeta` VALUES("918","135","_stock","");
INSERT INTO `wp_postmeta` VALUES("919","135","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("920","135","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("921","135","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("922","135","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("923","135","_price","2800");
INSERT INTO `wp_postmeta` VALUES("924","135","custom_test","asdfg");
INSERT INTO `wp_postmeta` VALUES("925","135","_edit_lock","1577396822:1");
INSERT INTO `wp_postmeta` VALUES("926","135","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("927","136","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("928","136","_edit_lock","1577396845:1");
INSERT INTO `wp_postmeta` VALUES("929","136","_thumbnail_id","133");
INSERT INTO `wp_postmeta` VALUES("930","136","custom_test","zxccvbbnnm");
INSERT INTO `wp_postmeta` VALUES("931","136","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("932","136","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("933","136","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("934","136","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("935","136","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("936","136","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("937","136","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("938","136","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("939","136","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("940","136","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("941","136","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("942","136","_stock","");
INSERT INTO `wp_postmeta` VALUES("943","136","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("944","136","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("945","136","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("946","136","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("947","136","_price","2800");
INSERT INTO `wp_postmeta` VALUES("948","137","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("949","137","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("950","137","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("951","137","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("952","137","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("953","137","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("954","137","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("955","137","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("956","137","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("957","137","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("958","137","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("959","137","_thumbnail_id","133");
INSERT INTO `wp_postmeta` VALUES("960","137","_stock","");
INSERT INTO `wp_postmeta` VALUES("961","137","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("962","137","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("963","137","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("964","137","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("965","137","_price","2800");
INSERT INTO `wp_postmeta` VALUES("966","137","custom_test","rtyuioop");
INSERT INTO `wp_postmeta` VALUES("967","137","_edit_lock","1577397498:1");
INSERT INTO `wp_postmeta` VALUES("968","137","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("972","138","_regular_price","2800");
INSERT INTO `wp_postmeta` VALUES("973","138","total_sales","0");
INSERT INTO `wp_postmeta` VALUES("974","138","_tax_status","taxable");
INSERT INTO `wp_postmeta` VALUES("975","138","_tax_class","");
INSERT INTO `wp_postmeta` VALUES("976","138","_manage_stock","no");
INSERT INTO `wp_postmeta` VALUES("977","138","_backorders","no");
INSERT INTO `wp_postmeta` VALUES("978","138","_sold_individually","no");
INSERT INTO `wp_postmeta` VALUES("979","138","_virtual","no");
INSERT INTO `wp_postmeta` VALUES("980","138","_downloadable","no");
INSERT INTO `wp_postmeta` VALUES("981","138","_download_limit","-1");
INSERT INTO `wp_postmeta` VALUES("982","138","_download_expiry","-1");
INSERT INTO `wp_postmeta` VALUES("983","138","_thumbnail_id","128");
INSERT INTO `wp_postmeta` VALUES("984","138","_stock","");
INSERT INTO `wp_postmeta` VALUES("985","138","_stock_status","instock");
INSERT INTO `wp_postmeta` VALUES("986","138","_wc_average_rating","0");
INSERT INTO `wp_postmeta` VALUES("987","138","_wc_review_count","0");
INSERT INTO `wp_postmeta` VALUES("988","138","_product_version","3.8.1");
INSERT INTO `wp_postmeta` VALUES("989","138","_price","2800");
INSERT INTO `wp_postmeta` VALUES("990","138","custom_test","zxccvbbnnmnmus");
INSERT INTO `wp_postmeta` VALUES("991","138","_edit_lock","1577796774:1");
INSERT INTO `wp_postmeta` VALUES("992","138","_edit_last","1");
INSERT INTO `wp_postmeta` VALUES("993","139","_wp_attached_file","2019/12/favicon.png");
INSERT INTO `wp_postmeta` VALUES("994","139","_wp_attachment_metadata","a:5:{s:5:\"width\";i:48;s:6:\"height\";i:48;s:4:\"file\";s:19:\"2019/12/favicon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("995","140","_wp_attached_file","2019/12/cropped-favicon.png");
INSERT INTO `wp_postmeta` VALUES("996","140","_wp_attachment_context","site-icon");
INSERT INTO `wp_postmeta` VALUES("997","140","_wp_attachment_metadata","a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:27:\"2019/12/cropped-favicon.png\";s:5:\"sizes\";a:10:{s:6:\"medium\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:21:\"woocommerce_thumbnail\";a:5:{s:4:\"file\";s:27:\"cropped-favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";s:9:\"uncropped\";b:0;}s:29:\"woocommerce_gallery_thumbnail\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"shop_catalog\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:14:\"shop_thumbnail\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-100x100.png\";s:5:\"width\";i:100;s:6:\"height\";i:100;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:27:\"cropped-favicon-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:25:\"cropped-favicon-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("998","141","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("999","141","_wp_trash_meta_time","1577601848");
INSERT INTO `wp_postmeta` VALUES("1000","139","_edit_lock","1577601750:1");
INSERT INTO `wp_postmeta` VALUES("1001","2","_edit_lock","1577601777:1");
INSERT INTO `wp_postmeta` VALUES("1002","2","_wp_trash_meta_status","publish");
INSERT INTO `wp_postmeta` VALUES("1003","2","_wp_trash_meta_time","1577601938");
INSERT INTO `wp_postmeta` VALUES("1004","2","_wp_desired_post_slug","sample-page");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES("1","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","trash","open","open","","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80__trashed","","","2019-12-26 07:43:27","2019-12-26 04:43:27","","0","http://dimtepla.com/?p=1","0","post","","0");
INSERT INTO `wp_posts` VALUES("2","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://dimtepla.com/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","trash","closed","open","","sample-page__trashed","","","2019-12-29 09:45:38","2019-12-29 06:45:38","","0","http://dimtepla.com/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://dimtepla.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","trash","closed","open","","privacy-policy__trashed","","","2019-12-26 07:42:45","2019-12-26 04:42:45","","0","http://dimtepla.com/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("11","1","2019-12-17 18:21:23","2019-12-17 15:21:23","","woocommerce-placeholder","","inherit","open","closed","","woocommerce-placeholder","","","2019-12-17 18:21:23","2019-12-17 15:21:23","","0","http://dimtepla.com/wp-content/uploads/2019/12/woocommerce-placeholder.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("12","1","2019-12-17 18:22:30","2019-12-17 15:22:30","","Магазин","","trash","closed","closed","","shop__trashed","","","2019-12-26 07:42:33","2019-12-26 04:42:33","","0","http://dimtepla.com/shop/","0","page","","0");
INSERT INTO `wp_posts` VALUES("13","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->","Корзина","","trash","closed","closed","","cart__trashed","","","2019-12-26 07:42:30","2019-12-26 04:42:30","","0","http://dimtepla.com/cart/","0","page","","0");
INSERT INTO `wp_posts` VALUES("14","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->","Оформление заказа","","trash","closed","closed","","checkout__trashed","","","2019-12-26 07:42:39","2019-12-26 04:42:39","","0","http://dimtepla.com/checkout/","0","page","","0");
INSERT INTO `wp_posts` VALUES("15","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->","Мой аккаунт","","trash","closed","closed","","my-account__trashed","","","2019-12-26 07:42:36","2019-12-26 04:42:36","","0","http://dimtepla.com/my-account/","0","page","","0");
INSERT INTO `wp_posts` VALUES("16","1","2019-12-22 07:50:18","2019-12-22 04:50:18","","logo","","inherit","open","closed","","logo","","","2019-12-22 07:50:18","2019-12-22 04:50:18","","0","http://dimtepla.com/wp-content/uploads/2019/12/logo.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("43","1","2019-12-22 23:55:57","2019-12-22 20:55:57","","vneck-tee-2.jpg","","inherit","open","closed","","vneck-tee-2-jpg","","","2019-12-22 23:55:57","2019-12-22 20:55:57","","0","http://dimtepla.com/wp-content/uploads/2019/12/vneck-tee-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("44","1","2019-12-22 23:55:58","2019-12-22 20:55:58","","vnech-tee-green-1.jpg","","inherit","open","closed","","vnech-tee-green-1-jpg","","","2019-12-22 23:55:58","2019-12-22 20:55:58","","0","http://dimtepla.com/wp-content/uploads/2019/12/vnech-tee-green-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("45","1","2019-12-22 23:55:59","2019-12-22 20:55:59","","vnech-tee-blue-1.jpg","","inherit","open","closed","","vnech-tee-blue-1-jpg","","","2019-12-22 23:55:59","2019-12-22 20:55:59","","0","http://dimtepla.com/wp-content/uploads/2019/12/vnech-tee-blue-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("46","1","2019-12-22 23:56:00","2019-12-22 20:56:00","","hoodie-2.jpg","","inherit","open","closed","","hoodie-2-jpg","","","2019-12-22 23:56:00","2019-12-22 20:56:00","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("47","1","2019-12-22 23:56:01","2019-12-22 20:56:01","","hoodie-blue-1.jpg","","inherit","open","closed","","hoodie-blue-1-jpg","","","2019-12-22 23:56:01","2019-12-22 20:56:01","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-blue-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("48","1","2019-12-22 23:56:02","2019-12-22 20:56:02","","hoodie-green-1.jpg","","inherit","open","closed","","hoodie-green-1-jpg","","","2019-12-22 23:56:02","2019-12-22 20:56:02","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-green-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("49","1","2019-12-22 23:56:03","2019-12-22 20:56:03","","hoodie-with-logo-2.jpg","","inherit","open","closed","","hoodie-with-logo-2-jpg","","","2019-12-22 23:56:03","2019-12-22 20:56:03","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-with-logo-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("50","1","2019-12-22 23:56:04","2019-12-22 20:56:04","","tshirt-2.jpg","","inherit","open","closed","","tshirt-2-jpg","","","2019-12-22 23:56:04","2019-12-22 20:56:04","","0","http://dimtepla.com/wp-content/uploads/2019/12/tshirt-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("51","1","2019-12-22 23:56:05","2019-12-22 20:56:05","","beanie-2.jpg","","inherit","open","closed","","beanie-2-jpg","","","2019-12-22 23:56:05","2019-12-22 20:56:05","","0","http://dimtepla.com/wp-content/uploads/2019/12/beanie-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("52","1","2019-12-22 23:56:06","2019-12-22 20:56:06","","belt-2.jpg","","inherit","open","closed","","belt-2-jpg","","","2019-12-22 23:56:06","2019-12-22 20:56:06","","0","http://dimtepla.com/wp-content/uploads/2019/12/belt-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("53","1","2019-12-22 23:56:07","2019-12-22 20:56:07","","cap-2.jpg","","inherit","open","closed","","cap-2-jpg","","","2019-12-22 23:56:07","2019-12-22 20:56:07","","0","http://dimtepla.com/wp-content/uploads/2019/12/cap-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("54","1","2019-12-22 23:56:08","2019-12-22 20:56:08","","sunglasses-2.jpg","","inherit","open","closed","","sunglasses-2-jpg","","","2019-12-22 23:56:08","2019-12-22 20:56:08","","0","http://dimtepla.com/wp-content/uploads/2019/12/sunglasses-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("55","1","2019-12-22 23:56:09","2019-12-22 20:56:09","","hoodie-with-pocket-2.jpg","","inherit","open","closed","","hoodie-with-pocket-2-jpg","","","2019-12-22 23:56:09","2019-12-22 20:56:09","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-with-pocket-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("56","1","2019-12-22 23:56:10","2019-12-22 20:56:10","","hoodie-with-zipper-2.jpg","","inherit","open","closed","","hoodie-with-zipper-2-jpg","","","2019-12-22 23:56:10","2019-12-22 20:56:10","","0","http://dimtepla.com/wp-content/uploads/2019/12/hoodie-with-zipper-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("57","1","2019-12-22 23:56:11","2019-12-22 20:56:11","","long-sleeve-tee-2.jpg","","inherit","open","closed","","long-sleeve-tee-2-jpg","","","2019-12-22 23:56:11","2019-12-22 20:56:11","","0","http://dimtepla.com/wp-content/uploads/2019/12/long-sleeve-tee-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("58","1","2019-12-22 23:56:12","2019-12-22 20:56:12","","polo-2.jpg","","inherit","open","closed","","polo-2-jpg","","","2019-12-22 23:56:12","2019-12-22 20:56:12","","0","http://dimtepla.com/wp-content/uploads/2019/12/polo-2.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("59","1","2019-12-22 23:56:13","2019-12-22 20:56:13","","album-1.jpg","","inherit","open","closed","","album-1-jpg","","","2019-12-22 23:56:13","2019-12-22 20:56:13","","0","http://dimtepla.com/wp-content/uploads/2019/12/album-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("60","1","2019-12-22 23:56:14","2019-12-22 20:56:14","","single-1.jpg","","inherit","open","closed","","single-1-jpg","","","2019-12-22 23:56:14","2019-12-22 20:56:14","","0","http://dimtepla.com/wp-content/uploads/2019/12/single-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("61","1","2019-12-22 23:56:15","2019-12-22 20:56:15","","t-shirt-with-logo-1.jpg","","inherit","open","closed","","t-shirt-with-logo-1-jpg","","","2019-12-22 23:56:15","2019-12-22 20:56:15","","0","http://dimtepla.com/wp-content/uploads/2019/12/t-shirt-with-logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("62","1","2019-12-22 23:56:17","2019-12-22 20:56:17","","beanie-with-logo-1.jpg","","inherit","open","closed","","beanie-with-logo-1-jpg","","","2019-12-22 23:56:17","2019-12-22 20:56:17","","0","http://dimtepla.com/wp-content/uploads/2019/12/beanie-with-logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("63","1","2019-12-22 23:56:18","2019-12-22 20:56:18","","logo-1.jpg","","inherit","open","closed","","logo-1-jpg","","","2019-12-22 23:56:18","2019-12-22 20:56:18","","0","http://dimtepla.com/wp-content/uploads/2019/12/logo-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("64","1","2019-12-22 23:56:19","2019-12-22 20:56:19","","pennant-1.jpg","","inherit","open","closed","","pennant-1-jpg","","","2019-12-22 23:56:19","2019-12-22 20:56:19","","0","http://dimtepla.com/wp-content/uploads/2019/12/pennant-1.jpg","0","attachment","image/jpeg","0");
INSERT INTO `wp_posts` VALUES("66","1","2019-12-23 08:39:10","2019-12-23 05:39:10","{
    \"dimtepla::header_textcolor\": {
        \"value\": \"blank\",
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-23 05:39:10\"
    }
}","","","trash","closed","closed","","4a4f077e-05ca-4d38-8f6e-8e9c57fa9989","","","2019-12-23 08:39:10","2019-12-23 05:39:10","","0","http://dimtepla.com/2019/12/23/4a4f077e-05ca-4d38-8f6e-8e9c57fa9989/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("83","1","2019-12-24 19:30:56","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 19:30:56","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=83","0","product","","0");
INSERT INTO `wp_posts` VALUES("84","1","2019-12-24 19:30:57","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 19:30:57","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=84","0","product","","0");
INSERT INTO `wp_posts` VALUES("85","1","2019-12-24 21:05:02","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 21:05:02","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=85","0","product","","0");
INSERT INTO `wp_posts` VALUES("86","1","2019-12-24 21:05:03","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 21:05:03","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=86","0","product","","0");
INSERT INTO `wp_posts` VALUES("87","1","2019-12-24 22:03:12","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 22:03:12","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=87","0","product","","0");
INSERT INTO `wp_posts` VALUES("88","1","2019-12-24 22:03:14","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-24 22:03:14","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=88","0","product","","0");
INSERT INTO `wp_posts` VALUES("89","1","2019-12-25 00:23:53","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 00:23:53","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=89","0","product","","0");
INSERT INTO `wp_posts` VALUES("90","1","2019-12-25 00:23:54","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 00:23:54","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=90","0","product","","0");
INSERT INTO `wp_posts` VALUES("91","1","2019-12-25 01:02:06","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:02:06","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=91","0","product","","0");
INSERT INTO `wp_posts` VALUES("92","1","2019-12-25 01:02:09","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:02:09","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=92","0","product","","0");
INSERT INTO `wp_posts` VALUES("93","1","2019-12-25 01:25:07","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:25:07","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=93","0","product","","0");
INSERT INTO `wp_posts` VALUES("94","1","2019-12-25 01:25:10","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:25:10","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=94","0","product","","0");
INSERT INTO `wp_posts` VALUES("95","1","2019-12-25 01:27:17","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:27:17","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=95","0","product","","0");
INSERT INTO `wp_posts` VALUES("96","1","2019-12-25 01:27:17","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:27:17","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=96","0","product","","0");
INSERT INTO `wp_posts` VALUES("97","1","2019-12-25 01:50:41","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 01:50:41","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=97","0","product","","0");
INSERT INTO `wp_posts` VALUES("98","1","2019-12-25 02:28:40","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 02:28:40","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=98","0","product","","0");
INSERT INTO `wp_posts` VALUES("99","1","2019-12-25 02:28:40","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 02:28:40","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=99","0","product","","0");
INSERT INTO `wp_posts` VALUES("100","1","2019-12-25 03:22:45","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:22:45","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=100","0","product","","0");
INSERT INTO `wp_posts` VALUES("101","1","2019-12-25 03:22:59","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:22:59","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=101","0","product","","0");
INSERT INTO `wp_posts` VALUES("102","1","2019-12-25 03:24:02","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:24:02","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=102","0","product","","0");
INSERT INTO `wp_posts` VALUES("103","1","2019-12-25 03:31:37","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:31:37","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=103","0","product","","0");
INSERT INTO `wp_posts` VALUES("104","1","2019-12-25 03:32:17","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:32:17","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=104","0","product","","0");
INSERT INTO `wp_posts` VALUES("105","1","2019-12-25 03:32:51","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:32:51","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=105","0","product","","0");
INSERT INTO `wp_posts` VALUES("106","1","2019-12-25 03:46:25","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:46:25","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=106","0","product","","0");
INSERT INTO `wp_posts` VALUES("107","1","2019-12-25 03:48:14","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:48:14","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=107","0","product","","0");
INSERT INTO `wp_posts` VALUES("108","1","2019-12-25 03:48:25","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:48:25","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=108","0","product","","0");
INSERT INTO `wp_posts` VALUES("109","1","2019-12-25 03:50:44","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:50:44","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=109","0","product","","0");
INSERT INTO `wp_posts` VALUES("110","1","2019-12-25 03:51:10","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:51:10","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=110","0","product","","0");
INSERT INTO `wp_posts` VALUES("111","1","2019-12-25 03:52:35","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:52:35","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=111","0","product","","0");
INSERT INTO `wp_posts` VALUES("112","1","2019-12-25 03:54:44","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 03:54:44","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=112","0","product","","0");
INSERT INTO `wp_posts` VALUES("114","1","2019-12-25 04:09:06","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 04:09:06","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=114","0","product","","0");
INSERT INTO `wp_posts` VALUES("115","1","2019-12-25 04:21:17","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","open","closed","","","","","2019-12-25 04:21:17","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=115","0","product","","0");
INSERT INTO `wp_posts` VALUES("117","1","2019-12-25 05:33:57","0000-00-00 00:00:00","{
    \"show_on_front\": {
        \"value\": \"posts\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-25 02:33:57\"
    },
    \"page_on_front\": {
        \"value\": \"0\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-25 02:33:57\"
    }
}","","","auto-draft","closed","closed","","fc26ffe8-a07a-4550-81f8-efca2e60eacc","","","2019-12-25 05:33:57","2019-12-25 02:33:57","","0","http://dimtepla.com/?p=117","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("118","1","2019-12-26 07:42:20","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2019-12-26 07:42:20","0000-00-00 00:00:00","","0","http://dimtepla.com/?p=118","0","post","","0");
INSERT INTO `wp_posts` VALUES("119","1","2019-12-26 07:42:30","2019-12-26 04:42:30","<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->","Корзина","","inherit","closed","closed","","13-revision-v1","","","2019-12-26 07:42:30","2019-12-26 04:42:30","","13","http://dimtepla.com/2019/12/26/13-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("120","1","2019-12-26 07:42:33","2019-12-26 04:42:33","","Магазин","","inherit","closed","closed","","12-revision-v1","","","2019-12-26 07:42:33","2019-12-26 04:42:33","","12","http://dimtepla.com/2019/12/26/12-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("121","1","2019-12-26 07:42:36","2019-12-26 04:42:36","<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->","Мой аккаунт","","inherit","closed","closed","","15-revision-v1","","","2019-12-26 07:42:36","2019-12-26 04:42:36","","15","http://dimtepla.com/2019/12/26/15-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("122","1","2019-12-26 07:42:39","2019-12-26 04:42:39","<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->","Оформление заказа","","inherit","closed","closed","","14-revision-v1","","","2019-12-26 07:42:39","2019-12-26 04:42:39","","14","http://dimtepla.com/2019/12/26/14-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("123","1","2019-12-26 07:42:45","2019-12-26 04:42:45","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://dimtepla.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","inherit","closed","closed","","3-revision-v1","","","2019-12-26 07:42:45","2019-12-26 04:42:45","","3","http://dimtepla.com/2019/12/26/3-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("124","1","2019-12-26 07:43:27","2019-12-26 04:43:27","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","inherit","closed","closed","","1-revision-v1","","","2019-12-26 07:43:27","2019-12-26 04:43:27","","1","http://dimtepla.com/2019/12/26/1-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("125","1","2019-12-26 19:41:07","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-26 19:41:07","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=125","0","product","","0");
INSERT INTO `wp_posts` VALUES("127","1","2019-12-26 19:44:48","2019-12-26 16:44:48","","kotl1","","inherit","open","closed","","kotl1","","","2019-12-26 19:44:48","2019-12-26 16:44:48","","0","http://dimtepla.com/wp-content/uploads/2019/12/kotl1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("128","1","2019-12-26 19:45:12","2019-12-26 16:45:12","","image1","","inherit","open","closed","","image1","","","2019-12-26 19:45:12","2019-12-26 16:45:12","","0","http://dimtepla.com/wp-content/uploads/2019/12/image1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("129","1","2019-12-26 20:18:15","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-26 20:18:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=129","0","product","","0");
INSERT INTO `wp_posts` VALUES("130","1","2019-12-26 23:55:59","2019-12-26 20:55:59","{
    \"woocommerce_checkout_company_field\": {
        \"value\": \"hidden\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-26 20:55:59\"
    },
    \"woocommerce_checkout_address_2_field\": {
        \"value\": \"hidden\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-26 20:55:59\"
    },
    \"woocommerce_checkout_phone_field\": {
        \"value\": \"hidden\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-26 20:55:59\"
    },
    \"woocommerce_checkout_highlight_required_fields\": {
        \"value\": false,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-26 20:55:59\"
    }
}","","","trash","closed","closed","","49990ebf-669b-409c-a85c-43bab00edb85","","","2019-12-26 23:55:59","2019-12-26 20:55:59","","0","http://dimtepla.com/2019/12/26/49990ebf-669b-409c-a85c-43bab00edb85/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("131","1","2019-12-27 00:45:24","2019-12-26 21:45:24","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7","","","2019-12-27 00:48:37","2019-12-26 21:48:37","","0","http://dimtepla.com/?post_type=product&#038;p=131","0","product","","0");
INSERT INTO `wp_posts` VALUES("132","1","2019-12-27 00:46:33","2019-12-26 21:46:33","","image2","","inherit","open","closed","","image2","","","2019-12-27 00:46:33","2019-12-26 21:46:33","","131","http://dimtepla.com/wp-content/uploads/2019/12/image2.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("133","1","2019-12-27 00:46:58","2019-12-26 21:46:58","","image3","","inherit","open","closed","","image3","","","2019-12-27 00:46:58","2019-12-26 21:46:58","","131","http://dimtepla.com/wp-content/uploads/2019/12/image3.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("134","1","2019-12-27 00:49:00","2019-12-26 21:49:00","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7-2","","","2019-12-27 00:49:00","2019-12-26 21:49:00","","0","http://dimtepla.com/?post_type=product&#038;p=134","0","product","","0");
INSERT INTO `wp_posts` VALUES("135","1","2019-12-27 00:49:07","2019-12-26 21:49:07","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7-3","","","2019-12-27 00:49:21","2019-12-26 21:49:21","","0","http://dimtepla.com/?post_type=product&#038;p=135","0","product","","0");
INSERT INTO `wp_posts` VALUES("136","1","2019-12-27 00:49:46","2019-12-26 21:49:46","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7-4","","","2019-12-27 00:49:46","2019-12-26 21:49:46","","0","http://dimtepla.com/?post_type=product&#038;p=136","0","product","","0");
INSERT INTO `wp_posts` VALUES("137","1","2019-12-27 00:50:12","2019-12-26 21:50:12","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7-5","","","2019-12-27 01:00:08","2019-12-26 22:00:08","","0","http://dimtepla.com/?post_type=product&#038;p=137","0","product","","0");
INSERT INTO `wp_posts` VALUES("138","1","2019-12-27 01:02:46","2019-12-26 22:02:46","","Неус-Вичлаз","","publish","closed","closed","","%d0%bd%d0%b5%d1%83%d1%81-%d0%b2%d0%b8%d1%87%d0%bb%d0%b0%d0%b7-6","","","2019-12-27 01:02:58","2019-12-26 22:02:58","","0","http://dimtepla.com/?post_type=product&#038;p=138","0","product","","0");
INSERT INTO `wp_posts` VALUES("139","1","2019-12-29 09:43:49","2019-12-29 06:43:49","","favicon","","inherit","open","closed","","favicon","","","2019-12-29 09:43:49","2019-12-29 06:43:49","","0","http://dimtepla.com/wp-content/uploads/2019/12/favicon.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("140","1","2019-12-29 09:43:56","2019-12-29 06:43:56","http://dimtepla.com/wp-content/uploads/2019/12/cropped-favicon.png","cropped-favicon.png","","inherit","open","closed","","cropped-favicon-png","","","2019-12-29 09:43:56","2019-12-29 06:43:56","","0","http://dimtepla.com/wp-content/uploads/2019/12/cropped-favicon.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("141","1","2019-12-29 09:44:08","2019-12-29 06:44:08","{
    \"blogdescription\": {
        \"value\": \"\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-29 06:44:08\"
    },
    \"site_icon\": {
        \"value\": 140,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-29 06:44:08\"
    }
}","","","trash","closed","closed","","7de35e68-66d2-4819-b6bf-7082b0545cf4","","","2019-12-29 09:44:08","2019-12-29 06:44:08","","0","http://dimtepla.com/2019/12/29/7de35e68-66d2-4819-b6bf-7082b0545cf4/","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("142","1","2019-12-29 09:45:38","2019-12-29 06:45:38","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://dimtepla.com/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","inherit","closed","closed","","2-revision-v1","","","2019-12-29 09:45:38","2019-12-29 06:45:38","","2","http://dimtepla.com/2019/12/29/2-revision-v1/","0","revision","","0");
INSERT INTO `wp_posts` VALUES("143","1","2019-12-31 15:55:19","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-31 15:55:19","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=143","0","product","","0");
INSERT INTO `wp_posts` VALUES("144","1","2019-12-31 15:57:14","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-31 15:57:14","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=144","0","product","","0");
INSERT INTO `wp_posts` VALUES("145","1","2019-12-31 16:01:01","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-31 16:01:01","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=145","0","product","","0");
INSERT INTO `wp_posts` VALUES("146","1","2019-12-31 16:03:05","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-31 16:03:05","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=146","0","product","","0");
INSERT INTO `wp_posts` VALUES("147","1","2019-12-31 16:03:53","0000-00-00 00:00:00","","AUTO-DRAFT","","auto-draft","closed","closed","","","","","2019-12-31 16:03:53","0000-00-00 00:00:00","","0","http://dimtepla.com/?post_type=product&p=147","0","product","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");
INSERT INTO `wp_term_relationships` VALUES("32","15","0");
INSERT INTO `wp_term_relationships` VALUES("33","15","0");
INSERT INTO `wp_term_relationships` VALUES("34","15","0");
INSERT INTO `wp_term_relationships` VALUES("35","15","0");
INSERT INTO `wp_term_relationships` VALUES("36","15","0");
INSERT INTO `wp_term_relationships` VALUES("37","15","0");
INSERT INTO `wp_term_relationships` VALUES("42","15","0");
INSERT INTO `wp_term_relationships` VALUES("131","2","0");
INSERT INTO `wp_term_relationships` VALUES("131","30","0");
INSERT INTO `wp_term_relationships` VALUES("134","2","0");
INSERT INTO `wp_term_relationships` VALUES("134","30","0");
INSERT INTO `wp_term_relationships` VALUES("135","2","0");
INSERT INTO `wp_term_relationships` VALUES("135","30","0");
INSERT INTO `wp_term_relationships` VALUES("136","2","0");
INSERT INTO `wp_term_relationships` VALUES("136","30","0");
INSERT INTO `wp_term_relationships` VALUES("137","2","0");
INSERT INTO `wp_term_relationships` VALUES("137","30","0");
INSERT INTO `wp_term_relationships` VALUES("138","2","0");
INSERT INTO `wp_term_relationships` VALUES("138","30","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","product_type","","0","6");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("11","11","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("12","12","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("13","13","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("14","14","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("15","15","product_cat","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("22","22","pa_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("23","23","pa_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("24","24","pa_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("25","25","pa_size","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("26","26","pa_size","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("27","27","pa_size","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("28","28","pa_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("29","29","pa_color","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("30","30","product_cat","","0","6");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_termmeta` VALUES("1","15","product_count_product_cat","0");
INSERT INTO `wp_termmeta` VALUES("10","22","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("11","23","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("12","24","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("13","25","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("14","26","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("15","27","order_pa_size","0");
INSERT INTO `wp_termmeta` VALUES("17","28","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("19","29","order_pa_color","0");
INSERT INTO `wp_termmeta` VALUES("22","30","order","0");
INSERT INTO `wp_termmeta` VALUES("23","30","display_type","");
INSERT INTO `wp_termmeta` VALUES("24","30","thumbnail_id","0");
INSERT INTO `wp_termmeta` VALUES("25","30","product_count_product_cat","6");


DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8","0");
INSERT INTO `wp_terms` VALUES("2","simple","simple","0");
INSERT INTO `wp_terms` VALUES("3","grouped","grouped","0");
INSERT INTO `wp_terms` VALUES("4","variable","variable","0");
INSERT INTO `wp_terms` VALUES("5","external","external","0");
INSERT INTO `wp_terms` VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("8","featured","featured","0");
INSERT INTO `wp_terms` VALUES("9","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("10","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("11","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("12","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("13","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("14","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("15","Uncategorized","uncategorized","0");
INSERT INTO `wp_terms` VALUES("22","Blue","blue","0");
INSERT INTO `wp_terms` VALUES("23","Green","green","0");
INSERT INTO `wp_terms` VALUES("24","Red","red","0");
INSERT INTO `wp_terms` VALUES("25","Large","large","0");
INSERT INTO `wp_terms` VALUES("26","Medium","medium","0");
INSERT INTO `wp_terms` VALUES("27","Small","small","0");
INSERT INTO `wp_terms` VALUES("28","Gray","gray","0");
INSERT INTO `wp_terms` VALUES("29","Yellow","yellow","0");
INSERT INTO `wp_terms` VALUES("30","boilers","boilers","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","theme_editor_notice");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"0fd3baaf35fb986474753b8916b0301af8b8544899fab653ded43074f02e4b5c\";a:4:{s:10:\"expiration\";i:1577803296;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36 OPR/65.0.3467.48\";s:5:\"login\";i:1576593696;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","118");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("20","1","_woocommerce_tracks_anon_id","woo:GD4DqZd0Zogjo6aeYzWUSkrL");
INSERT INTO `wp_usermeta` VALUES("21","1","dismissed_install_notice","1");
INSERT INTO `wp_usermeta` VALUES("22","1","dismissed_wc_admin_notice","1");
INSERT INTO `wp_usermeta` VALUES("23","1","_yoast_wpseo_profile_updated","1576599901");
INSERT INTO `wp_usermeta` VALUES("26","1","wc_last_active","1577750400");
INSERT INTO `wp_usermeta` VALUES("29","1","managenav-menuscolumnshidden","a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}");
INSERT INTO `wp_usermeta` VALUES("30","1","metaboxhidden_nav-menus","a:4:{i:0;s:21:\"add-post-type-product\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-product_cat\";i:3;s:15:\"add-product_tag\";}");
INSERT INTO `wp_usermeta` VALUES("31","1","wp_user-settings","libraryContent=browse");
INSERT INTO `wp_usermeta` VALUES("32","1","wp_user-settings-time","1576990219");
INSERT INTO `wp_usermeta` VALUES("33","1","wp_woocommerce_product_import_mapping","a:51:{i:0;s:2:\"id\";i:1;s:4:\"type\";i:2;s:3:\"sku\";i:3;s:4:\"name\";i:4;s:9:\"published\";i:5;s:8:\"featured\";i:6;s:18:\"catalog_visibility\";i:7;s:17:\"short_description\";i:8;s:11:\"description\";i:9;s:17:\"date_on_sale_from\";i:10;s:15:\"date_on_sale_to\";i:11;s:10:\"tax_status\";i:12;s:9:\"tax_class\";i:13;s:12:\"stock_status\";i:14;s:14:\"stock_quantity\";i:15;s:10:\"backorders\";i:16;s:17:\"sold_individually\";i:17;s:0:\"\";i:18;s:0:\"\";i:19;s:0:\"\";i:20;s:0:\"\";i:21;s:15:\"reviews_allowed\";i:22;s:13:\"purchase_note\";i:23;s:10:\"sale_price\";i:24;s:13:\"regular_price\";i:25;s:12:\"category_ids\";i:26;s:7:\"tag_ids\";i:27;s:17:\"shipping_class_id\";i:28;s:6:\"images\";i:29;s:14:\"download_limit\";i:30;s:15:\"download_expiry\";i:31;s:9:\"parent_id\";i:32;s:16:\"grouped_products\";i:33;s:10:\"upsell_ids\";i:34;s:14:\"cross_sell_ids\";i:35;s:11:\"product_url\";i:36;s:11:\"button_text\";i:37;s:10:\"menu_order\";i:38;s:16:\"attributes:name1\";i:39;s:17:\"attributes:value1\";i:40;s:19:\"attributes:visible1\";i:41;s:20:\"attributes:taxonomy1\";i:42;s:16:\"attributes:name2\";i:43;s:17:\"attributes:value2\";i:44;s:19:\"attributes:visible2\";i:45;s:20:\"attributes:taxonomy2\";i:46;s:23:\"meta:_wpcom_is_markdown\";i:47;s:15:\"downloads:name1\";i:48;s:14:\"downloads:url1\";i:49;s:15:\"downloads:name2\";i:50;s:14:\"downloads:url2\";}");
INSERT INTO `wp_usermeta` VALUES("34","1","wp_product_import_error_log","a:0:{}");
INSERT INTO `wp_usermeta` VALUES("35","1","dismissed_no_secure_connection_notice","1");
INSERT INTO `wp_usermeta` VALUES("36","1","manageedit-shop_ordercolumnshidden","a:4:{i:0;s:15:\"billing_address\";i:1;s:16:\"shipping_address\";i:2;s:11:\"order_total\";i:3;s:10:\"wc_actions\";}");
INSERT INTO `wp_usermeta` VALUES("37","1","edit_shop_order_per_page","20");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$BWOwp7wQtu0iLmPLcElx11z122FPmS.","admin","Email@mail.com","","2019-12-17 14:41:23","","0","admin");


DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(10,2) DEFAULT NULL,
  `max_price` decimal(10,2) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_wc_product_meta_lookup` VALUES("131","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");
INSERT INTO `wp_wc_product_meta_lookup` VALUES("134","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");
INSERT INTO `wp_wc_product_meta_lookup` VALUES("135","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");
INSERT INTO `wp_wc_product_meta_lookup` VALUES("136","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");
INSERT INTO `wp_wc_product_meta_lookup` VALUES("137","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");
INSERT INTO `wp_wc_product_meta_lookup` VALUES("138","","0","0","2800.00","2800.00","0","","instock","0","0.00","0");


DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_wc_tax_rate_classes` VALUES("1","Пониженная ставка","%d0%bf%d0%be%d0%bd%d0%b8%d0%b6%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");
INSERT INTO `wp_wc_tax_rate_classes` VALUES("2","Нулевая ставка","%d0%bd%d1%83%d0%bb%d0%b5%d0%b2%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");


DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("1","color","Color","select","menu_order","0");
INSERT INTO `wp_woocommerce_attribute_taxonomies` VALUES("2","size","Size","select","menu_order","0");


DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_items`;

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_sessions`;

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_woocommerce_sessions` VALUES("7","1","a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:702:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"UA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"UA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:14:\"Email@mail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}","1577854922");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_yoast_seo_meta` VALUES("12","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("13","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("14","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("15","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("17","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("18","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("19","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("20","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("21","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("22","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("23","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("24","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("25","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("26","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("27","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("28","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("29","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("30","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("31","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("32","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("33","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("34","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("35","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("36","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("37","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("38","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("39","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("40","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("41","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("42","0","0");


