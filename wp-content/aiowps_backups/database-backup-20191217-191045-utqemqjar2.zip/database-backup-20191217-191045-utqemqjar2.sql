-- All In One WP Security & Firewall 4.4.2
-- MySQL dump
-- 2019-12-17 16:10:45

SET NAMES utf8;
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `wp_aiowps_events`;

CREATE TABLE `wp_aiowps_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `event_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `username` varchar(150) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `event_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `ip_or_host` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `referer_info` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_code` varchar(50) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `event_data` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_failed_logins`;

CREATE TABLE `wp_aiowps_failed_logins` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `failed_login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_attempt_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_global_meta`;

CREATE TABLE `wp_aiowps_global_meta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_time` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `meta_key1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key2` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key3` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key4` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_key5` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value1` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value2` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value3` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value4` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `meta_value5` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`meta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_activity`;

CREATE TABLE `wp_aiowps_login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `login_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logout_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `login_country` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `browser_type` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_login_lockdown`;

CREATE TABLE `wp_aiowps_login_lockdown` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `user_login` varchar(150) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `lockdown_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `release_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `failed_login_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `lock_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `unlock_key` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_aiowps_permanent_block`;

CREATE TABLE `wp_aiowps_permanent_block` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocked_ip` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `block_reason` varchar(128) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `country_origin` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blocked_date` datetime NOT NULL DEFAULT '1000-10-10 10:00:00',
  `unblock` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_commentmeta`;

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_comments`;

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_comments` VALUES("1","1","Автор комментария","wapuu@wordpress.example","https://wordpress.org/","","2019-12-17 17:41:23","2019-12-17 14:41:23","Привет! Это комментарий.
Чтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.
Аватары авторов комментариев загружаются с сервиса <a href=\"https://ru.gravatar.com\">Gravatar</a>.","0","1","","","0","0");


DROP TABLE IF EXISTS `wp_links`;

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_options`;

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=376 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_options` VALUES("1","siteurl","http://dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("2","home","http://dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("3","blogname","dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("4","blogdescription","Ещё один сайт на WordPress","yes");
INSERT INTO `wp_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `wp_options` VALUES("6","admin_email","Email@mail.com","yes");
INSERT INTO `wp_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `wp_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `wp_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `wp_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `wp_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `wp_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `wp_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `wp_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `wp_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `wp_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `wp_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `wp_options` VALUES("18","default_category","1","yes");
INSERT INTO `wp_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `wp_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `wp_options` VALUES("21","default_pingback_flag","1","yes");
INSERT INTO `wp_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `wp_options` VALUES("23","date_format","d.m.Y","yes");
INSERT INTO `wp_options` VALUES("24","time_format","H:i","yes");
INSERT INTO `wp_options` VALUES("25","links_updated_date_format","d.m.Y H:i","yes");
INSERT INTO `wp_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `wp_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `wp_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `wp_options` VALUES("30","hack_file","0","yes");
INSERT INTO `wp_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `wp_options` VALUES("32","moderation_keys","","no");
INSERT INTO `wp_options` VALUES("33","active_plugins","a:3:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:27:\"woocommerce/woocommerce.php\";i:2;s:24:\"wordpress-seo/wp-seo.php\";}","yes");
INSERT INTO `wp_options` VALUES("34","category_base","","yes");
INSERT INTO `wp_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `wp_options` VALUES("36","comment_max_links","2","yes");
INSERT INTO `wp_options` VALUES("37","gmt_offset","3","yes");
INSERT INTO `wp_options` VALUES("38","default_email_category","1","yes");
INSERT INTO `wp_options` VALUES("39","recently_edited","","no");
INSERT INTO `wp_options` VALUES("40","template","twentytwenty","yes");
INSERT INTO `wp_options` VALUES("41","stylesheet","twentytwenty","yes");
INSERT INTO `wp_options` VALUES("42","comment_whitelist","1","yes");
INSERT INTO `wp_options` VALUES("43","blacklist_keys","","no");
INSERT INTO `wp_options` VALUES("44","comment_registration","0","yes");
INSERT INTO `wp_options` VALUES("45","html_type","text/html","yes");
INSERT INTO `wp_options` VALUES("46","use_trackback","0","yes");
INSERT INTO `wp_options` VALUES("47","default_role","subscriber","yes");
INSERT INTO `wp_options` VALUES("48","db_version","45805","yes");
INSERT INTO `wp_options` VALUES("49","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `wp_options` VALUES("50","upload_path","","yes");
INSERT INTO `wp_options` VALUES("51","blog_public","1","yes");
INSERT INTO `wp_options` VALUES("52","default_link_category","2","yes");
INSERT INTO `wp_options` VALUES("53","show_on_front","posts","yes");
INSERT INTO `wp_options` VALUES("54","tag_base","","yes");
INSERT INTO `wp_options` VALUES("55","show_avatars","1","yes");
INSERT INTO `wp_options` VALUES("56","avatar_rating","G","yes");
INSERT INTO `wp_options` VALUES("57","upload_url_path","","yes");
INSERT INTO `wp_options` VALUES("58","thumbnail_size_w","150","yes");
INSERT INTO `wp_options` VALUES("59","thumbnail_size_h","150","yes");
INSERT INTO `wp_options` VALUES("60","thumbnail_crop","1","yes");
INSERT INTO `wp_options` VALUES("61","medium_size_w","300","yes");
INSERT INTO `wp_options` VALUES("62","medium_size_h","300","yes");
INSERT INTO `wp_options` VALUES("63","avatar_default","mystery","yes");
INSERT INTO `wp_options` VALUES("64","large_size_w","1024","yes");
INSERT INTO `wp_options` VALUES("65","large_size_h","1024","yes");
INSERT INTO `wp_options` VALUES("66","image_default_link_type","none","yes");
INSERT INTO `wp_options` VALUES("67","image_default_size","","yes");
INSERT INTO `wp_options` VALUES("68","image_default_align","","yes");
INSERT INTO `wp_options` VALUES("69","close_comments_for_old_posts","0","yes");
INSERT INTO `wp_options` VALUES("70","close_comments_days_old","14","yes");
INSERT INTO `wp_options` VALUES("71","thread_comments","1","yes");
INSERT INTO `wp_options` VALUES("72","thread_comments_depth","5","yes");
INSERT INTO `wp_options` VALUES("73","page_comments","0","yes");
INSERT INTO `wp_options` VALUES("74","comments_per_page","50","yes");
INSERT INTO `wp_options` VALUES("75","default_comments_page","newest","yes");
INSERT INTO `wp_options` VALUES("76","comment_order","asc","yes");
INSERT INTO `wp_options` VALUES("77","sticky_posts","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("78","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("79","widget_text","a:3:{i:2;a:4:{s:5:\"title\";s:13:\"О сайте\";s:4:\"text\";s:205:\"Здесь может быть отличное место для того, чтобы представить себя, свой сайт или выразить какие-то благодарности.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:21:\"Найдите нас\";s:4:\"text\";s:226:\"<strong>Адрес</strong>
123 Мейн стрит
Нью Йорк, NY 10001

<strong>Часы</strong>
Понедельник&mdash;пятница: 9:00&ndash;17:00
Суббота и воскресенье: 11:00&ndash;15:00\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("80","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("81","uninstall_plugins","a:0:{}","no");
INSERT INTO `wp_options` VALUES("82","timezone_string","","yes");
INSERT INTO `wp_options` VALUES("83","page_for_posts","0","yes");
INSERT INTO `wp_options` VALUES("84","page_on_front","0","yes");
INSERT INTO `wp_options` VALUES("85","default_post_format","0","yes");
INSERT INTO `wp_options` VALUES("86","link_manager_enabled","0","yes");
INSERT INTO `wp_options` VALUES("87","finished_splitting_shared_terms","1","yes");
INSERT INTO `wp_options` VALUES("88","site_icon","0","yes");
INSERT INTO `wp_options` VALUES("89","medium_large_size_w","768","yes");
INSERT INTO `wp_options` VALUES("90","medium_large_size_h","0","yes");
INSERT INTO `wp_options` VALUES("91","wp_page_for_privacy_policy","3","yes");
INSERT INTO `wp_options` VALUES("92","show_comments_cookies_opt_in","1","yes");
INSERT INTO `wp_options` VALUES("93","admin_email_lifespan","1592145683","yes");
INSERT INTO `wp_options` VALUES("94","initial_db_version","45805","yes");
INSERT INTO `wp_options` VALUES("95","wp_user_roles","a:9:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:115:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;s:20:\"wpseo_manage_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:35:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"wpseo_manager\";a:2:{s:4:\"name\";s:11:\"SEO Manager\";s:12:\"capabilities\";a:37:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;s:20:\"wpseo_manage_options\";b:1;}}s:12:\"wpseo_editor\";a:2:{s:4:\"name\";s:10:\"SEO Editor\";s:12:\"capabilities\";a:36:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:15:\"wpseo_bulk_edit\";b:1;s:28:\"wpseo_edit_advanced_metadata\";b:1;}}s:8:\"customer\";a:2:{s:4:\"name\";s:8:\"Customer\";s:12:\"capabilities\";a:1:{s:4:\"read\";b:1;}}s:12:\"shop_manager\";a:2:{s:4:\"name\";s:12:\"Shop manager\";s:12:\"capabilities\";a:92:{s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:10:\"edit_posts\";b:1;s:10:\"edit_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:13:\"publish_posts\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_posts\";b:1;s:12:\"delete_pages\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:19:\"delete_others_pages\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:12:\"upload_files\";b:1;s:6:\"export\";b:1;s:6:\"import\";b:1;s:10:\"list_users\";b:1;s:18:\"edit_theme_options\";b:1;s:18:\"manage_woocommerce\";b:1;s:24:\"view_woocommerce_reports\";b:1;s:12:\"edit_product\";b:1;s:12:\"read_product\";b:1;s:14:\"delete_product\";b:1;s:13:\"edit_products\";b:1;s:20:\"edit_others_products\";b:1;s:16:\"publish_products\";b:1;s:21:\"read_private_products\";b:1;s:15:\"delete_products\";b:1;s:23:\"delete_private_products\";b:1;s:25:\"delete_published_products\";b:1;s:22:\"delete_others_products\";b:1;s:21:\"edit_private_products\";b:1;s:23:\"edit_published_products\";b:1;s:20:\"manage_product_terms\";b:1;s:18:\"edit_product_terms\";b:1;s:20:\"delete_product_terms\";b:1;s:20:\"assign_product_terms\";b:1;s:15:\"edit_shop_order\";b:1;s:15:\"read_shop_order\";b:1;s:17:\"delete_shop_order\";b:1;s:16:\"edit_shop_orders\";b:1;s:23:\"edit_others_shop_orders\";b:1;s:19:\"publish_shop_orders\";b:1;s:24:\"read_private_shop_orders\";b:1;s:18:\"delete_shop_orders\";b:1;s:26:\"delete_private_shop_orders\";b:1;s:28:\"delete_published_shop_orders\";b:1;s:25:\"delete_others_shop_orders\";b:1;s:24:\"edit_private_shop_orders\";b:1;s:26:\"edit_published_shop_orders\";b:1;s:23:\"manage_shop_order_terms\";b:1;s:21:\"edit_shop_order_terms\";b:1;s:23:\"delete_shop_order_terms\";b:1;s:23:\"assign_shop_order_terms\";b:1;s:16:\"edit_shop_coupon\";b:1;s:16:\"read_shop_coupon\";b:1;s:18:\"delete_shop_coupon\";b:1;s:17:\"edit_shop_coupons\";b:1;s:24:\"edit_others_shop_coupons\";b:1;s:20:\"publish_shop_coupons\";b:1;s:25:\"read_private_shop_coupons\";b:1;s:19:\"delete_shop_coupons\";b:1;s:27:\"delete_private_shop_coupons\";b:1;s:29:\"delete_published_shop_coupons\";b:1;s:26:\"delete_others_shop_coupons\";b:1;s:25:\"edit_private_shop_coupons\";b:1;s:27:\"edit_published_shop_coupons\";b:1;s:24:\"manage_shop_coupon_terms\";b:1;s:22:\"edit_shop_coupon_terms\";b:1;s:24:\"delete_shop_coupon_terms\";b:1;s:24:\"assign_shop_coupon_terms\";b:1;}}}","yes");
INSERT INTO `wp_options` VALUES("96","fresh_site","0","yes");
INSERT INTO `wp_options` VALUES("97","WPLANG","ru_RU","yes");
INSERT INTO `wp_options` VALUES("98","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("99","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("100","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("101","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("102","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("103","sidebars_widgets","a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}","yes");
INSERT INTO `wp_options` VALUES("104","cron","a:17:{i:1576599083;a:1:{s:26:\"action_scheduler_run_queue\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:12:\"every_minute\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1576599683;a:1:{s:32:\"woocommerce_cancel_unpaid_orders\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1576600884;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1576602572;a:1:{s:24:\"aiowps_hourly_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1576606883;a:1:{s:24:\"woocommerce_cleanup_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576616400;a:1:{s:27:\"woocommerce_scheduled_sales\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576617683;a:1:{s:28:\"woocommerce_cleanup_sessions\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1576636884;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1576680083;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576680096;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576680097;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576681772;a:1:{s:23:\"aiowps_daily_cron_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576682026;a:1:{s:19:\"wpseo-reindex-links\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576682483;a:1:{s:33:\"woocommerce_cleanup_personal_data\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1576682493;a:1:{s:30:\"woocommerce_tracker_send_event\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1578355200;a:1:{s:25:\"woocommerce_geoip_updater\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:7:\"monthly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:2635200;}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `wp_options` VALUES("105","widget_pages","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("106","widget_calendar","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("107","widget_media_audio","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("108","widget_media_image","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("109","widget_media_gallery","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("110","widget_media_video","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("111","widget_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("112","widget_nav_menu","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("113","widget_custom_html","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("115","recovery_keys","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("119","theme_mods_twentytwenty","a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"background_color\";s:3:\"fff\";}","yes");
INSERT INTO `wp_options` VALUES("126","_site_transient_timeout_browser_9ebd6ec4f1073f0694d6845e1a3fb409","1577198497","no");
INSERT INTO `wp_options` VALUES("127","_site_transient_browser_9ebd6ec4f1073f0694d6845e1a3fb409","a:10:{s:4:\"name\";s:5:\"Opera\";s:7:\"version\";s:12:\"65.0.3467.48\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:22:\"https://www.opera.com/\";s:7:\"img_src\";s:42:\"http://s.w.org/images/browsers/opera.png?1\";s:11:\"img_src_ssl\";s:43:\"https://s.w.org/images/browsers/opera.png?1\";s:15:\"current_version\";s:5:\"12.18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}","no");
INSERT INTO `wp_options` VALUES("128","_site_transient_timeout_php_check_efdd3ae45e3cb36518103d0effbe0754","1577198497","no");
INSERT INTO `wp_options` VALUES("129","_site_transient_php_check_efdd3ae45e3cb36518103d0effbe0754","a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}","no");
INSERT INTO `wp_options` VALUES("131","can_compress_scripts","0","no");
INSERT INTO `wp_options` VALUES("132","_site_transient_timeout_community-events-1aecf33ab8525ff212ebdffbb438372e","1576636898","no");
INSERT INTO `wp_options` VALUES("133","_site_transient_community-events-1aecf33ab8525ff212ebdffbb438372e","a:3:{s:9:\"sandboxed\";b:0;s:8:\"location\";a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}s:6:\"events\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("134","_transient_timeout_feed_126d1ca39d75da07beec8b892738427b","1576636899","no");
INSERT INTO `wp_options` VALUES("135","_transient_feed_126d1ca39d75da07beec8b892738427b","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Блог | WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"https://ru.wordpress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Русский\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Dec 2019 21:24:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"ru-RU\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/?v=5.4-alpha-46964\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Ежегодный опрос пользователей и разработчиков WordPress 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2019/11/2019-annual-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 03 Nov 2019 08:53:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2141\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:721:\"Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. В этом году мы рады предложить вам опрос не только на английском, но и на русском языке (также были добавлены испанский, французский, немецкий и японский). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в английском блоге WordPress.org. Сбор данных осуществляется в [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3075:\"
<div class=\"wp-block-media-text alignwide has-media-on-the-right\"><figure class=\"wp-block-media-text__media\"><img src=\"https://ru.wordpress.org/files/2019/11/image-12-1.png\" alt=\"\" class=\"wp-image-2145\" srcset=\"https://ru.wordpress.org/files/2019/11/image-12-1.png 768w, https://ru.wordpress.org/files/2019/11/image-12-1-300x134.png 300w\" sizes=\"(max-width: 768px) 100vw, 768px\" /></figure><div class=\"wp-block-media-text__content\">
<p style=\"font-size:18px\">Каждый год сообщество WordPress проводит ежегодный опрос для пользователей и участников сообщества. </p>
</div></div>



<p>В этом году мы рады предложить вам опрос не только <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-english\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"на английском (opens in a new tab)\">на английском</a>, но и на русском языке (также были добавлены <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-spanish\">испанский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-french\">французский</a>, <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-german\">немецкий</a> и <a href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-japanese\">японский</a>). Опрос будет проводиться в течении четырех недель, результаты будут опубликованы в <a rel=\"noreferrer noopener\" aria-label=\"английском блоге WordPress.org (opens in a new tab)\" href=\"https://wordpress.org/news/\" target=\"_blank\">английском блоге WordPress.org</a>.</p>



<p>Сбор данных осуществляется в полном соответствии с <a href=\"https://ru.wordpress.org/about/privacy/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"политикой конфиденциальности WordPress.org (opens in a new tab)\">политикой конфиденциальности WordPress.org</a>: все данные будут анонимизированы и не будут ассоциироваться с IP-адресами и адресами e-mail.</p>



<div class=\"wp-block-button\"><a class=\"wp-block-button__link has-text-color has-very-light-gray-color has-background has-vivid-cyan-blue-background-color\" href=\"https://wordpressdotorg.survey.fm/wordpress-2019-survey-russian\">Пройти опрос</a></div>



<p>Если вы ответите, что принимали участие в жизни сообщества или сделали что-либо для WordPress, то вам будет предложен дополнительный опрос для участников сообщества. Каждый из опросов займет примерно 5 минут.</p>



<p>Дополнение: опрос был продлён до 16 декабря.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:54:\"
		
		
				
		
				
		
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Конференция WordCamp Санкт-Петербург 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://ru.wordpress.org/news/2019/08/wordcamp-saint-petersburg-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Aug 2019 09:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2119\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:443:\"Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: https://2019.saintpetersburg.wordcamp.org/ Заказ билетов на мероприятие доступен уже сегодня!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1484:\"
<div class=\"wp-block-image\"><figure class=\"aligncenter\"><img src=\"https://2019.saintpetersburg.wordcamp.org/files/2019/08/b46860.png\" alt=\"\" /></figure></div>



<p>Второй WordCamp в Санкт-Петербурге пройдет 28 сентября. Для ознакомления с подробностями о мероприятии, а также если вы хотите стать спикером или волонтёром, посетите сайт: <a rel=\"noreferrer noopener\" aria-label=\"https://2019.saintpetersburg.wordcamp.org/ (opens in a new tab)\" href=\"https://2019.saintpetersburg.wordcamp.org/\" target=\"_blank\">https://2019.saintpetersburg.wordcamp.org/</a></p>



<figure class=\"wp-block-image\"><img src=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg\" alt=\"\" class=\"wp-image-2125\" srcset=\"https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-1024x629.jpg 1024w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-300x184.jpg 300w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2-768x472.jpg 768w, https://ru.wordpress.org/files/2019/08/YP_0081-gallery-2.jpg 1680w\" sizes=\"(max-width: 1024px) 100vw, 1024px\" /><figcaption>Конференция пройдет в пространстве коворкинга &#171;Ясная Поляна&#187; ул. Льва Толстого 1-3</figcaption></figure>



<p>Заказ билетов на мероприятие доступен уже сегодня!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WordPress Translation Day 4 — Санкт-Петербург\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:152:\"https://ru.wordpress.org/news/2019/05/wordpress-translation-day-4-%d1%81%d0%b0%d0%bd%d0%ba%d1%82-%d0%bf%d0%b5%d1%82%d0%b5%d1%80%d0%b1%d1%83%d1%80%d0%b3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 May 2019 11:53:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2099\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:685:\"Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках https://wptranslationday.org/ в Петербурге очная часть пройдет по адресу 9-я Советская, 18 (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое время. В программе &#8212; философия WordPress полиглотов, инструктаж, практическая часть, где мы переводим непереведенные плагины, темы, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1478:\"
<p>Друзья! Ни для кого не секрет, что 11-го мая проходит всемирный суточный марафон перевода WordPress. В рамках <a href=\"https://wptranslationday.org/\">https://wptranslationday.org/</a>  в Петербурге очная часть <a href=\"https://www.meetup.com/St-Petersburg-WordPress-Meetup/events/261316455/\" target=\"_blank\" rel=\"noreferrer noopener\" aria-label=\"пройдет (opens in a new tab)\">пройдет</a> по адресу 9-я Советская, 18  (пространство funhouse, цоколь) с 12.00 до 21.00. Вход свободный в любое  время.</p>



<p>В программе &#8212; философия WordPress полиглотов, инструктаж,  практическая часть, где мы переводим непереведенные плагины, темы, и  т.д. Заочно можно участвовать присоединившись в Телеграм-группу @wcspb  <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>



<p>Берем свои ноутбуки, знание русского языка (и немного английского), и отличное настроение!</p>



<p>Полиглоты, лингвисты, программисты объединяйтесь!</p>



<p></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WP Moscow #6. Собственная тема на Elementor, кейс по WordPress + React JS\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:222:\"https://ru.wordpress.org/news/2019/02/wp-moscow-6-%d1%81%d0%be%d0%b1%d1%81%d1%82%d0%b2%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%82%d0%b5%d0%bc%d0%b0-%d0%bd%d0%b0-elementor-%d0%ba%d0%b5%d0%b9%d1%81-%d0%bf%d0%be-wordpress-react-js/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Feb 2019 05:10:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2081\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:563:\"Очередной митап по WordPress состоится в четверг 28 февраля. Запланировано два доклада: «Создание собственной темы для WordPress сайта при помощи плагина Elementor»Леонид Лукин «Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»Андрей Панферов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:742:\"
<p>Очередной митап по WordPress состоится в четверг 28 февраля.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Создание собственной темы для WordPress сайта при помощи плагина Elementor»</strong><br>Леонид Лукин</p>



<p><strong>«Как сделать впечатляющий промо-сайт на WordPress + React JS. Разбор кейса.»</strong><br>Андрей Панферов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258755820/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WP Moscow #5 | Тонкости продаж, Gutenberg и ACF\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:157:\"https://ru.wordpress.org/news/2019/01/wp-moscow-5-%d1%82%d0%be%d0%bd%d0%ba%d0%be%d1%81%d1%82%d0%b8-%d0%bf%d1%80%d0%be%d0%b4%d0%b0%d0%b6-gutenberg-%d0%b8-acf/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 22 Jan 2019 16:14:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2074\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:424:\"Очередной митап по WordPress состоится в четверг 31 января. Запланировано два доклада: «Как продавать услуги по разработке сайтов»Андрей Панферов «ACF PRO + Gutenberg»Николай Миронов Вход свободной по предварительной регистрации. Начало в 19.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:603:\"
<p>Очередной митап по WordPress состоится в четверг 31 января.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Как продавать услуги по разработке сайтов»</strong><br>Андрей Панферов</p>



<p><strong>«ACF PRO + Gutenberg»</strong><br>Николай Миронов</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/258124643/\">предварительной регистрации</a>.</p>



<p>Начало в 19.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WP Moscow #4 | Обсудим настройки тем и дизайн\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:211:\"https://ru.wordpress.org/news/2018/11/wp-moscow-4-%d0%be%d0%b1%d1%81%d1%83%d0%b4%d0%b8%d0%bc-%d0%bd%d0%b0%d1%81%d1%82%d1%80%d0%be%d0%b9%d0%ba%d0%b8-%d1%82%d0%b5%d0%bc-%d0%b8-%d0%b4%d0%b8%d0%b7%d0%b0%d0%b9%d0%bd/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Nov 2018 13:22:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2065\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:467:\"Очередной митап по WordPress состоится в четверг 15 ноября. Запланировано два доклада: «Настройки темы: Customizer или Advanced Custom Fields?»Денис Янчевский «В чем отличие UX дизайна от UI дизайна?»Фёдор Гребенников Вход свободной по предварительной регистрации. Начало в 18.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:646:\"
<p>Очередной митап по WordPress состоится в четверг 15 ноября.</p>



<p>Запланировано два доклада:</p>



<p><strong>«Настройки темы: Customizer или Advanced Custom Fields?»</strong><br>Денис Янчевский</p>



<p><strong>«В чем отличие UX дизайна от UI дизайна?»</strong><br>Фёдор Гребенников</p>



<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/wordpress-moscow/events/255766420/\">предварительной регистрации</a>.</p>



<p>Начало в 18.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WP Moscow #3 | Доклады, живое общение, пицца\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:198:\"https://ru.wordpress.org/news/2018/10/wp-moscow-3-%d0%b4%d0%be%d0%ba%d0%bb%d0%b0%d0%b4%d1%8b-%d0%b6%d0%b8%d0%b2%d0%be%d0%b5-%d0%be%d0%b1%d1%89%d0%b5%d0%bd%d0%b8%d0%b5-%d0%bf%d0%b8%d1%86%d1%86%d0%b0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 14 Oct 2018 23:14:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2057\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:666:\"Очередной митап по WordPress состоится в субботу 20 октября. Запланировано три доклада: «SEO? Изучить не надо игнорировать — где ставить запятую веб-разработчику?» Павел Карпов «Перевод проекта с премиум-темы на чистый код» Владимир Скляр «Видите ли вы хаос в коде плагинов и тем? А он есть!» Николай Коробочкин Вход свободной по предварительной регистрации. Начало в 12.00.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Denis Yanchevskiy\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:870:\"<p>Очередной митап по WordPress состоится в субботу 20 октября.</p>
<p>Запланировано три доклада:</p>
<p><strong>«SEO? Изучить не надо игнорировать — где ставить запятую веб-разработчику?»</strong><br />
Павел Карпов</p>
<p><strong>«Перевод проекта с премиум-темы на чистый код»</strong><br />
Владимир Скляр</p>
<p><strong>«Видите ли вы хаос в коде плагинов и тем? А он есть!»</strong><br />
Николай Коробочкин</p>
<p>Вход свободной по <a href=\"https://www.meetup.com/ru-RU/Moscow-WordPress-Meetup/events/255225381/\">предварительной регистрации</a>.</p>
<p>Начало в 12.00.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:51:\"
		
		
				
		
				
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"Электронная коммерция с WordPress, как создать интернет-магазин?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://ru.wordpress.org/news/2018/09/meetup-moscow-1809/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 17 Sep 2018 19:41:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2048\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:583:\"Первый тематический митап про WooCommerce (и не только) состоится в Москве 20 сентября. Обсуждаем особенности создания интернет-магазинов на WordPress, плагины, темы, оптимизацию работы сайта. Приглашаем всех, кто интересуется электронной коммерцией, имеет опыт или планирует открыть свой интернет-магазин. Подробности по ссылке\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:697:\"
<p>Первый тематический митап про WooCommerce (и не только) состоится в Москве 20 сентября. Обсуждаем особенности создания интернет-магазинов на WordPress, плагины, темы, оптимизацию работы сайта.</p>



<p>Приглашаем всех, кто интересуется электронной коммерцией, имеет опыт или планирует открыть свой интернет-магазин.</p>



<p><a href=\"https://www.meetup.com/ru-RU/Moscow-WordPress-Meetup/events/254204545/\">Подробности по ссылке</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:54:\"
		
		
				
		
				
		
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Конференция WordCamp Москва 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://ru.wordpress.org/news/2018/07/wordcamp-moscow2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Jul 2018 17:06:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=2017\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:446:\"В этом году WordCamp Moscow впервые будет длиться два дня! Мероприятие пройдет 18 и 19 августа в центре Digital October! Посетите сайт конференции, чтобы ознакомиться с подробностями, стать спикером, спонсором или зарегистрироваться для участия в конференции!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:568:\"<p>В этом году WordCamp Moscow впервые будет длиться два дня! Мероприятие пройдет <strong>18 и 19 августа</strong> в центре Digital October!</p>
<p><a href=\"https://2018.moscow.wordcamp.org/\" target=\"_blank\" rel=\"noopener noreferrer\">Посетите сайт конференции</a>, чтобы ознакомиться с подробностями, стать спикером, спонсором или зарегистрироваться для участия в конференции!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:54:\"
		
		
				
		
				
		
		

		
				
								
										\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:6:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Конференция WordCamp Санкт-Петербург 2018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://ru.wordpress.org/news/2018/05/wordcamp-stpetersburg2018/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 02 May 2018 07:03:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:14:\"Новости\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:25:\"Общие вопросы\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:15:\"WordCamp Russia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://ru.wordpress.org/?p=1994\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:575:\"Конференция состоится 26 мая 2018 при поддержке компании SEMrush. Хотите поучаствовать, поделиться сообществом своим опытом или просто рассказать что-то интересное из мира WordPress? Приходите, будет интересно! Полезные знакомства, новые доклады, футболка с символикой WordPress, пицца и after-party. Подробности на сайте конференции.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:3:\"Yui\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:706:\"<p>Конференция состоится 26 мая 2018 при поддержке компании SEMrush.<br />
Хотите поучаствовать, поделиться сообществом своим опытом или просто рассказать что-то интересное из мира WordPress?<br />
Приходите, будет интересно!<br />
Полезные знакомства, новые доклады, футболка с символикой WordPress, пицца и after-party.<br />
Подробности <a href=\"https://2018.saintpetersburg.wordcamp.org/\" target=\"_blank\" rel=\"noopener noreferrer\">на сайте конференции.</a></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:35:\"https://ru.wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"
	hourly	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"
	1	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 17 Dec 2019 14:41:39 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:6:\"x-olaf\";s:3:\"⛄\";s:13:\"last-modified\";s:29:\"Tue, 17 Dec 2019 14:39:53 GMT\";s:4:\"link\";s:61:\"<https://ru.wordpress.org/wp-json/>; rel=\"https://api.w.org/\"\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 1\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("136","_transient_timeout_feed_mod_126d1ca39d75da07beec8b892738427b","1576636899","no");
INSERT INTO `wp_options` VALUES("137","_transient_feed_mod_126d1ca39d75da07beec8b892738427b","1576593699","no");
INSERT INTO `wp_options` VALUES("138","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1576636900","no");
INSERT INTO `wp_options` VALUES("139","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Matt: Comments and Collatz Conundrum\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50619\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://ma.tt/2019/12/comments-and-collatz-conundrum/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1482:\"<p>Over the summer <a href=\"https://terrytao.wordpress.com/\">Terence Tao</a>, a <a href=\"https://en.wikipedia.org/wiki/Fields_Medal\">Fields Medal</a>-winning mathematician considered one of the best of his generation, got an anonymous comment <a href=\"https://terrytao.wordpress.com/2011/08/25/the-collatz-conjecture-littlewood-offord-theory-and-powers-of-2-and-3/\">on his WordPress blog post from 2011 exploring the Collatz conjecture</a> — one of the most persistent problems in math — suggesting he explore the problem for &#8220;almost all&#8221; numbers. Terence has been a regular WP.com blogger since 2007 and he and his commenters make <a href=\"https://en.support.wordpress.com/latex/\">extensive use of our LaTeX feature to express and embed equations</a>. </p>



<p>That anonymous comment <a href=\"https://www.quantamagazine.org/mathematician-terence-tao-and-the-collatz-conjecture-20191211/\">led him to an important breakthrough on the Collatz Conundrum, as Quanta Magazine reports</a>. If you want a great comments, you as the author have to participate in them and Terence is incredibly active in engaging with the commenters on his site.</p>



<p>I&#8217;ve always said that comments are the best part of blogging, but this is a particularly cool example. <a href=\"https://terrytao.wordpress.com/2019/09/10/almost-all-collatz-orbits-attain-almost-bounded-values/\">Here&#8217;s Terence&#8217;s latest post on it</a>, with an excellent comment thread following.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Dec 2019 21:46:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Slim SEO Keeps Options Simple and Handles the Legwork of SEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95857\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://wptavern.com/slim-seo-keeps-options-simple-and-handles-the-legwork-of-seo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7627:\"<p>I have been running a blog of some kind since the Spring of 2003.  In a few short months, it will be my 17th <em>blog-aversary</em>.  The most important lesson I have learned over the years is to not do more work than is necessary to publish a blog post.</p>



<p>There was a time when I fiddled with custom field boxes to fine-tune every aspect of a blog post, such as meta keywords, descriptions, titles, and much more.  However, worrying over every bit of metadata about a post became more work than actually writing the blog post itself.  It was killing my creative process.</p>



<p>I have tried numerous SEO plugins and even built such a plugin myself once.  Eventually, I would always come back to simply automating most of the process for whatever project I was working on.</p>



<p>Some SEO purists may balk at the idea.  They might argue that everything must be fine-tuned for the best results in search engines.  I could not say.  Worrying about ranking seems to be a never-ending, uphill battle.  In my experience, no particular plugin has ever given me an edge in comparison to another.  Results were always similar regardless of whether I fixated on every detail that options-filled SEO plugins offered or let an automated system generate the bits and pieces I needed.</p>



<p>I decided to give the <a href=\"https://wordpress.org/plugins/slim-seo/\">Slim SEO plugin</a> a try.  It promised to handle the dirty work and ticked most of the boxes in terms of what I was looking for in an SEO plugin.</p>



<p>Slim SEO is a plugin built by eLightUp, the company behind the <a href=\"https://wordpress.org/plugins/meta-box/\">Meta Box</a> framework and <a href=\"https://wordpress.org/themes/author/gretathemes/\">GretaThemes</a>.  Given their history of building quality extensions for WordPress, their SEO plugin made sense for a test run.</p>



<p>The plugin beautifully handles the basics that you would expect from an SEO plugin.  It automatically handles meta tags, including Open Graph Tags for social media.  It generates a sitemap of your public posts and pages.  It outputs structured data via JSON-LD with no work on the user&rsquo;s part.</p>



<p><strong>TL;DR:</strong> For users who are looking for a simple SEO solution with little legwork, Slim SEO is a solid option.  For users who want to tinker with every aspect of their SEO, look elsewhere.</p>



<h2>A Slim User Interface</h2>



<p>As a user, the things I tire of quickly the most are complex options screens.  <em>Just give me the basics.</em>  That is exactly what Slim SEO does.  It has a single options screen titled &ldquo;SEO&rdquo; under the default &ldquo;Settings&rdquo; menu in the admin.  Currently, the only options are for inputting header and footer scripts from various services, such as Google Tag Manager or Google Analytics.</p>



<p>On the post-editing screen, the plugin provides a simple meta box for customizing the meta title and description.  Users can also opt to hide the post from search engines and change the Facebook and Twitter images for the post.  And, that&rsquo;s it.</p>



<img />Per-post SEO options meta box.



<p>Each of these options can be skipped if you prefer to let the plugin handle them automatically.</p>



<p>Suffice it to say, I am a fan of the slimmed-down interface.  The plugin has no SEO scores, keyword rankings, or 20 different options to worry about.  It does not show a preview of what the post might look like in a search engine.  The options available are items that I <em>may</em> want to configure from time to time, so it&rsquo;s nice to have the ability to do so when needed.</p>



<h2>The Downsides of the Plugin</h2>



<p>Slimmed-down does not always equate to being better.  You make sacrifices by allowing the plugin to make decisions that may not always be the best for your site.  Keep these in mind when deciding whether to use the plugin.</p>



<h3>Automatic Redirects</h3>



<p>One of the biggest downsides of automated systems is that I sometimes want things to be handled differently by the plugin.  The plugin&rsquo;s automatic redirect feature is a good example of that issue.  Out of the box, the plugin will redirect all attachment page views to the media file.  It also redirects visitors to author archive pages to the home page if the author has not written any posts or on single-author sites.</p>



<p>These auto-redirects may be desirable for some end-users, but they are not something I want.  The problem is there is no clear way to disable this feature, even via code.</p>



<h3>Header Cleanup</h3>



<p>The plugin also has a &ldquo;cleanup&rdquo; feature that automatically removes the RSD link, Windows Live Writer manifest link, WordPress version number, and post shortlink from the <code>&lt;head&gt;</code> area on the front end.  It may be desirable to remove those items, but their removal would be more appropriate in a cleanup WordPress type of plugin rather than a plugin focused on SEO.</p>



<h3>Automatic Image Alt Attributes</h3>



<p>Slim SEO automatically adds the <code>alt</code> attribute to post thumbnails and when inserting images into the editor.  The problem is that it uses the attachment title.  This could make accessibility worse than simply leaving the alt attribute empty.  If your attachment title is something like <code>DS_IMG9453.jpg</code>, it does not accurately describe an image.</p>



<h3>Breadcrumbs</h3>



<p>The plugin has a shortcode for outputting breadcrumbs.  It must either be manually added to a shortcode-aware area or within a theme template.</p>



<p>The breadcrumbs functionality provides a baseline experience. It doesn&rsquo;t handle every scenario or even close to every scenario.  The feature will not get you far with highly-complex setups.   However, it would work OK for the average install. </p>



<p>That&rsquo;s par for the course with SEO plugins &mdash; mediocre breadcrumbs at best.  Frankly, SEO plugins should drop breadcrumbs from the feature list and let fully-fledged breadcrumb plugins do their thing.  Users should use opt for a plugin that specifically focuses on being a breadcrumb plugin.  Authors who build those tend to have more experience handling edge cases.</p>



<h2>How Does the Code Stack Up?</h2>



<p>From a programming perspective, the code is clean and clear.  It is 90% to the point where it should be.  The missing 10% is that there are no references to many of the objects the plugin creates.  This is not an issue limited to this plugin and is more common than it should be.</p>



<p>This issue makes it next to impossible to remove actions and filters from hooks.  For end-users, this does not matter.  For developers, it is not a frustration-free exercise to manipulate how the plugin works.  This could easily be solved in numerous ways, such as using a container, service locator, static single instance, singleton, or even a global.  Whether some of those methods should be deployed is beyond the scope of this review.  Nevertheless, <em>some</em> reference to the plugin&rsquo;s objects would help.</p>



<p>Addressing this issue would come in handy disabling those auto-redirects.</p>



<h2>The Final Verdict</h2>



<p>Aside from a handful of admittedly trivial gripes, I would use this plugin in lieu of SEO plugins with more options.  Years of running multiple sites has taught me to grab for the simplest solutions so that I can get back to doing the things I enjoy doing.</p>



<p>If you prefer to micro-manage every aspect of your SEO, there are plenty of existing options out there.  Slim SEO will not fit your needs.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 Dec 2019 20:48:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Inserting Special Characters Into the Block Editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95833\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wptavern.com/inserting-special-characters-into-the-block-editor\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3696:\"<p>For users of the Classic WordPress editor who often needed to insert special characters into their posts, life was once simple.  Click the &ldquo;&Omega;&rdquo; button in the editor to open a modal with a list of characters not found on a standard keyboard.  The user then only needed to click on the character they wanted to insert and go about the business of writing their post.</p>



<p>For users who made the move to the block editor and were accustomed to inserting special characters at the click of a button, life became more complicated.  The answer to their woes was to first insert a Classic block and use its special character inserter, which kind of defeats the purpose of using the new and shiny block editor.  Another option was to use the special character app/program packaged with their computer, which assumes all users know the keyboard shortcut for it or how to run the program.</p>



<p>By many accounts, this would be considered a <em>standard</em> feature for any text editor.  When WordPress is at a stage of trying to sell a new editor, it should be prepared to include features that users of the old editor consider standard.  The lack of a special-character inserter could have been written off as an oversight if people were not asking for it.</p>



<ul><li><a href=\"https://github.com/WordPress/gutenberg/issues/1678\">Reimplement Character Map</a></li><li><a href=\"https://github.com/WordPress/gutenberg/issues/7162\">Just a Few More Text/Paragraph Formatting Choices?</a></li><li><a href=\"https://github.com/WordPress/gutenberg/issues/8782\">Add Special Character Menu</a></li><li><a href=\"https://github.com/WordPress/gutenberg/issues/8817\">Where Are the Special Characters?</a></li></ul>



<p>People <em>were</em> asking for it.</p>



<p>Fortunately, the requests caught the attention of the 10up team.  In September this year, they <a href=\"https://10up.com/blog/2019/insert-special-characters-wordpress-plugin/\">released the first version</a> of their <a href=\"https://wordpress.org/plugins/insert-special-characters/\">Insert Special Characters</a> plugin.  It has since gone through a couple of updates and works well across browsers.</p>



<p>The plugin is simple and does its job much better than the previous Classic editor inserter.  Instead of just handling the basics, the team went above and beyond what was necessary to launch the plugin.</p>



<p>The plugin adds a new sub-menu item to the text toolbar titled &ldquo;&Omega; Special Characters.&rdquo;</p>



<img />&ldquo;Special Characters&rdquo; rich text menu item.



<p>After clicking the link to insert a special character, a modal box appears on the screen.  The box provides hundreds of special characters to choose from.  It sorts them under Miscellaneous, Math, Latin, and Arrow categories while providing a search filter to narrow down the list.  The box can also be reached by typing <code>ctrl</code>/<code>cmd</code> + <code>o</code> on the keyboard.</p>



<img />Special characters insertion modal box.



<p>Like many modals, the box pops up in a weird position from time to time, depending on where the insertion point is on the screen. Outside of that, I found no major problems with the plugin.</p>



<p>The plugin also <a href=\"https://github.com/10up/insert-special-characters/blob/1.0.2/README.md#extending\">provides a hook</a> for other developers to manipulate the tabs and available characters in the modal.</p>



<p>This does beg the question of whether the feature should be implemented in the core block editor now.  If the core team puts it in at this point, one would hope they would make it competitive with the plugin.  Anything less would be a letdown.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Dec 2019 20:46:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:112:\"WPTavern: WordPress 5.3.1 Includes Security and Bug Fixes, Accessibility Enhancements, and Twenty Twenty Changes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95815\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"https://wptavern.com/wordpress-5-3-1-includes-security-and-bug-fixes-accessibility-enhancements-and-twenty-twenty-changes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4204:\"<p><a href=\"https://wordpress.org/news/2019/12/wordpress-5-3-1-security-and-maintenance-release/\">WordPress 5.3.1 was released today</a> with 46 bug fixes and enhancements.  Changes include several accessibility improvements and four security vulnerability fixes.  The update includes multiple changes to the default Twenty Twenty theme.</p>



<p>Version 5.3.1 is a security and maintenance release.  All users are encouraged to update as soon as possible.  For those with auto-updates enabled, updates are currently rolling out.  All major branches of WordPress from version 3.7 through 5.3 received the new security fixes.</p>



<p>The following security issues were addressed:</p>



<ul><li>Users without the correct permission (capability) could make a post sticky via the REST API.</li><li>An issue where cross-site scripting (XSS) could be stored in links.</li><li>Hardening the <code>wp_kses_bad_protocol()</code> function so that it is aware of the named colon attribute.</li><li>A stored XSS vulnerability using block editor content.</li></ul>



<p>Most of the release focused on maintenance.  Form fields and buttons now have the same height, which should result in a more consistent admin UI.  This has long been an issue, but the accessibility changes in WordPress 5.3 highlighted the problem.</p>



<p>A bug with how permalinks were generated with the new Date/Time changes in WordPress 5.3 has been fixed.  This left some sites using date-based URLs with incorrect post permalinks.</p>



<p>Other changes include removing support for the CollegeHumor oEmbed provider (the site is no longer available), updating the <code>sodium_compat</code> library, and making sure admin verification emails use the user&rsquo;s locale instead of the site&rsquo;s locale.  For a full overview of all changes, visit the <a href=\"https://wordpress.org/support/wordpress-version/version-5-3-1/\">WordPress 5.3.1 release page</a>.</p>



<h2>Accessibility Improvements</h2>



<img />&ldquo;Coffee&rdquo; color scheme with new button colors.



<p>Some of the biggest accessibility changes fixed issues with the <a href=\"https://make.wordpress.org/core/2019/12/10/alternate-color-schemes-changes-in-wordpress-5-3-1/\">alternate admin color schemes</a> available in WordPress.  The accessibility improvements to buttons in WordPress 5.3 did not get carried over to most of the alternate schemes.  Or, rather, those alternate color schemes were not taken into account when the changes went into effect.  This left secondary button elements practically unreadable in some cases, which made accessibility worse.</p>



<p>Version 5.3.1 creates a unified design for secondary buttons for every color scheme.  It also makes sure that the <code>:active</code> state for buttons are consistent.</p>



<p>Other improvements to accessibility include adding underlines to links on the Dashboard screen that were not clearly links by context, properly disabling nav menu forms when they should not be in use, and adding hover effects for links on the &ldquo;About&rdquo; admin screens.</p>



<h2>Twenty Twenty Changes</h2>



<img />Author bio option in the customizer.



<p>The Twenty Twenty theme launched with JavaScript-based, smooth-scroll behavior for anchor links.  This feature did not work correctly in all cases.  It also broke anchor links to individual comments when paginated comments were enabled on a site.  </p>



<p>Version 1.1 of Twenty Twenty <a href=\"https://make.wordpress.org/core/2019/12/08/twenty-twenty-animated-scroll-changes-in-wordpress-5-3-1/\">includes CSS-based, smooth-scroll behavior</a>.  This greatly simplifies the code by using native behavior.  It also works based on the user&rsquo;s reduced motion setting for their browser, which enhances accessibility for the theme.</p>



<p>The theme update comes packaged with a new option for showing or hiding the post author bio.  The setting is available under the &ldquo;Theme Options&rdquo; section in the customizer.  It is enabled by default and will show the author bio section at the end of every post across the site.</p>



<p>The Twenty Twenty update also includes several bug fixes, most of which were trivial issues.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Dec 2019 00:58:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WordPress.org blog: WordPress 5.3.1 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8203\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2019/12/wordpress-5-3-1-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:12695:\"<p>WordPress 5.3.1 is now available!</p>



<p>This security and maintenance release features 46 fixes and enhancements. Plus, it adds a number of security fixes—see the list below.</p>



<p>WordPress 5.3.1 is a short-cycle maintenance release. The next major release will be version 5.4.</p>



<p>You can download WordPress 5.3.1 by clicking the button at the top of this page, or visit your<strong>&nbsp;Dashboard → Updates</strong>&nbsp;and click&nbsp;<strong>Update Now</strong>.</p>



<p>If you have sites that support automatic background updates, they’ve already started the update process.</p>



<h2>Security updates</h2>



<p>Four security issues affect WordPress versions 5.3 and earlier; version 5.3.1 fixes them, so you’ll want to upgrade. If you haven’t yet updated to 5.3, there are also updated versions of 5.2 and earlier that fix the security issues.</p>



<ul><li>Props to <a href=\"https://danielbachhuber.com/\">Daniel Bachhuber</a> for finding an issue where an unprivileged user could make a post sticky via the REST API.</li><li>Props to <a href=\"https://blog.ripstech.com/authors/simon-scannell\">Simon Scannell of RIPS Technologies</a> for finding and disclosing an issue where cross-site scripting (XSS) could be stored in well-crafted links.</li><li>Props to the <a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://wordpress.org/\">WordPress.org</a> Security Team for hardening <code>wp_kses_bad_protocol()</code> to ensure that it is aware of the named colon attribute.</li><li>Props to <a href=\"https://twitter.com/ducnt_\">Nguyen The Duc</a> for discovering a stored XSS vulnerability using block editor content.</li></ul>



<h2>Maintenance updates</h2>



<p>Here are a few of the highlights:</p>



<ul><li>Administration: improvements to admin form controls height and alignment standardization (see related <a href=\"https://make.wordpress.org/core/2019/12/11/admin-form-controls-height-and-alignment-standardization-in-wordpress-5-3-1/\">dev note</a>), dashboard widget links accessibility and alternate color scheme readability issues (see related <a href=\"https://make.wordpress.org/core/2019/12/10/alternate-color-schemes-changes-in-wordpress-5-3-1/\">dev note</a>).</li><li>Block editor: fix Edge scrolling issues and intermittent JavaScript issues.</li><li>Bundled themes: add customizer option to show/hide author bio, replace JS based smooth scroll with CSS (see related <a href=\"https://make.wordpress.org/core/2019/12/08/twenty-twenty-animated-scroll-changes-in-wordpress-5-3-1/\">dev note</a>) and fix Instagram embed CSS.</li><li>Date/time: improve non-GMT dates calculation, fix date format output in specific languages and make&nbsp;<code>get_permalink()</code>&nbsp;more resilient against PHP timezone changes.</li><li>Embeds: remove CollegeHumor oEmbed provider as the service doesn&#8217;t exist anymore.</li><li>External libraries: update <code>sodium_compat</code>.</li><li>Site health: allow the remind interval for the admin email verification to be filtered.</li><li>Uploads: avoid thumbnails overwriting other uploads when filename matches, and exclude PNG images from scaling after upload.</li><li>Users: ensure administration email verification uses the user&#8217;s locale instead of the site locale.</li></ul>



<p>For more information, <a href=\"https://core.trac.wordpress.org/query?status=closed&resolution=fixed&milestone=5.3.1&order=priority\">browse the full list of changes on Trac</a> or check out the&nbsp;<a href=\"https://wordpress.org/support/wordpress-version/version-5-3-1/\">version 5.3.1 HelpHub documentation page</a>.</p>



<h2>Thanks!</h2>



<p>In addition to the security researchers mentioned above, thank you to everyone who contributed to WordPress 5.3.1:</p>



<p><a href=\"https://profiles.wordpress.org/123host/\">123host</a>, <a href=\"https://profiles.wordpress.org/acosmin/\">acosmin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/aljullu/\">Albert Juhé Lluveras</a>, <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/viper007bond/\">Alex Mills</a>, <a href=\"https://profiles.wordpress.org/anantajitjg/\">Anantajit JG</a>, <a href=\"https://profiles.wordpress.org/anlino/\">Anders Norén</a>, <a href=\"https://profiles.wordpress.org/andraganescu/\">andraganescu</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey &#8220;Rarst&#8221; Savchenko</a>, <a href=\"https://profiles.wordpress.org/aravindajith/\">aravindajith</a>, <a href=\"https://profiles.wordpress.org/archon810/\">archon810</a>, <a href=\"https://profiles.wordpress.org/ate-up-with-motor/\">Ate Up With Motor</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans/\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson (birgire)</a>, <a href=\"https://profiles.wordpress.org/boga86/\">Boga86</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/littlebigthing/\">Csaba (LittleBigThings)</a>, <a href=\"https://profiles.wordpress.org/xendo/\">Dademaru</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber/\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/mte90/\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/davidbaumwald/\">David Baumwald</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion hulse</a>, <a href=\"https://profiles.wordpress.org/ehtis/\">ehtis</a>, <a href=\"https://profiles.wordpress.org/ellatrix/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/epiqueras/\">epiqueras</a>, <a href=\"https://profiles.wordpress.org/fabifott/\">Fabian</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/flaviozavan/\">flaviozavan</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/hometowntrailers/\">Glenn</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Grzegorz (Greg) Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/grzegorzjanoszka/\">Grzegorz.Janoszka</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh Pillai</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/ispreview/\">ispreview</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/macmanx/\">James Huff</a>, <a href=\"https://profiles.wordpress.org/jameskoster/\">James Koster</a>, <a href=\"https://profiles.wordpress.org/jarretc/\">Jarret</a>, <a href=\"https://profiles.wordpress.org/studiotwee/\">Jasper van der Meer</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jb Audras</a>, <a href=\"https://profiles.wordpress.org/jeichorn/\">jeichorn</a>, <a href=\"https://profiles.wordpress.org/jeremyclarke/\">Jer Clarke</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/joehoyle/\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/jrf/\">Juliette Reinders Folmer</a>, <a href=\"https://profiles.wordpress.org/justdaiv/\">justdaiv</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kharisblank/\">Kharis Sulistiyono</a>, <a href=\"https://profiles.wordpress.org/ixkaito/\">Kite</a>, <a href=\"https://profiles.wordpress.org/kyliesabra/\">kyliesabra</a>, <a href=\"https://profiles.wordpress.org/lisota/\">lisota</a>, <a href=\"https://profiles.wordpress.org/lukaswaudentio/\">lukaswaudentio</a>, <a href=\"https://profiles.wordpress.org/maciejmackowiak/\">Maciej Mackowiak</a>, <a href=\"https://profiles.wordpress.org/marcelo2605/\">marcelo2605</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius L. J.</a>, <a href=\"https://profiles.wordpress.org/mat-lipe/\">Mat Lipe</a>, <a href=\"https://profiles.wordpress.org/mayanksonawat/\">mayanksonawat</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce-Dwan</a>, <a href=\"https://profiles.wordpress.org/michael-arestad/\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/miette49/\">miette49</a>, <a href=\"https://profiles.wordpress.org/mcsf/\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/mihdan/\">mihdan</a>, <a href=\"https://profiles.wordpress.org/mauteri/\">Mike Auteri</a>, <a href=\"https://profiles.wordpress.org/msaari/\">Mikko Saari</a>, <a href=\"https://profiles.wordpress.org/gdragon/\">Milan Petrovic</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/nextscripts/\">NextScripts</a>, <a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/nielslange/\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/noyle/\">noyle</a>, <a href=\"https://profiles.wordpress.org/ov3rfly/\">Ov3rfly</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">Paragon Initiative Enterprises</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/quicoto/\">Ricard Torres</a>, <a href=\"https://profiles.wordpress.org/murgroland/\">Roland Murg</a>, <a href=\"https://profiles.wordpress.org/rmccue/\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher/\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/samuelfernandez/\">SamuelFernandez</a>, <a href=\"https://profiles.wordpress.org/sathyapulse/\">sathyapulse</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic/\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scvleon/\">scvleon</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sergiomdgomes/\">sergiomdgomes</a>, <a href=\"https://profiles.wordpress.org/sgr33n/\">SGr33n</a>, <a href=\"https://profiles.wordpress.org/simonjanin/\">simonjanin</a>, <a href=\"https://profiles.wordpress.org/smerriman/\">smerriman</a>, <a href=\"https://profiles.wordpress.org/steevithak/\">steevithak</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/dufresnesteven/\">Steve Dufresne</a>, <a href=\"https://profiles.wordpress.org/subratamal/\">Subrata Mal</a>, <a href=\"https://profiles.wordpress.org/manikmist09/\">Sultan Nasir Uddin</a>, <a href=\"https://profiles.wordpress.org/cybr/\">Sybre Waaijer</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/tanvirul/\">Tanvirul Haque</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Tellyworth</a>, <a href=\"https://profiles.wordpress.org/timon33/\">timon33</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/spaceshipone/\">Timothée Brosille</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/dinhtungdu/\">Tung Du</a>, <a href=\"https://profiles.wordpress.org/veminom/\">Veminom</a>, <a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>, <a href=\"https://profiles.wordpress.org/waleedt93/\">waleedt93</a>, <a href=\"https://profiles.wordpress.org/williampatton/\">williampatton</a>, <a href=\"https://profiles.wordpress.org/wpgurudev/\">wpgurudev</a>, and <a href=\"https://profiles.wordpress.org/tollmanz/\">Zack Tollman</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 13 Dec 2019 00:07:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Jb Audras\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:118:\"WPTavern: Gutenberg 7.1 Includes Welcome Modal, Improves Multi-Block Selection, and Adds Drag-and-Drop Featured Images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95796\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"https://wptavern.com/gutenberg-7-1-includes-welcome-modal-improves-multi-block-selection-and-adds-drag-and-drop-featured-images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7146:\"<p class=\"has-drop-cap\">The past two weeks have been blazing fast for <a href=\"https://make.wordpress.org/core/2019/12/11/whats-new-in-gutenberg-11-december/\">Gutenberg plugin development</a>.  A total of 161 pull requests (patches) were merged into version 7.1 of the plugin.  Over 20 bugs were squashed while the team added several enhancements, which include better multi-block selection, a new welcome modal, and drag-and-drop featured images.</p>



<p>The team refactored several areas of the codebase to prepare for future changes and make it possible to use new hooks.  API changes include a new <a href=\"https://github.com/WordPress/gutenberg/pull/17926\">custom select control</a>, <a href=\"https://github.com/WordPress/gutenberg/pull/18609\">text highlight</a>, and <a href=\"https://github.com/WordPress/gutenberg/pull/17603\">custom gradient picker</a> components for developers to use in their plugins.</p>



<p>The release also featured a toolbar button for switching between &ldquo;edit&rdquo; and &ldquo;select&rdquo; mode.  The select mode allows you to select blocks without opening the editing controls unless you click again within a block, which switches you back to editing mode.  The only noticeable difference is that the editing controls do not appear while in select mode.  <em>Wondering when I will ever use this feature&hellip;</em></p>



<h2>Welcome Guide Modal</h2>



<img />New welcome guide modal for first-time users.



<p>The new version of the plugin includes a <a href=\"https://github.com/WordPress/gutenberg/pull/18041\">pop-up welcome modal</a> for first-time users.  There are currently three panels with short introductions to what blocks are, how to use them, and getting to know the block library.  </p>



<p>Ideally, the modal will link out to more extensive documentation in a future iteration.  Right now, the information provided does not go into much detail.  It feels like a message to say, &ldquo;Hey, check out this shiny new thing.&rdquo;  However, there needs to be more substance for it to be helpful for first-timers.</p>



<h2>Improved Multi-block Selection</h2>



<img />Selecting multiple blocks at once.



<p>The block editor now incorporates a nicer <a href=\"https://github.com/WordPress/gutenberg/pull/16835\">native multi-block selection</a> process.  The first aspect of this change is to use the native selection color, which improves accessibility.  It also uses native selection behavior when selecting multiple blocks.</p>



<p>The second part is important because it paves the way toward partial block selection in a future release.  Currently, when selecting text across multiple blocks, the editor extends this out to select all text from the selected blocks.  In the future, it should be possible to select only part of the text across multiple blocks.  This would be consistent with normal text-based editors where users can select the last sentence from one paragraph and the first from the next, for example.</p>



<p><a href=\"https://github.com/WordPress/gutenberg/pull/18746\">Selecting multiple blocks and pasting</a> new content works correctly in 7.1.  In the past, the rich text component handled pasting.  This resulted in the blocks being split and the pasted content inserted between the split.  The block editor now handles the pasting process.  This allows users to completely replace multiple selected blocks with a paste.</p>



<h2>Drag-and-Drop Featured Images</h2>



<img />Dragging a featured image from the desktop.



<p>Instead of clicking the featured image box to open the media modal, users can now save themselves a click.  Just like dragging and dropping an image into the editor, the featured image box now accepts any image file dropped into it.</p>



<h2>Table Captions</h2>



<img />Adding a caption to the table block.



<p>For those who have long waited for a true table <code>&lt;caption&gt;</code> implementation, keep on waiting.</p>



<p>A <a href=\"https://github.com/WordPress/gutenberg/issues/11589\">year-old ticket</a> that was opened for a table caption feature was closed with a solution matching that of other blocks with captions (e.g., image, gallery).  The <a href=\"https://github.com/WordPress/gutenberg/pull/15554\">pull request</a> featured a lengthy discussion over the technical limitations of how to best handle the feature.  Ultimately, the decision was to wrap tables in a <code>&lt;figure&gt;</code> element and add the caption via the <code>&lt;figcaption&gt;</code> tag.</p>



<p>While this may work for some who need to add a caption or summary below a table, it is not currently helping users who need captions in their normal spot at the top of a table.</p>



<p>In the long run, users who need to roll out advanced tables will likely need a table block plugin anyway.  The Gutenberg and core WordPress implementation is limiting for anything beyond the most basic table output.  Real captions would have been a nice touch though.</p>



<h2>Alignment for the Navigation Block</h2>



<img />Aligning navigation block items.



<p>The Navigation block, which moved out of the experimental stage in version 7.0, has a <a href=\"https://github.com/WordPress/gutenberg/pull/18909\">new option for justifying</a> the list items to the left, right, or center.  This will be an important feature for full-site editing in the long term because users will want to set their nav menu perfectly.</p>



<p>This block will likely be in flux for a while.  There are still major questions about how navigation will work on mobile, especially as we inch closer to full-site editing.  <em>Will core play a role in making mobile menus?  Will themes be left to their own devices?  Will themes offer multiple options based on screen size?</em></p>



<h2>Moving Ahead with Templates and Full-Site Editing</h2>



<p>Coming off the heels of a somewhat controversial <a href=\"https://wptavern.com/initial-documentation-for-block-based-wordpress-themes-proposed\">documentation proposal for block-based themes</a>, version 7.1 includes a new demo block template named <code>index.html</code>.  It is a fallback template in cases where no templates are available.  This is an early, experimental step toward making full-site editing a reality.  </p>



<p>Theme developers who want to start looking at what block templates <em>could</em> look like, should <a href=\"https://github.com/WordPress/gutenberg/blob/v7.1.0/lib/demo-block-templates/index.html\">view the demo index.html template</a>.</p>



<p>Unfortunately, the release ZIP file available through the official plugin repository does not include the <code>index.html</code> template.  It was excluded because of a <a href=\"https://github.com/WordPress/gutenberg/issues/19066\">bug in the build process</a>.  However, it may be packaged in a version 7.1.1 minor release.  The file is correctly included for developers who clone from the Git repository.</p>



<p>The second step of this process was the addition of a Template Part block.  The idea for this block is that it would be a placeholder to add to templates, which would output a template part on the front end.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 11 Dec 2019 21:21:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"bbPress: bbPress 2.6.3 is out!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://bbpress.org/?p=206794\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://bbpress.org/blog/2019/12/bbpress-2-6-3-is-out/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:967:\"<p>bbPress 2.6.3 fixes <a href=\"https://bbpress.trac.wordpress.org/query?status=closed&group=resolution&milestone=2.6.3\">9 issues</a> reported by community members:</p>



<ul><li>Fixes a few typos and grammatical errors</li><li>Bumps required WordPress versions to 5.3.0 (bbPress always only officially supports the latest WordPress version)</li><li>Fixes the Forums widget displaying in the wrong order</li><li>Fixes a JavaScript error with hierarchical replies</li></ul>



<p class=\"has-text-color has-background has-very-dark-gray-color has-very-light-gray-background-color\">We&#8217;re continuing to work on improving bbPress 2.6 while also deciding what exactly will make it into 2.7.</p>



<p class=\"has-text-color has-background has-very-dark-gray-color\">Expect for the next minor release (bbPress 2.6.4) to be released sometime before Christmas 2019. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f41d.png\" alt=\"🐝\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Dec 2019 20:52:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Creator of EditorsKit Launches Community Block-Sharing Site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95775\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://wptavern.com/creator-of-editorskit-launches-community-block-sharing-site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4340:\"<img />



<p>Jeffrey Carandang, the creator behind the EditorsKit WordPress plugin, <a href=\"https://shareablock.com/introducing-shareablock-share-and-download-free-gutenberg-block-template-designs/\">launched a new community site</a> for sharing block designs and templates today.  The ShareABlock website allows visitors to download block files directly from the site and import them into the block editor.  Users can also sign up to share custom block designs and full-blown block templates.  All downloads are available for free.</p>



<p>At the moment, there are 18 block designs available for download.  There are two primary types of downloads:  block patterns and block templates. </p>



<p><a href=\"https://shareablock.com/blocks/category/block-patterns/\">Patterns</a> are smaller groupings of blocks to create a specific section for a page.  These include designs such as various hero sections, pricing lists, and a call-to-action section. </p>



<p><a href=\"https://shareablock.com/blocks/category/templates/\">Templates</a> work the same way as patterns.  However, they are larger sets of blocks designed to create an entire page.  For example, one template allows users to import a full gallery portfolio page.  Another creates an editable resume layout.</p>



<p>Other than Carandang, two other contributors have shared block designs.  This number should rise as more people sign up and decide to share their creations.  The <a href=\"https://shareablock.com/how-to-submit-design-on-share-a-block/\">registration process</a> is open to anyone who wants to join.  However, each contribution is subject to a review for quality assurance.</p>



<p>&ldquo;One of my primary goals in creating [EditorsKit] is to help users get a little more comfortable with using the new WordPress Gutenberg block editor,&rdquo; described Carandang in the announcement post for ShareABlock.  &ldquo;The goal is to help users create Gutenberg blocks easily. With drag and drop import, layout and designs will be available in an instant.&rdquo;</p>



<p>Carandang feels confident that pre-configured block designs will help users learn how to use the block editor to create richer content.  &ldquo;Even if it&rsquo;s just a little help to make them comfortable with Gutenberg, it means a lot,&rdquo; he wrote.</p>



<p>He said the feedback from users has been positive thus far.</p>



<img />Importing the Fullscreen Profile Card block pattern.



<p>Block designs downloaded from ShareABlock require the <a href=\"https://wordpress.org/plugins/block-options/\">EditorsKit plugin</a>, which is available for free in the WordPress plugin directory.  This requirement is because WordPress does not currently have a native importer built into the block editor.  In the future, this may change and the requirement could be lifted.</p>



<p>Version 1.7 of EditorsKit introduced the <a href=\"https://wptavern.com/editorskit-1-6-and-1-7-add-tools-for-writers-drag-and-drop-block-export-import\">ability to import blocks</a> by dragging and dropping a block <code>.json</code> file into the editor.  The blocks available via ShareABlock work using this feature.  After downloading a <code>.json</code> file from the site, users merely need to drag it into the editor.  Users can also use the &ldquo;Import&rdquo; block available from EditorsKit to do the same.</p>



<h2>Block Patterns and the Future</h2>



<p>&ldquo;The plan is to provide integration with Block Patterns, which is what the core devs are currently working on,&rdquo; said Carandang.  &ldquo;With this integration, the import process will be much easier.&rdquo;</p>



<p>Block patterns are a planned feature that is under <a href=\"https://github.com/WordPress/gutenberg/issues/17335\">active development</a> in the Gutenberg plugin and will eventually make its way into core WordPress. Patterns are predefined sets of blocks.  They will allow users to quickly create more advanced layouts while also teaching what specific blocks do.  The idea is to have a set of patterns with common layouts that people see around the web.  </p>



<p>Carandang said he is actively checking the progress of the Block Patterns feature.  He is eager to see the feature to come to fruition, which carries with it the possibility of more widespread use of the blocks available from his new community.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 10 Dec 2019 19:51:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"BuddyPress: BuddyPress 5.1.0 Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=309343\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://buddypress.org/2019/12/buddypress-5-1-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1258:\"<p>Immediately available is <a href=\"https://downloads.wordpress.org/plugin/buddypress.5.1.0.zip\">BuddyPress 5.1.0</a>. This maintenance release fixes 8 bugs related to the 5.0.0 release, and is a recommended upgrade for all BuddyPress installations.</p>



<p>For details on the changes, please read the <a href=\"https://codex.buddypress.org/releases/version-5-1-0/\">5.1.0 release notes</a>.</p>



<p>Update to BuddyPress 5.1.0 today in your WordPress Dashboard, or by&nbsp;<a href=\"https://wordpress.org/plugins/buddypress/\">downloading from the WordPress.org plugin repository</a>.</p>



<h2>Many thanks to 5.1.0 contributors <span class=\"dashicons dashicons-heart\"></span></h2>



<p><a href=\"https://profiles.wordpress.org/szepeviktor/\">szepe.viktor</a>, <a href=\"https://profiles.wordpress.org/jarretc/\">JarretC</a>, <a href=\"https://profiles.wordpress.org/espellcaste/\">Renato Alves (espellcaste)</a>, <a href=\"https://profiles.wordpress.org/dcavins/\">David Cavins (dcavins)</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges (boonebgorges)</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby (johnjamesjacoby)</a> &amp; <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet (imath)</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Dec 2019 21:45:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Progress on WordPress’ 2019 Projects Sets 2020 Roadmap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95761\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wptavern.com/progress-on-wordpress-2019-projects-sets-2020-roadmap\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8566:\"<p>Josepha Haden, Executive Director of WordPress, published an <a href=\"https://make.wordpress.org/core/2019/12/06/update-9-projects-for-2019/\">update of WordPress&rsquo; goals in 2019</a>.  The focus for WordPress over the past year has been on nine primary projects.  Of the nine projects, WordPress only managed to ship two in 2019.  This means that the focus in 2020 will be much the same as the community continues building on the progress it has made toward the existing projects.</p>



<p>Currently, there are three <a href=\"https://wordpress.org/about/roadmap/\">planned major releases</a> for WordPress in 2020:</p>



<ul><li>Version 5.4 &ndash; March 2020</li><li>Version 5.5 &ndash; August 2020</li><li>Version 5.6 &ndash; December 2020</li></ul>



<p>Each of those dates are subject to change.  We should also get more specific dates as each release draws near.  The various projects for 2020 should land in each release.</p>



<p>Matt Mullenweg, co-founder of WordPress, initially laid out the 2019 plans in his <a href=\"https://wptavern.com/state-of-the-word-2018-wordpress-embraces-the-block-editor\">2018 State of the Word</a> address and <a href=\"https://make.wordpress.org/core/2018/12/08/9-priorities-for-2019/\">listed the projects</a> on the Make Core blog.  The big takeaway is that 2019 was supposed to be the year that we got closer to full-site customization (Phase 2 of the Gutenberg project).  While developers have made huge strides in making that a reality, much of the project is still in its infancy.</p>



<h2>Projects That Shipped in 2019</h2>



<p>All existing core WordPress widgets now exist as blocks.  Rather than being limited to placing widgets where the theme decides, users can now put widgets in posts, pages, or any other content area via the block editor.  As the project continues to move toward full-site editing, users will eventually have the ability to place these widgets and other blocks nearly anywhere.</p>



<p>The site health project was merged into core.  It features a screen that provides information about the site&rsquo;s health to site owners.  It also has a fatal-error detection script that emails site owners when plugin and theme issues are found.</p>



<h2>Projects to Expect in 2020</h2>



<p>Most of the remaining projects that did not quite make the cut for release in 2019 have still made progress during the year.  The following is a breakdown of what projects to expect in the coming year.</p>



<h3>Navigation Menu Block</h3>



<img />Navigation block in the block editor.



<p>Currently, the navigation block&rsquo;s target is to ship with WordPress 5.4.  This is a likely reality because it is now out of the experimental stage and is available for beta testing in <a href=\"https://wptavern.com/gutenberg-7-0-launches-stable-navigation-block-post-blocks-and-template-parts\">Gutenberg 7.0</a>.  The development team worked on this block for several releases and now have something stable enough for user testing.</p>



<p>This block is a major piece of the site-customization puzzle.  In the long term, users will need an easy-to-use block for handling navigation menus across their site.</p>



<h3>Custom Block-Aware Content Areas for Themes</h3>



<p>Phase 1 of the Gutenberg project brought the block editor to post content.  A large part of Phase 2 is <a href=\"https://github.com/WordPress/gutenberg/issues/13489\">breaking outside of post content</a> and allowing users to add blocks in more areas.  It is unclear exactly what that will look like in the long run.  Themes should be able to register additional block-aware areas.</p>



<p>The target release for this feature is set to WordPress 5.5, but it is too early to guess whether that is a realistic target.  It is a tough issue to solve because it will need to coincide with decisions on <a href=\"https://wptavern.com/initial-documentation-for-block-based-wordpress-themes-proposed\">theme block templates</a>, <a href=\"https://github.com/WordPress/gutenberg/pull/18029\">saving multiple entities</a>, and <a href=\"https://github.com/WordPress/gutenberg/issues/13113\">full-site customization</a> in general.  It is not a feature that can be rushed because it will have far-reaching consequences to how WordPress works for years into the future.</p>



<h3>Widget Areas to Support Blocks</h3>



<img />Experimental widget areas feature in Gutenberg.



<p>The current plan is to allow widget areas (sidebars) to support blocks alongside widgets.  The Gutenberg plugin has an experimental widget areas option for enabling an early version of this feature, which has a target release of WordPress 5.5.</p>



<p>There are two aspects to making this feature a reality.  The first is making it work on the <a href=\"https://github.com/WordPress/gutenberg/issues/13204\">widgets admin screen</a>.  The second is making it work in the <a href=\"https://github.com/WordPress/gutenberg/issues/13205\">customizer</a>, an area where users can also manage widgets.</p>



<p>At the moment, it feels like the sidebar concept should be deprecated.  The experimental feature works by allowing users to add blocks to a sidebar, which are converted into one big &ldquo;block area&rdquo; widget on output.  If WordPress is &ldquo;all in&rdquo; on the block paradigm, energy would be better spent focusing on allowing themes to build custom block areas and letting the official Sidebar API die a slow death.  Mixing an old concept with a new one feels clunky at best.  It&rsquo;s time to move on and soft-deprecate sidebars and widgets until most themes no longer support them.</p>



<h3>Block Directory Search and Install</h3>



<img />Experimental block directory search in Gutenberg plugin.



<p>Eventually, all WordPress users will be able to search for a block via the block inserter.  If the block exists, they can insert it into the block area.  If not, the inserter will allow users to discover new blocks from the <a href=\"https://wordpress.org/plugins/browse/block/\">block directory</a>.  The installation, activation, and insertion of the new block should be seamless.</p>



<p>The target release for this feature is set for WordPress 5.5, which should be possible (if not earlier) based on how well the feature currently works in the Gutenberg plugin.  It is not perfect yet and has broken more than a few of my posts when working with installed blocks.  There are still <a href=\"https://github.com/WordPress/gutenberg/issues/17440\">several open issues</a> that need to be addressed.</p>



<p>Plugin authors who are looking to get ahead of the game can submit block plugins by following the <a href=\"https://make.wordpress.org/meta/2019/12/06/block-directory-plugin-guidelines/\">block plugin guidelines</a>.</p>



<h3>Automatic Plugin, Theme, and Major Core Updates</h3>



<p>After years of extensive testing and using automatic updates for minor WordPress releases, it feels like we should already have auto-updates on everything at this point.  Having to keep up with plugin and theme updates can be a pain for some site owners.  With enough plugins, it is not out of the realm of possibility to have one or more plugins to update daily.</p>



<p>Some hosting solutions and Jetpack have mitigated this issue for many users by offering automatic plugin updates, but this is a long overdue core feature that should be a high priority.  No target release was given for auto-updates on themes/plugins or major core releases.  Let&rsquo;s hope the feature does not get put on the back burner for another year.</p>



<h3>Tackling Over 6,500 Trac Issues</h3>



<p>With the Gutenberg plugin getting much of the attention these days, it is easy to forget that there are <a href=\"https://core.trac.wordpress.org/\">thousands of tickets</a> awaiting patches, reviews, and decisions on Trac.  I have long been a champion of using one major release of WordPress to simply fix existing bugs while adding no new features.</p>



<p>Jonathan Desrosiers has written an <a href=\"https://jonathandesrosiers.com/2019/06/wordpress-triage-team-3-month-reflection/\">extensive post</a> that covers much of the work the Triage Team has done earlier this year.</p>



<p>Triaging is not something that ever truly reaches a conclusion.  It is an ongoing process that must continue throughout the life of a project.  People who are interested in being involved with the Triage Team can find more information on the <a href=\"https://make.wordpress.org/core/2019/03/01/introducing-the-wordpress-triage-team/\">Triage Team announcement post</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Dec 2019 21:25:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"HeroPress: Video from DoSummitGood\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=3027\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:113:\"https://heropress.com/video-from-dosummitgood/#utm_source=rss&utm_medium=rss&utm_campaign=video-from-dosummitgood\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2637:\"<img width=\"960\" height=\"503\" src=\"https://s20094.pcdn.co/wp-content/uploads/2019/12/DoSummitGood-mountain_optimised-1024x536.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"\" />
<p>I recently took part in DoSummitGood, an online conference for people and organizations working to Do Good in the WordPress community.</p>



<p>The organizers managed to get recordings of all the talks on YouTube the very next day, which is pretty impressive.</p>



<p>In this talk I tell a lot more about what was going on in my personal life while spinning up HeroPress, so I recommend checking it out even if you&#8217;ve already heard the story.</p>



<div class=\"wp-block-embed__wrapper\">
<div class=\"jetpack-video-wrapper\"></div>
</div>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Video from DoSummitGood\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Video%20from%20DoSummitGood&via=heropress&url=https%3A%2F%2Fheropress.com%2Fvideo-from-dosummitgood%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Video from DoSummitGood\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fvideo-from-dosummitgood%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fvideo-from-dosummitgood%2F&title=Video+from+DoSummitGood\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Video from DoSummitGood\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/video-from-dosummitgood/&media=https://heropress.com/wp-content/uploads/2019/12/DoSummitGood-mountain_optimised-150x150.jpg&description=Video from DoSummitGood\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Video from DoSummitGood\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/video-from-dosummitgood/\" title=\"Video from DoSummitGood\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/video-from-dosummitgood/\">Video from DoSummitGood</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Dec 2019 16:13:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WordPress.org blog: People of WordPress: Jill Binder\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8192\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/12/people-of-wordpress-jill-binder/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10930:\"<p><em>You’ve probably heard that WordPress is open-source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Jill Binder</strong></h2>



<p>Jill Binder never meant to become an activist. She insists it was an accident.</p>



<p>Despite that, Jill has led the Diversity Outreach Speaker Training working group in the WordPress Community team since 2017. This group is dedicated to increasing the number of women and other underrepresented groups who are stepping up to become speakers at WordPress Meetups, WordCamps, and events.&nbsp;</p>



<h2><strong>Jill’s back story</strong></h2>



<h3><strong>Internship</strong></h3>



<p>Jill’s WordPress story begins in 2011, in Vancouver, Canada.&nbsp;Jill secured an internship for her college program, working on a higher education website that was built in WordPress.&nbsp;As a thank you, her practicum advisor bought Jill a ticket to WordCamp Vancouver 2011: Developer’s Edition. After that Jill began freelancing&nbsp; with WordPress as a Solopreneur.&nbsp;</p>



<h3><strong>First steps in the WordPress community</strong></h3>



<p>The following year her internship advisor, who had become a client, was creating the first ever BuddyCamp for BuddyPress. He asked Jill to be on his organizing team. At that event she also moderated a panel that had Matt Mullenweg on it. Then, Jill was invited to be on the core organizing team for WordCamp Vancouver.</p>



<p>Part of this role meant reviewing and selecting speakers. From 40 speaker applications that could be a fit the team had to pick only 14 to speak.</p>



<h2><strong>The diversity challenge when selecting speakers</strong></h2>



<p>For anyone who has organized a conference, you know that speaker selection is hard. Of the 40 applications, 7 were from women, and the lead organizer selected 6 of those to be included in the speaker line up.</p>



<p>At this point Jill wasn’t aware that very few women apply to speak at tech conferences and suggested selection should be made on the best fit for the conference. The team shared that not only did they feel the pitches were good and fit the conference, but they also needed to be accepted or the Organizers would be criticized for a lack of diversity.</p>



<p>Selecting women for fear of criticism is embarrassing to admit, but that’s how people felt in 2013.</p>



<p>By the time the event happened, though, the number of women speakers dropped to 4. And with an additional track being added, the number of speakers overall was up to 28. Only 1 speaker in 7 was a woman (or 14%) and attendees did ask questions and even blogged about the lack of representation.</p>



<h2><strong>What keeps women from applying?</strong></h2>



<p>Later that year at&nbsp; WordCamp San Francisco—the biggest WordCamp at the time (before there was a WordCamp US)—Jill took the opportunity to chat with other organizers about her experience. She found out that many organizers had trouble getting enough women to present.</p>



<p>Surprisingly Vancouver had a high number of women applicants in comparison to others, and the consensus was more would be accepted&nbsp; if only more would apply.</p>



<p>Jill decided that she&nbsp; needed to know why this was happening? Why weren’t there more women applying? She started researching, reading, and talking to people.</p>



<p>Though this issue is complex, two things came up over and over:</p>



<ul><li>“What would I talk about?”</li><li>“I’m not an expert on anything. I don’t know enough about anything to give a talk on it.”</li></ul>



<h2><strong>A first workshop with encouraging results</strong></h2>



<p>Then Jill had an idea. She brought up the issue at an event and someone suggested that they should get women together in a room and brainstorm speaker topics.</p>



<p>So Jill became the lead of a small group creating a workshop in Vancouver: the talented Vanessa Chu, Kate Moore Hermes, and Mandi Wise. In one of the exercises that they created, participants were invited to brainstorm ideas—this proved that they had literally a hundred topic ideas and the biggest problem then became picking just one!</p>



<p>In the first workshop, they focussed on:</p>



<ul><li>Why it matters that women (<em>added later: diverse groups</em>) are in the front of the room</li><li>The myths of what it takes to be the speaker at the front of the room (aka beating impostor syndrome)</li><li>Different presentation formats, especially story-telling</li><li>Finding and refining a topic</li><li>Tips to become a better speaker</li><li>Leveling up by speaking in front of the group throughout the afternoon</li></ul>



<img src=\"https://i2.wp.com/wordpress.org/news/files/2019/12/image-2.png?w=632&ssl=1\" alt=\"women gathering to discussion presentation topics\" class=\"wp-image-8195\" />Vancouver Workshop 2014



<h2><strong>Leading to workshops across North America and then the world</strong></h2>



<p>Other cities across North America heard about the workshop and started hosting them, adding their own material.</p>



<p>Many women who initially joined her workshop wanted help getting even better at public speaking. So Jill&#8217;s Vancouver team added in some material created from the other cities and a bit more of their own. Such as:</p>



<ul><li>Coming up with a great title</li><li>Writing a pitch that is more likely to get accepted</li><li>Writing a bio</li><li>Creating an outline</li></ul>



<p>At WordCamp Vancouver 2014—only one year since Jill started—there were 50% women speakers and 3 times the number of women applicants! Not only that, but this WordCamp was a Developer’s Edition, where it’s more challenging to find women developers in general, let alone those who will step up to speak.</p>



<h3><strong>More work is needed!</strong></h3>



<p>Impressive as those results were, the reason Jill is so passionate about this work is because of what happened next:</p>



<ul><li>Some of the women who attended the workshop stepped up to be leaders in the community and created new content for other women.</li><li>A handful of others became WordCamp organizers. One year Vancouver had an almost all-female organizing team – 5 out of 6!</li><li>It also influenced local businesses. One local business owner loved what one of the women speakers said so much that he hired her immediately. She was the first woman developer on the team, and soon after she became the Senior Developer.</li></ul>



<h2><strong>Diversity touches on many levels</strong></h2>



<p>Jill has seen time and again what happens when different people speak at the front of the room. More people feel welcome in the community. The speakers and the new community members bring new ideas and new passions that help to make the technology we are creating more inclusive. And together we generate new ideas that benefit everyone.</p>



<p>This workshop was so successful, with typical results of going from 10% to 40-60% women speakers at WordCamps, that the WordPress Global Community Team asked Jill to promote it and train it for women and all diverse groups around the world. In late 2017, Jill started leading the Diverse Speaker Training group (<a href=\"https://make.wordpress.org/community/tag/wpdiversity/\">#wpdiversity</a>).</p>



<p>Dozens of community members across the world have now been trained to lead the workshop. With now dozens of workshops worldwide, for WordPress and other open source software projects as well, there is an increase in speaker diversity.&nbsp;</p>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/12/image-3.png?fit=632%2C474&ssl=1\" alt=\"Diverse Speaker Training group \" class=\"wp-image-8196\" />WordCamp US 2019



<p>As a result of the success, Jill is now sponsored to continue the program. The first sponsor is Automattic. She’s proud of how the diversity represented on the stage adds value not only to the brand but also in the long-term will lead to the creation of a better product. She’s inspired by seeing the communities change as a result of the new voices and new ideas at the WordPress events.</p>



<blockquote class=\"wp-block-quote\"><p><em>Jill’s leadership in the development and growth of the Diversity Outreach Speaker Training initiative has had a positive, measurable impact on WordPress community events worldwide. When WordPress events are more diverse, the WordPress project gets more diverse — which makes WordPress better for more people.”</em></p><cite><em> Andrea Middleton, Community organizer on the WordPress open source project</em></cite></blockquote>



<h3><strong>Resources:</strong></h3>



<ul><li>The Workshop: <a href=\"http://diversespeakers.info/\">http://diversespeakers.info/</a></li><li>More information: <a href=\"https://tiny.cc/wpdiversity\">https://tiny.cc/wpdiversity</a></li><li><a href=\"https://make.wordpress.org/community/handbook/wordcamp-organizer/planning-details/speakers/building-a-diverse-speaker-roster/\">How to build a diverse speaker roster</a></li><li><a href=\"https://make.wordpress.org/community/2017/11/13/call-for-volunteers-diversity-outreach-speaker-training/\">Diversity Outreach Speaker Training Team</a></li></ul>



<h2><strong>Contributors</strong></h2>



<p>Alison Rothwell (<a href=\"https://profiles.wordpress.org/wpfiddlybits/\">@wpfiddlybits</a>), Yvette Sonneveld (<a href=\"https://profiles.wordpress.org/yvettesonneveld/\">@yvettesonneveld</a>), Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\">@chanthaboune</a>), Topher DeRosia (<a href=\"https://profiles.wordpress.org/topher1kenobe/\">@topher1kenobe</a>)</p>



<div class=\"wp-block-image\"><img src=\"https://lh6.googleusercontent.com/fq6qus5qmviDZaznrQnW-4wcbSs6NSrqeqEEGnPjgi2WJrVevNm4Em4KsP-VVH_0kMgWuNtW7mm_V9-hKtrrJFohRi6KrUXAoLHjrymChCltMr9fuh4dBIu_0SqNPts0MZgcvh_W\" alt=\"\" width=\"153\" height=\"115\" /></div>



<p><em>This post is based on an article originally published on HeroPress.com, a community initiative created by </em><a href=\"https://profiles.wordpress.org/topher1kenobe/\"><em>Topher DeRosia</em></a><em>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em></p>



<p></p>



<p><em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em></p>



<p><em><strong>Correction: December 7, 2019</strong><br />The original article mentioned the team Jill lead, but did not mention the team members who joined her. Those have been added. Apologies to Vanessa, Kate, and Mandi. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f642.png\" alt=\"🙂\" class=\"wp-smiley\" /> </em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Dec 2019 23:27:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Josepha\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: Zero BS CRM 3.0 Improves UI, Changes Database Structure, and Becomes More Extendable\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95739\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:103:\"https://wptavern.com/zero-bs-crm-3-0-improves-ui-changes-database-structure-and-becomes-more-extendable\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6294:\"<img />



<p>The team behind Zero BS CRM <a href=\"https://zerobscrm.com/road-to-v3/\">launched version 3.0</a> of their WordPress plugin today.  This is the first major release since the plugin was <a href=\"https://wptavern.com/automattic-acquires-zero-bs-crm-considers-rebranding-it-as-jetpack-crm\">acquired by Automattic in August</a>.  The updated plugin uses custom database tables, opens the plugin for more extensions, and has a more consistent UI than previous versions.</p>



<p>CRM is an acronym for &ldquo;customer relationship management.&rdquo;  CRM systems allow businesses to manage their customer relationships through an interface.  How CRM systems work can vary greatly, depending on the software used.  In general, the goal is to help manage contacts, sales, and productivity.</p>



<p>Zero BS CRM was co-created by Mike Stott and Woody Hayday.  Despite a low number of plugin users (around 1,000 at acquisition), Automattic acquired the plugin based on the strength of the product.  Currently, Stott and Hayday are the primary developers on the plugin and maintain more than 30 commercial extensions for it.</p>



<p>Many CRM solutions are SaaS products, such as Salesforce CRM and HubSpot CRM.  &ldquo;The main benefit of ZBS CRM over online SaaS type solutions is it sits in your WP admin dashboard, and you own your own data,&rdquo; said Stott.</p>



<p>Version 3.0 of the plugin improves in several key areas.  One major change is the switch to custom database tables rather than pigeon-holing everything into a custom post type.  This change should speed up accessing data such as contacts and transactions in large databases.</p>



<p>Users should benefit from a much improved and consistent UI from previous versions.  Zero BS CRM does not strictly follow the core WordPress admin UI.  &ldquo;When looking at ZBS CRM and how to tie in all our menu items into the WordPress UI &ndash; it wasn&rsquo;t easy,&rdquo; said Stott.  &ldquo;We settled on using a UI framework with our own top menu, and a natural follow-on for that was to draw our list views using that same UI and button systems. Whether we move this back or not depends on feedback from our users &mdash; we get a lot of positive feedback on how easy it is to navigate around and wouldn&rsquo;t want to change something that&rsquo;s been getting good feedback.&rdquo;</p>



<img />Contact management screen in the Zero BS CRM plugin.



<p>Moving to custom tables over custom post types has also helped improve elements of the UI.  Stott said a huge advantage is not having third-party plugins accidentally adding themselves to the plugin&rsquo;s admin pages, such as having unnecessary SEO options on contact records.</p>



<p>Another big change in 3.0 was building out a more extendable foundation for the plugin.  This will open up custom CRM objects in the future.  For example, plugin users could manage resources such as &ldquo;properties&rdquo; or &ldquo;campuses&rdquo; along with customer contact data.  This update creates more potential for industry-specific extensions.</p>



<p>&ldquo;It really opens the door for more extendibility in the future,&rdquo; said Stott, &ldquo;and through an improved API in 2020 will allow for us to do more work across platforms and open up our CRM tools to more people.&rdquo;</p>



<p>The Zero BS CRM plugin remains free and is <a href=\"https://wordpress.org/plugins/zero-bs-crm/\">available in the WordPress plugin repository</a>.  The primary source of income comes from its extension bundles, which are priced monthly and billed yearly.  The website currently offers freelancer ($11/month), entrepreneur ($17/month), and elite ($30/month) pricing options.  It also has a reseller plan available.</p>



<h2>The Move to Automattic</h2>



<p>When the plugin was first acquired, there was an initial idea to rebrand as &ldquo;Jetpack CRM.&rdquo;  However, they have maintained the Zero BS CRM branding with an acronym instead of the direct expletive for &ldquo;BS.&rdquo;  A rebrand may still be on the table in 2020 or beyond.</p>



<p>&ldquo;We&rsquo;ve been gathering user feedback and sentiment following the minor changes to ZBS CRM and the initial reactions if we were to rename as Jetpack CRM,&rdquo; said Stott.  &ldquo;Since the shorter name, there&rsquo;s been less objection or negative feelings, which puts less pressure on a big rebrand project, but it&rsquo;s certainly something we&rsquo;ll be coming back to.&rdquo;</p>



<p>Stott said the primary focus since the acquisition has been less on branding and more on delivering 3.0 to the existing customer base.</p>



<p>The acquisition by Automattic has helped with how their two-person team works.  &ldquo;The main thing is being able to lean on the amazing team and people throughout Automattic,&rdquo; said Stott.  &ldquo;In the past, we&rsquo;d only have Woody and my input, now we can reach out to experts in design, marketing, plus much more, and bounce our ideas around a vast pool of experience.&rdquo;</p>



<p>He explained that the additional support resources of Automattic&rsquo;s Happiness Engineers means that he and his partner can focus more on engineering and growing the product and team.</p>



<p>The acquisition of Zero BS CRM came during a busy year for Automattic.  With major moves such as <a href=\"https://wptavern.com/automattic-acquires-tumblr-plans-to-rebuild-the-backend-powered-by-wordpress\">acquiring Tumblr</a> and the <a href=\"https://wptavern.com/automattic-raises-300m-in-series-d-investment-round-valuation-jumps-to-3-billion\">Salesforce investment</a>, this small plugin has mostly flown under the radar in comparison.  Stott and Hayday have big plans for 2020.  They would like to grow the engineering team and explore bringing their tools to more WordPress.com users.</p>



<p>The plugin&rsquo;s growth has remained stable since the acquisition, according to Stott.  &ldquo;The announcement brought us some additional customers who saw the backing from Automattic as strong advocacy for the plugin over other solutions in the WordPress space, so they made the decision to join us,&rdquo; he said.  The plugin has doubled its active install count and now serves over 2,000 users.  The team expects to continue growing in the coming months.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 06 Dec 2019 20:43:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"WPTavern: Gutenberg: One Year Later\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95698\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wptavern.com/gutenberg-one-year-later\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9610:\"<p>As we quickly head into the final weeks of 2019, we also pass the first anniversary of WordPress 5.0 and, subsequently, Gutenberg coming headlong into our lives. </p>



<p>Love it or hate it, Gutenberg is here to stay.  If you had asked my thoughts on it last December, I would have probably sided with a large portion of other WordPress users.</p>



<p><em>What are you doing?</em></p>



<p><em>WordPress is fine, leave it alone!</em></p>



<p><em>Stop forcing me to use this!</em></p>



<p>Here we are, twelve months later, and you know what? I LOVE IT.  And, I am not alone.</p>



<p>When it comes to writing content, I cannot <em>imagine</em> using the Classic Editor anymore. Sure, for a few paragraphs, the Classic Editor is fine.  However, when you need to make a 4,000+ word post, Gutenberg and the new block system make things a lot easier.</p>



<p>Yes, the UI is a struggle for someone brand new to WordPress.  We have all heard the &ldquo;<em>Wait, I thought you said this was like Word?</em>&rdquo; line.  A good onboarding process would tackle that going forward.  For the rest of us, if you have not adopted Gutenberg yet, you should take another look at it.</p>



<h2>The Need for a New Editor</h2>



<p>Let&rsquo;s be honest.  The Classic Editor was great for short posts, a couple of headlines and paragraphs, job done.  But, how often were you going into the Text tab to remove an extra line break, fix a shortcode, or cut and paste a section to somewhere else in the post?&nbsp; At best, it was a struggle.  Often, it was excruciating to get your post <em>just right</em> before publishing.</p>



<p>Not only will I <em>not</em> miss this, but I am pleased that new users will not be exposed to it anymore either.</p>



<img />Classic Editor &ndash; Text tab in action



<p>When I first heard of Gutenberg &mdash; before it was released in WordPress 5.0 &mdash; I installed the plugin and was immediately confused and slightly bewildered at the options. I wondered how I would edit in the future. </p>



<p>I, among many others, probably gave out the same noises as when Facebook and Twitter reveal a huge overhaul of their UI, agreeing with everyone that things would never be the same again. <em>This was a mistake. </em>Of course, I was both right and wrong at the same time.  I just didn&rsquo;t know it.  Editing would not be the same again.  Instead, it would be a lot better (with some adjustment).</p>



<p>I also know that many people will not agree with me and do not like the way Gutenberg looks or behaves to this day. But, if you give it some time and understand how it can make your life easier, it will do just that.</p>



<p>First, take the time to work out the difference between Blocks and Document. On the left you have all the blocks for your post or page, inserting them in merrily as you go. On the right, the Document panel controls everything else, handily changing when you need to fine-tune a block.</p>



<img />Gutenberg block editor in action



<p>One of the most common complaints I have read is people struggling with the toolbar that appears as you hover over each block. There is a simple solution to this, and when it is enabled, the majority of people suddenly start to love it! Make sure you set the view to &ldquo;Top Toolbar&rdquo; in the Gutenberg options. Now you have a distraction and clutter-free editing environment to work with.</p>



<h2>Gutenberg vs. Page Builders</h2>



<p>Gutenberg is not a page builder, and it is a common argument thrown out by people on why they refuse to use it. They are right, it is not a replacement for the likes of Elementor or Beaver Builder.  If you remove the comparison to page builders from your mind, you will find adapting to it is much easier.</p>



<p>My peers and I regularly chat about Gutenberg and agree it is already great for writing.  The post creation process is a breath of fresh air.  Others have great stories from their clients about being able to produce content and edit it with ease, and the number of editor-related support requests is down, which can only be a good thing.</p>



<p>However, many of us would not use it for designing pages. Instead, we still prefer to use one of the many page builders for that complete control.</p>



<p>Gutenberg Phase 2 will allow editing of the site to areas outside of the main content (e.g., headers, footers, sidebars) and will creep further into the page builder category, which means we will have a strange blend of Gutenberg and page builders living side by side on many sites soon.</p>



<p>Will it remove the complete need for themes? Who knows? I suspect we will have people further divided into opposing camps going forward, but what a great opportunity for us to collectively work on for a better overall experience in the end.</p>



<h2>By the Numbers</h2>



<p>Let us take a quick look at Gutenberg and its penetration to date.</p>



<p>Currently, 63.8% of all WordPress installs are running 5.x onward according to WordPress.org, which means Gutenberg is available natively on nearly two-thirds of all WordPress installs.</p>



<p>But, it is not all red roses when it comes to adoption. </p>



<p>The Classic Editor plugin has over 5 million active installs (and a rather biased 723 five-star reviews, such as &ldquo;Keep this forever&rdquo; and &ldquo;Never going to give it up!&rdquo;). It is also currently in the top five of the most popular plugins. </p>



<p>Is this the backlash against Gutenberg or incompatibility with older themes forcing users to use the Classic Editor for now? At a guess, a good majority is probably the latter combined with some diehards. </p>



<p>But, look at the graph below from the <a rel=\"noreferrer noopener\" class=\"ek-link\" href=\"https://wordpress.org/plugins/classic-editor/\" target=\"_blank\">Classic Editor plugin page</a>.</p>



<img />



<p>Growth is declining. That is not a movement of people who continue to install Classic Editor on new installs and refuse to adapt.</p>



<p>Classic Editor adoption will likely continue falling, and perhaps the original date of it being supported until 2022 isn&rsquo;t that far-fetched after all (note: they have said they will continue to support it longer if needed).</p>



<p>On the flip-side, the Gutenberg plugin has 200,000 active installs and a whopping two-thirds of reviews (2,003) are a paltry one star. However, many are merely unhelpful complaints (e.g., &ldquo;This is junk&rdquo; and &ldquo;Destroy it&rdquo;).  They do not tell the true story to novices.</p>



<p>As you can see from the graph below for the Gutenberg plugin, active install growth is up and continues to climb.  It is not at the same pace as the decline with the Classic Editor, but that is probably because it is bundled with WordPress now.</p>



<img />



<p>One thing people seem to forget is Gutenberg is a plugin in and of itself.  It is updated frequently, whereas the majority of users only see changes to it when there is a WordPress core update.</p>



<p>If you can see past the fields of one-star reviews and install the plugin, you will be rewarded with more frequent updates to the experience. </p>



<p>For example, version 7.0 recently added in the Navigation block as stable, allowing users to quickly create a menu of links. Don&rsquo;t get me wrong; this does require theme integration for it to work, but you can get a better idea of where it is heading on a more frequent basis this way (7.0 is expected to ship with WordPress 5.4 in March/April 2020).</p>



<h2>Block Party</h2>



<p>Compatibility with Gutenberg continues at a quick pace.  With over 21 pages of block-enabled plugins available on WordPress.org, pretty much all the popular plugins have solutions in place.  A fair amount of plugin updates these days are also adding new and enhanced blocks as standard.</p>



<p>If those are not enough for you, we also now have a new breed of block-specific plugins. There is a growing trend of plugins devoted to purely enhancing the style and number of blocks you can add to your site.</p>



<p>Popular Gutenberg-focused plugins such as <a class=\"ek-link\" href=\"https://wpstackable.com\">Stackable</a> and <a class=\"ek-link\" href=\"https://editorskit.com\">EditorsKit</a> add further styling and editing abilities, bringing you another step closer to full-page design and enhancing your content.</p>



<img />EditorsKit &ndash; a purely Gutenberg plugin.



<p>Because no one knows how far Gutenberg will go and which toes it will step on, block plugins may have a fight on their hands in the future.  At the pace they are being released and updated, it is a good sign of a committed global collective who not only believe in the future of blocks but is excited about it too.</p>



<h2>What Does the Future Hold?</h2>



<p>Gutenberg is here to stay, and I don&rsquo;t think any of us have ever denied that. It is probably not an issue for anyone who started using WordPress for the first time this year.</p>



<p>Thankfully, for those already deeply embedded in WordPress, things are getting easier (and I would say more enjoyable) with the growth of the new Gutenberg-specific plugins.</p>



<p>With the advent of platforms such as Wix and Squarespace, it was obvious that WordPress needed <em>something</em> to make it more user-friendly and Gutenberg is a solid attempt at that. It is still a bit rough around the edges, but the days we look back nostalgically at the Classic Editor are likely numbered.</p>



<p>How will it look at the end of 2020? Will you still be using the Classic Editor?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 05 Dec 2019 17:49:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Chris Hughes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: Initial Documentation for Block-Based WordPress Themes Proposed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95687\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/initial-documentation-for-block-based-wordpress-themes-proposed\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7198:\"<p class=\"has-drop-cap\">In a pull request on the Gutenberg repository yesterday, Riad Benguella <a href=\"https://github.com/WordPress/gutenberg/pull/18890\">created an initial document</a> that outlines how block-based WordPress themes might work.  While the document is merely a starting point for the conversation, it is a set of ideas that will likely forever reshape the WordPress landscape.  It is paradigm-shifting.</p>



<p>For the first time, theme authors can glimpse what their future holds.  Since the inception of Gutenberg, many have asked for more technical details.  Particularly, they wanted to know whether themes would be reduced to a stylesheet or a stylesheet and a few PHP files.  <em>What would themes look like architecturally?  Would themes exist at all?</em></p>



<p>The document, while open for changes, makes a strong case about the structure of themes going forward.  It is clear that much forethought has gone into the proposal.  It matches the direction of the experimental site-editing feature in Gutenberg that has already been set in motion.  Even though it is subject to change, there seems to be a finality to the overarching idea.  The writing has long been on the wall.  Now everyone can see the wall.  The missing piece is figuring out how to bring the idea to fruition.</p>



<h2>What is Full Site Editing?</h2>



<p>Before understanding how themes of the future might work, you must first understand the direction that Gutenberg is headed.  The end goal for Gutenberg, and eventually WordPress, is for users to have the ability to customize every aspect of their site via the block system.  Currently, the block system primarily handles editing post content.</p>



<p>To move to full-site editing, every piece of dynamic data about a site must be a block.  For example, a site title block must exist as a placeholder for the site title.  Users should be able to place it anywhere they desire to output the title, such as in the header.</p>



<p>This has left theme authors with a reasonable question:  If users can move these blocks anywhere, where do themes fit into the picture?</p>



<p>It is easy to see how themes would become little more than a stylesheet that styles every WordPress block while also handling other necessary styles like typography and vertical rhythm.  Even then, it makes one wonder if themes, at least in how we have come to know them, are necessary at all.</p>



<h2>The Proposed Theme Structure</h2>



<p>The proposed structure does not look much different from current WordPress themes.  The big difference is that theme templates would become &ldquo;block templates&rdquo; and &ldquo;block template parts.&rdquo;  These templates would be HTML files rather than PHP files.</p>



<p>The following is where the structure currently stands.</p>



<pre class=\"wp-block-code\"><code>theme
|__ style.css
|__ functions.php
|__ block-templates
    |__ index.html
    |__ single.html
    |__ archive.html
    |__ ...
|__ block-template-parts
    |__ header.html
    |__ footer.html
    |__ sidebar.html
    |__ ...</code></pre>



<p>From a templating perspective, it appears relatively <em>normal</em> for a WordPress theme.  The files simply have a different type and are organized in specific folders.</p>



<p>However, the difference is how the HTML templates would work.  They would essentially become placeholders for blocks.  Users would also have the ability to edit or completely overwrite individual templates via the WordPress admin.  Because templates are made up of blocks, no code would be necessary on the user&rsquo;s part.  They could simply point and click to insert or remove blocks with their mouse.  </p>



<p>In other words, block templates within themes would be unique starting points for users to build their sites.</p>



<p>There are two noteworthy items about the proposed system:  themes are still themes and end-users can become theme builders.</p>



<h3>The Essence of a Theme Remains the Same</h3>



<p>When you cut through everything else, WordPress themes have always been HTML and CSS.  The PHP aspect of theming basically mixes PHP function calls (i.e., template tags) within some structured HTML markup.  If you look at most themes going through the official WordPress theme directory, you will find that the underlying markup is mostly the same.</p>



<p>In the block template system, this idea doesn&rsquo;t change.  If anything, it could simplify the role of theme author by creating a set of standard elements (blocks) that themes output.  If done right, it also creates a standard for class names so that styles can easily be shared across themes and all sorts of similar goodies.</p>



<h3>Anyone Can Build a Theme</h3>



<p>The initial outline explains the potential of exporting themes:</p>



<blockquote class=\"wp-block-quote\"><p>Ultimately, any WordPress user with the correct capabilities (example: administrator WordPress role) will be able to access these templates in the WordPress admin, edit them in dedicated views and potentially export the templates as a theme.</p></blockquote>



<p>This is where the proposed system could revolutionize website building.  Those without the coding skills to create a WordPress theme today could have the tools to contribute something back tomorrow.</p>



<p>The idea aligns perfectly with the open-source ethos of WordPress.  By giving everyone the ability to export their customizations, it provides an avenue for contributing that we have never had before for non-coders.  <em>A free directory of customized themes created by and for the community, anyone?</em></p>



<h2>The Design Side of the Equation</h2>



<p>Block templates are merely the HTML.  Themes will need to stand apart with their CSS.  However, there must be standardization to pull this off.</p>



<p>Designers will need to shift to a block-based approach when it comes to design.  Some may already be familiar with various &ldquo;component-based&rdquo; systems, which would work much the same way.  Rather than designing from the top-down, theme authors would approach design on a more atomic level by designing each block.</p>



<p>There are also many unanswered questions about how styles will eventually work.  Currently, there is an open ticket for <a href=\"https://github.com/WordPress/gutenberg/issues/9534\">discussing a style system for blocks</a>.  Much of the discussion is around how to integrate a design system with themes.</p>



<h2>Join the Discussion</h2>



<p>It is important to point out that nothing about this proposal is set in stone.  It is a high-level outline of what the future of themes could hold.  However, now is time for input from the community, especially theme authors who may have felt a bit out of the loop in the past.  Now is the time to make your voice heard and to contribute ideas to the discussion.</p>



<p>The WordPress theme review team also has an <a href=\"https://make.wordpress.org/themes/2019/12/04/questions-about-the-future-of-themes/\">open discussion on the future of themes</a> that goes along with this proposal and whether themes should start taking advantage of experimental Gutenberg features.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 04 Dec 2019 20:56:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Black Friday Banner Gone Wrong: Advertising in Free Plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95661\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/black-friday-banner-gone-wrong-advertising-in-free-plugins\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6514:\"<img />Screenshot of the Yoast Black Friday Ad



<p>On November 28, millions of people awoke to a Black Friday ad on nearly every page of their WordPress admin, courtesy of the <a href=\"https://wordpress.org/plugins/wordpress-seo/\">Yoast SEO plugin</a>.  That day also coincided with the U.S. Thanksgiving holiday, so it left freelancers and agencies scrambling to address a banner on their clients&rsquo; sites on a day they likely planned to spend with family.  The ad was not limited to users with administrative permissions either, so some site owners were troubled to find users with low-level permissions could see the ad in the WordPress admin.</p>



<p>The initial code for the banner was <a href=\"https://github.com/Yoast/wordpress-seo/commit/bf13569fa7a25aacac72e8b92c577adcafa9ccc6#diff-9ac66dbc3ac65e9898209f08c006799c\">added on October 25</a>, which made its way into version 12.4 of the Yoast SEO plugin.  The code for the banner ad limited its output between November 28 and December 3 (Cyber Monday).</p>



<p>After blowback from users, the Yoast team published an updated version of the plugin without the banner.  However, the initial damage was done.  Users began immediately <a href=\"https://wordpress.org/support/plugin/wordpress-seo/reviews/?filter=1\">leaving poor reviews</a> for the plugin.  The 1-star reviews are still coming in, putting the number over 100 in the span of five days.</p>



<p>&ldquo;That BlackFridayBanner was not the best idea,&rdquo; wrote Marieke van de Rakt, CEO of Yoast, <a href=\"https://twitter.com/MariekeRakt/status/1200077958700044290\">on Twitter</a>. &ldquo;We&rsquo;re truly sorry for the annoyance and difficulties it may have caused. We did not think this through properly. If you want, you can update to a new version of our plugin without that banner.&rdquo;</p>



<p>The initial decision to place the ad was about growth for Yoast&rsquo;s premium products.  The company has not grown as fast as expected over the past year explained van de Rakt.  They had also seen other plugins use those types of ads, which was a part of the decision to run it.</p>



<p>&ldquo;Let&rsquo;s be clear,&rdquo; said van de Rakt.  &ldquo;This was a mistake. We just didn&rsquo;t think this one through. It was incredibly stupid. So I can talk about why we made a decision, but I don&rsquo;t want that to be the explanation. The explanation is that we made a mistake.&rdquo;</p>



<p>The ad was an animated banner, and some users complained that it was difficult to dismiss.  All notices in plugins available through the WordPress plugin directory must be dismissible.  &ldquo;That was a technical mistake,&rdquo; said van de Rakt of the issues with clicking the &ldquo;x&rdquo; icon for dismissal.</p>



<p>While the team had seen other plugins run similar ads in the past, van de Rakt explained that they didn&rsquo;t take into account how large of a user base Yoast SEO has in comparison to those plugins.  &ldquo;For so many users, we were the first plugin that done this,&rdquo; she said.  &ldquo;They never saw this before in their backend. And they freak out. This was a complete error of judgment.&rdquo;</p>



<p>Yoast plans to talk more with its plugin&rsquo;s users.  Currently, the team is looking into creating a user-testing panel to prevent similar situations in the future.</p>



<p>&ldquo;In hindsight, and that&rsquo;s what I feel most bad about, the banner did not fit our values,&rdquo; said van de Rakt.  &ldquo;These kinds of banners are not &lsquo;Yoast.&rsquo; Perhaps, if we state more explicitly what we as Yoast find important and what fits Yoast and what doesn&rsquo;t, a mistake like this will be made less quickly.&rdquo;</p>



<h2>Making Money with Freemium Products</h2>



<p>Yoast is a large company within the WordPress space.  It employs 90 people in its primary office in Wijchen, the Netherlands.  It also has an additional 20 employees around the world.  Running a successful business means paying everyone, contributing back to WordPress with its five-for-the-future work, and running charitable programs such as the Yoast Diversity Fund.</p>



<p>Currently, the Yoast SEO plugin has over 5 million active installs.  According to van de Rakt, only around 2% of the plugin&rsquo;s users also use the company&rsquo;s premium products.  Such a large plugin needs continuous funding to support and maintain.</p>



<p>Advertising a product or service in an internet culture that is seemingly averse to ads is not always easy.  &ldquo;It&rsquo;s rather hard to find ways to reach our audience, and we also have some principles on how (not) to do that,&rdquo; said van de Rakt.  &ldquo;We like to advertise in a straight-forward way. Tell people what they&rsquo;re buying. Ads are very annoying, but at least they are clear in what they&rsquo;re doing.&rdquo;</p>



<p>One issue that plugin companies run into is the lack of an official premium marketplace for WordPress.  Currently, companies have to resort to in-admin advertising or similar tactics to push users on an upsell.  Most of Yoast&rsquo;s premium products are sold through banners on the plugin&rsquo;s pages in the WordPress admin.  Such practices do not always go over well with users, particularly when they are using a free product.  One wrong step and it could spell disaster for future growth.  Yoast is large enough to bounce back, but smaller companies may struggle more.</p>



<p>It is a tough balancing act between providing a valuable free product and making enough of a return to run a successful company.  The Yoast team does not want to lock their popular SEO plugin completely behind a paywall.  &ldquo;Our mission is SEO for everyone,&rdquo; said van de Rakt.  &ldquo;We believe that every idea should have a fair chance in the search results. That means that also without any funds, people should be able to have a good working SEO plugin. Our free plugin is really important to us.&rdquo;</p>



<p>&ldquo;I had a really bad weekend,&rdquo; said van de Rakt.  &ldquo;I am a people pleaser and I was terribly sad by what happened. But, the discussion about how to handle this is a good one.&rdquo;</p>



<p>Perhaps some good will come of this incident if there is an open dialogue.  &ldquo;These kinds of things sometimes lead to different &lsquo;rule-sets&rsquo; or policies within WordPress,&rdquo; said van de Rakt.  &ldquo;Might even mean that there will be different and better ways for premium plugins to market their products.&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Dec 2019 20:53:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"BuddyPress: ​​Contributing to BuddyPress just got easier :)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=309282\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://buddypress.org/2019/12/bp-beta-tester-1-0-0/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1940:\"<p>Yesterday morning we’ve deployed the first stable version of the BP Beta Tester plugin on the WordPress.org plugins directory.​​</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"wp-embedded-content\"><a href=\"https://wordpress.org/plugins/bp-beta-tester/\">BP Beta Tester</a></blockquote>
</div>



<p>This plugin’s goal is to make it easier to beta test our pre-releases. You just need to install and activate the plugin to be ready to try our beta and release candidate versions once we’ve announced them on this blog.​​<br />​<br />Beta testing BuddyPress is very important to make sure it behaves the right way for you and for the community. Although we, the BuddyPress Development Team, are regularly testing it, it’s very challenging to test every possible configuration of WordPress and BuddyPress. That’s why we absolutely need your help during these pre-release stages.​​</p>



<p>Making this plugin available was one of the means we thought about during our post 5.0.0 release development meeting to have more BuddyPress contributors.​​<br />​<br />Beta testing is actually a good way to start contributing, to anticipate and fix potential issues before you have the bad surprise to meet them once you&#8217;re upgrading to a new stable version of the plugin.​​</p>



<p><strong>NB:</strong> to beta test BuddyPress, we strongly advise you to have a local copy of your live site or a staging site : it’s always safer than doing it on a production site.​​</p>



<p>During our next pre-release stages, when you will find something is going wrong during your beta tests, please think of warning us about it submitting a ticket on our <a href=\"https://buddypress.trac.wordpress.org/newticket\">Development Tracker</a> or posting a new topic in our <a href=\"https://buddypress.org/support/\">support forums</a>.​​</p>



<p>Thanks in advance for your time and help &lt;3</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 03 Dec 2019 12:27:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: Gutenberg 7.0 Launches Stable Navigation Block, Post Blocks, and Template Parts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95640\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"https://wptavern.com/gutenberg-7-0-launches-stable-navigation-block-post-blocks-and-template-parts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7072:\"<p>On November 27, <a href=\"https://make.wordpress.org/core/2019/11/27/whats-new-in-gutenberg-27-november/\">Gutenberg 7.0 landed</a> with several features, enhancements, and bug fixes.  Most notably, the navigation block is now a stable feature.  Theme authors can also start using block template parts and testing the post title and content blocks.</p>



<p>The update addressed several bugs with the block editor.  It also introduced new developer features such as the <a href=\"https://github.com/WordPress/gutenberg/pull/17963\">card component</a> and the ability to <a href=\"https://github.com/WordPress/gutenberg/pull/17376\">internationalize strings with safe HTML</a>.</p>



<p>Gradient classes are now <a href=\"https://github.com/WordPress/gutenberg/pull/18590\">used for the cover block</a>.  Classes are a nicer solution than the inline styles used in earlier iterations.  Note that gradients are still an experimental feature.</p>



<p>For developers, there is a new <a href=\"https://github.com/WordPress/gutenberg/tree/master/docs/designers-developers/developers/backward-compatibility\">backward-compatibility document</a> that outlines how the project preserves compatibility in its public APIs. This should be useful for all developers working on the project in the future.</p>



<h2>Navigation Block Now Stable</h2>



<img />Creating a nav menu with the navigation block.



<p>The navigation block is now a stable feature and no longer considered experimental.  The interface is much improved over earlier implementations.  For quickly building a menu of links, it does the job.  Users can manually type a link or search for an existing link for the site.</p>



<p>A user interface for nav menus in the block editor is no easy beast to tame.  The Gutenberg team managed to fit in the most common features without making it feel confusing.  For users, theme integration may be limited until their themes are updated with full support.  The default Gutenberg design may not be ideal or work at all in the context of the active theme.</p>



<p>The navigation block also comes with both light and dark block styles.  Theme authors can design these how they prefer, add additional styles, or remove the styles altogether.  More than likely, theme authors will begin adding several variations to their themes as a selling point in the long run.</p>



<p>The Gutenberg team dropped the background color option from the navigation block. Instead, users are encouraged to place it within a group block and add a background to the group. It is possible to change the link text color directly within the navigation block.</p>



<p>Currently, there is no parity between normal nav menu HTML classes and navigation block classes.  This could result in bulkier theme CSS, at least in the transition between how themes currently work and  the full site-editing era.  Inconsistent classes is an issue that should be handled with a <a href=\"https://wptavern.com/themes-of-the-future-a-design-framework-and-a-master-theme\">design framework</a>.</p>



<h2>Post Title and Content Blocks Added</h2>



<img />Customized post title block output.



<p>As part of the experimental site-editing feature, Gutenberg has introduced the <a href=\"https://github.com/WordPress/gutenberg/pull/18461\">post title and post content blocks</a>.  These blocks act as placeholders and will output either the title or content.  Both blocks are foundational elements for true full-site editing.  Eventually, users will no longer be as limited to how their posts are output on the screen.</p>



<p>Currently, the post title block simply outputs the post title inside of <code>&lt;h1&gt;</code> tags. There are no classes for customizing the design. The other missing element at this point is the post byline or meta area that often accompanies the title.  In the long run, Gutenberg needs to have a method of handling post header and footer areas.</p>



<p>The custom post header feature has plagued theme authors for years, long before Gutenberg was around.  There are dozens or more implementations in the wild.  Some of them work with the block editor.  Others use custom post meta or the featured image.  However, users are often left with sub-par implementations that don&rsquo;t always work in the context of a specific post.</p>



<p>One of the features I have wanted to implement within Gutenberg is the &ldquo;hero&rdquo; image with text set over the top.  By using the built-in cover block and the post title block, I was able to accomplish this.  However, it was still missing the post byline.  Therefore, I put together a quick filter to output the post byline when the post title block is in use.</p>



<p><em>Any theme author who wants to test it out can modify the following code. I would not recommend this in production since this is an experimental feature, but it is good to start thinking ahead about possibilities.</em></p>


<pre class=\"brush: php; auto-links: false; gutter: false; title: ; wrap-lines: false; notranslate\">
add_filter( \'pre_render_block\', function( $block_content, $block ) {

    if ( \'core/post-title\' === $block[\'blockName\'] ) {

        $post = gutenberg_get_post_from_context();

        if ( ! $post ) {
            return $block_content;
        }

        if ( \'post\' === $post-&gt;post_type ) {

            $block_content = \'&lt;h1 class=\"entry__title\"&gt;\' . get_the_title( $post ) . \'&lt;/h1&gt;\';

            $block_content .= sprintf(
                \'&lt;div class=\"entry__byline\"&gt;%s &amp;middot; %s &amp;middot; %s&lt;/div&gt;\',
                get_the_author(),
                get_the_date(),
                get_the_term_list( $post-&gt;ID, \'category\' )
            );
        }
      }

    return $block_content;

}, 10, 2 );
</pre>


<h2>Block Template Parts for Themes</h2>



<p>Gutenberg 6.9 <a href=\"https://wptavern.com/gutenberg-6-9-introduces-image-titles-block-patterns-and-new-theme-features\">introduced block templates</a> that resolve from a theme&rsquo;s <code>/block-templates</code> folder as part of the site-building experiment.  Version 7.0 takes that a step farther and introduces a <a href=\"https://github.com/WordPress/gutenberg/pull/18339\">block template parts system</a>, which resolves from a theme&rsquo;s <code>/block-template-parts</code> directory.</p>



<p>This new system allows top-level templates to house smaller, reusable template parts.  This is a rather standard method of template-part handling that has become a part of the normal theme-building experience.</p>



<p>It will be interesting to see how this works in the long run.  WordPress&rsquo; current template part system for theme authors (i.e., <code>get_template_part()</code>) is a bare-bones implementation with little flexibility for handling features like hierarchy and passing data.  Thus far, the new feature seems to be a melding of blocks and old templating ideas, but it is too early in the process to see where it goes or whether theme authors will have to make customizations to bend the system to their will.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Dec 2019 19:22:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WordPress.org blog: The Month in WordPress: November 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=8156\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2019/12/the-month-in-wordpress-november-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8071:\"<p>November has been a big month in the WordPress community. New releases, big events, and a push for more contributors have characterized the work being done across the project — read on to find out more!</p>



<hr class=\"wp-block-separator\" />



<h2>The release of WordPress 5.3 “Kirk”</h2>



<p><a href=\"https://wordpress.org/news/2019/11/kirk/\">WordPress 5.3 was released</a> on November 12, and is <a href=\"https://wordpress.org/download/\">available for download</a> or update in your dashboard! Named “Kirk,” after jazz multi-instrumentalist Rahsaan Roland Kirk, 5.3 enhances the block editor with <a href=\"https://make.wordpress.org/core/2019/09/24/new-block-apis-in-wordpress-5-3/\">new APIs</a> and <a href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">theme-related features</a>, adds more intuitive interactions, and improves accessibility in a number of areas — including <a href=\"https://make.wordpress.org/core/2019/10/18/noteworthy-admin-css-changes-in-wordpress-5-3/\">CSS in the dashboard</a>, the <a href=\"https://make.wordpress.org/core/2019/10/14/improvements-in-media-component-accessibility-in-wordpress-5-3/\">media manager</a>, <a href=\"https://make.wordpress.org/core/2019/09/23/core-widgets-new-aria-current-attribute-in-wordpress-5-3/\">core widgets</a>, and <a href=\"https://core.trac.wordpress.org/query?focuses=~accessibility&milestone=5.3&group=component&max=500&col=id&col=summary&col=milestone&col=owner&col=type&col=status&col=priority&order=id\">dozens of other areas</a>.</p>



<p>You can read the full details of all the included enhancements in the <a href=\"https://make.wordpress.org/core/2019/10/17/wordpress-5-3-field-guide/\">5.3 Field Guide</a>.</p>



<p>Along with 5.3 came <a href=\"https://wordpress.org/themes/twentytwenty/\">the new Twenty Twenty theme</a>, which gives users more design flexibility and integrates with the block editor. For more information about the improvements to the block editor, expanded design flexibility, the Twenty Twenty theme, and to see the huge list of amazing contributors who made this release possible, read <a href=\"https://wordpress.org/news/2019/11/kirk/\">the full announcement</a>.</p>



<p>Want to get involved in building WordPress Core? Follow <a href=\"https://make.wordpress.org/core/\">the Core team blog</a> and join the #core channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>. You can also <a href=\"https://make.wordpress.org/core/2019/11/15/5-3-retrospective-call-for-feedback/\">provide feedback</a> on the 5.3 release process.</p>



<h2>At Last! bbPress 2.6!</h2>



<p><a href=\"https://bbpress.org/blog/2019/11/bbpress-2-6/\">bbPress 2.6 was released</a> on November 12 after a little over six years in development. This new release includes per-forum moderation, new platforms to import from, and an extensible engagements API. You can read more about all of this in <a href=\"https://codex.bbpress.org/\">the bbPress codex</a>.</p>



<p><a href=\"https://bbpress.org/blog/2019/11/bbpress-2-6-1-is-out/\">Version 2.6.1</a> and <a href=\"https://bbpress.org/blog/2019/11/bbpress-2-6-2-is-out/\">2.6.2</a> quickly followed, both of which fixed a number of bugs that required immediate attention.</p>



<p>Want to get involved in building bbPress? Follow <a href=\"https://bbpress.org/blog/\">the bbPress blog</a> and join the #bbpress channel in <a href=\"https://make.wordpress.org/chat/\">the Making WordPress Slack group</a>.</p>



<h2>State of the Word</h2>



<p><a href=\"https://2019.us.wordcamp.org/\">WordCamp US 2019</a> was held in St. Louis, MO this year on November 1-3. At the event, <a href=\"https://profiles.wordpress.org/matt/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>matt</a> gave his annual State of the Word address, during which he shared what had been accomplished in the past year, announced what is coming next, and shared several ways to get involved.</p>



<p>You can watch <a href=\"https://www.youtube.com/watch?v=LezbkeV059Q&t=21s\">the State of the Word</a> as well as <a href=\"https://www.youtube.com/watch?v=fFsVbAo8HwI\">the Q&amp;A session at the end</a>, and <a href=\"https://ma.tt/2019/11/state-of-the-word-2019/\">read Matt’s recap</a> of the address. If you didn’t make it to St. Louis, you can still <a href=\"https://www.youtube.com/playlist?list=PL1pJFUVKQ7ETHl165LvLVXfB3yBZEzV-q\">watch all the sessions</a> at your leisure.</p>



<h2>Five for the Future</h2>



<p>During the State of the Word, Matt announced that there is now <a href=\"https://wordpress.org/five-for-the-future/\">a dedicated landing page for Five for the Future</a>, which features the people and organizations that commit at least it 5% of their resources to the WordPress open source project. There are many ways to contribute to WordPress, such as core development, marketing, translation, training, and community organizing, among many other important paths to contribution.</p>



<p>Five for the Future welcomes individuals and organizations, and highlights all the incredible ways we build WordPress together. For more information, visit <a href=\"https://wordpress.org/five-for-the-future/\">the Five for the Future page</a>.<br /></p>



<hr class=\"wp-block-separator\" />



<h2>Further Reading:</h2>



<ul><li>After releasing WordPress 5.3, the Core team announced <a href=\"https://make.wordpress.org/core/2019/11/21/tentative-release-calendar-2020-2021/\">a tentative release schedule</a> for 2020 and 2021.</li><li>The Core team has announced <a href=\"https://make.wordpress.org/core/2019/11/28/new-css-focus-in-core/\">a new CSS focus</a> to complement the existing ones for PHP and JavaScript — this focus comes with dedicated tags, targeted work, and a new #core-css Slack channel.</li><li>Version 2.2 of the WordPress Coding Standards <a href=\"https://github.com/WordPress/WordPress-Coding-Standards/releases/tag/2.2.0\">has been released</a> — this new release is ready for WordPress 5.3, includes five brand new sniffs, and plenty of new command-line documentation.</li><li>The latest update to the Theme Review Coding Standards, <a href=\"https://github.com/WPTRT/WPThemeReview/releases/tag/0.2.1\">v0.2.1</a>, is compatible with v2.2 of the WordPress Coding Standards, and helps authors to build more standards-compatible themes.</li><li><a href=\"https://2019.us.wordcamp.org/2019/11/11/wordcamp-us-2020/\">The WordCamp US team has announced</a> the dates for next year’s event in St. Louis, MO — WordCamp US 2020 will be held on October 27-29. This will be the first time that the event will be held during the week and not on a weekend. The team has also announced a Call for Organizers. If you are interested in joining the team, <a href=\"https://2020.us.wordcamp.org/2019/11/21/join-the-wcus-2020-organizing-team/\">learn more</a>.&nbsp;</li><li>The WP Notify project, which is building a unified notification system for WordPress Core, <a href=\"https://make.wordpress.org/core/2019/11/29/wp-notify-hiatus-till-january-2020/\">is on hiatus</a> until January 2020.</li><li>A working group on the Community Team <a href=\"https://make.wordpress.org/community/2019/11/25/handbook-update-how-to-improve-the-diversity-of-your-wordpress-events/\">has updated their Handbook</a> to help organizers create more diverse events.</li><li>The WP-CLI team <a href=\"https://make.wordpress.org/cli/2019/11/12/wp-cli-v2-4-0-release-notes/\">released v2.4.0</a> of the WordPress command-line tool. This release includes support for WordPress 5.3 and PHP 7.4.</li><li>Gutenberg development continues rapidly with <a href=\"https://make.wordpress.org/core/2019/11/27/whats-new-in-gutenberg-27-november/\">the latest 7.0 release</a> including an early version of the navigation menus block, among other enhancements and fixes.</li></ul>



<p><em>Have a story that we should include in the next “Month in WordPress” post? Please </em><a href=\"https://make.wordpress.org/community/month-in-wordpress-submissions/\"><em>submit it here</em></a><em>.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 02 Dec 2019 08:38:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Hugh Lashbrooke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Powering Your House\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50550\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://ma.tt/2019/11/powering-your-house/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:263:\"<div class=\"wp-block-embed__wrapper\">

</div>



<p>I enjoyed this fun video from xkcd&#8217;s Randall Munroe on different ways you could power your home, illustrated. <a href=\"https://xkcd.com/how-to/\">Check out his book How To for more in the same vein</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 30 Nov 2019 22:33:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: WP&amp;UP to Hold #DoSummitGood Online Event for Giving Tuesday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95585\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"https://wptavern.com/wpup-to-hold-dosummitgood-online-event-for-giving-tuesday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4922:\"<img />



<p>On Giving Tuesday, December 3, WP&amp;UP is holding an online event called <a href=\"https://wpandup.org/go/dosummitgood\">#DoSummitGood</a> that features speakers from various &ldquo;for good&rdquo; WordPress organizations.  The event will have nine sessions from 13 speakers.  It begins at <a href=\"http://www.timebie.com/std/utc.php?q=13\">13:00 UTC</a>.</p>



<p>Giving Tuesday is a global movement meant to inspire generosity.  The celebration has run each year since 2012 on the Tuesday following the U.S. Thanksgiving holiday.  The idea is to inspire people to do good, not for just one day of the year, but each day of their lives.</p>



<p>A WordPress-focused event on Giving Tuesday sounds like a perfect match.  Given the nature of open source and the charitable work of many of the people and companies in the space, it makes sense to hold a specific event for the holiday.   &ldquo;This is the first #DoSummitGood and there has already been a discussion about making this an annual event for Giving Tuesday,&rdquo; said Dan Maby, CEO and a Trustee of WP&amp;UP.</p>



<p>WP&amp;UP is a registered charity organization with a mission to support and promote positive mental health within the WordPress community.  Its <a href=\"https://wpandup.org/health-hubs/\">Health Hubs</a> cover topics like business, skills, physical, and mental health.  The organization also provides support and counseling services.</p>



<p>The idea for the #DoSummitGood event was born from a WP&amp;UP <a href=\"https://wpandup.org/2019/10/join-our-open-discussion-town-hall-ama-on-wednesday-9th-october/\">Town Hall</a> in October.  &ldquo;Our focus is on collaboration and our Town Halls are an opportunity for members of the public to get involved and help brainstorm ideas for the community, as well as get to know more about what WP&amp;UP does,&rdquo; said Maby.</p>



<p>The primary event will run via <a href=\"https://www.crowdcast.io/e/dosummitgood/register\">Crowdcast</a>.  By registering for the event, attendees will gain access to the Hallway Track to meet with other attendees online.  They will also have the ability to ask questions directly to the speakers.  Registration is free but will close once it reaches a specific number of signups.  &ldquo;WP&amp;UP is paying for the technical solution to deliver the event,&rdquo; said Maby.  &ldquo;As a registered charity we have to be responsible for expenditure, and so limiting the number of seats for this first event is one way we can do that.&rdquo;</p>



<p>For those who do not register and attend via Crowdcast, they can still watch and participate in the event through various social platforms:</p>



<ul><li><a href=\"https://twitter.com/WPandUP\">Twitter</a></li><li><a href=\"https://www.facebook.com/WPandUP/\">Facebook</a></li><li><a href=\"https://www.youtube.com/wpandup\">YouTube</a></li><li><a href=\"https://www.twitch.tv/wpandup\">Twitch</a></li></ul>



<p>Each of the sessions will feature various international speakers who will give a talk on their area of expertise.  The sessions will follow a specific format and run for one hour.  For the first 10 minutes of each session, the individual speaker or group will talk about the &ldquo;for good&rdquo; entity they represent.  They will follow up with a 35-minute talk on their subject.  Afterward, the speaker and attendees will participate in an open Q&amp;A session.</p>



<p>The #DoSummitGood event is designed to give back.  &ldquo;Throughout the event, a donation form will be shared,&rdquo; said Maby.  &ldquo;All money raised through this form will be distributed between the various non-profits that feature in the event.&rdquo;</p>



<p>Cory Miller, a Trustee at WP&amp;UP, will kick off the event with a session titled &ldquo;The Iceberg of Life: How I Manage the Ups and Downs.&rdquo;  Miller has been open about mental health within the WordPress community and his struggles for several years.  He has previously written on the topic of <a href=\"https://corymiller.com/the-iceberg-of-life/\">The Iceberg of Life</a>, which is worth reading if you are looking to get an early look into what his session may be about.</p>



<p>Marieke van de Rakt will follow up with a talk about improving a site&rsquo;s SEO.  She is representing Yoast and its <a href=\"https://wptavern.com/yoast-launches-fund-to-increase-speaker-diversity-at-tech-conferences\">diversity fund program</a>, which helps to remove the financial burdens that cause minorities or underrepresented groups to speak at conferences.</p>



<p>The nine sessions have a diverse group of speakers from various organizations that are currently providing support for charities, minorities, and other groups that need help.  The topics include turning passion into a profession,  bringing more diversity to speaking roles at conferences, and more.  Two of the sessions will be round-table events with multiple speakers.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Nov 2019 19:26:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Matt: Distributed Podcast: Clark Valberg, Lydia X. Z. Brown, Stephen Wolfram, and the Grand Meetup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50496\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://ma.tt/2019/11/distributed-podcast-updates/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9149:\"<p>If y&#8217;all haven&#8217;t caught up recently with my podcast <a href=\"https://distributed.blog/\">Distributed</a>, this is a perfect moment to do so—the past several weeks have been full of insights from folks like InVision CEO Clark Valberg, attorney and advocate Lydia X. Z. Brown, Stephen Wolfram, and some of my own Automattic colleagues in-person at our Grand Meetup. </p>



<p>You can subscribe at <a href=\"https://podcasts.apple.com/us/podcast/distributed-with-matt-mullenweg/id1463243282\">Apple Podcasts</a>, <a href=\"https://podcasts.google.com/?feed=aHR0cHM6Ly9kaXN0cmlidXRlZC5ibG9nL2NhdGVnb3J5L3BvZGNhc3QvZmVlZC8%3D\">Google</a>, <a href=\"https://overcast.fm/itunes1463243282/distributed-with-matt-mullenweg\">Overcast</a>, <a href=\"https://open.spotify.com/show/59bljZU7v9cJTXKvlfnFN8?si=Iv4hgJMFRCCx4SpmXlLArg\">Spotify</a>, or wherever you like to listen.&nbsp;</p>



<span id=\"more-50496\"></span>



<h2><a href=\"https://distributed.blog/2019/11/26/the-importance-of-irl-in-a-world-of-screens/\">The Importance of IRL in a World of Screens (Automattic Grand Meetup)</a></h2>



<p>&#8220;When you work in a distributed company, every time that you interact with your colleagues via text… you are taking out of your social bank account with them. So when you get people together, that’s when you have the opportunity to see each other face-to-face, and remind everybody that you’re all human beings. And fill that social capital back up because it’s so hard to communicate via text.&#8221;</p>



<h2><a href=\"https://distributed.blog/2019/11/14/clark-valberg-invision/\">Building the Tools That Bring the Screen to Life (Clark Valberg, InVision)&nbsp;</a></h2>



<p>&#8220;We needed it as a talent hack, as a talent arbitrage. Hire the best people wherever they happen to be, figure everything out later, hire them quickly, get them in the ship as early as possible and start seeing results. How can I just hire the best people no matter where they are?&#8221;</p>



<h2><a href=\"https://distributed.blog/2019/10/31/making-work-accessible-wherever-it-happens/\">Making Work Accessible, Wherever It Happens (Lydia X. Z. Brown)</a></h2>



<p>&#8220;I have believed from a very young age that every single one of us has a moral obligation to use whatever resources we have — time, money, knowledge, skills, emotional energy, access to physical resources — however that might be defined — that we each have a moral obligation to use those resources in service of justice, and fighting against injustice and oppression and violence in all of its forms, structural and individual, subtle and overt.&#8221;</p>



<h2><a href=\"https://distributed.blog/2019/10/17/inside-toptals-distributed-screening-process/\">Inside Toptal&#8217;s Distributed Screening Process (Taso Du Val)&nbsp;</a></h2>



<p>&#8220;I was going into an office but not seeing anyone or interacting with anyone except myself. So it almost was this zombie-like walk to the office every morning where I’m going to the office because I go to work, but I don’t see anyone who I work with. [laughs] And so I actually started waking up and just working on my computer at home. And then I said to myself, &#8216;Well, why am I even working from home?\'&#8221;</p>



<h2><a href=\"https://distributed.blog/2019/10/03/turning-ideas-into-real-things/\">The Machine That Turns Ideas Into Real Things (Stephen Wolfram)&nbsp;</a></h2>



<p>“You can do things that are very commercial, but a little bit intellectually boring. And it tends to be the case that you’re doing a lot of rinse-and-repeat stuff if you want to grow purely commercially, so to speak. Or, you can do things that are wonderful intellectually, but the world doesn’t happen to value them and you can’t make commercial sense that way. And I’ve tried to navigate something in between those two where it’s where I’m really intellectually interested and where it’s commercially successful enough to sustain the process for a long time.”</p>



<h2><a href=\"https://distributed.blog/2019/09/19/welcome-to-the-chaos/\">Welcome to the Chaos (Sonal Gupta, Automattic)</a></h2>



<p>“I like to trust people and give them autonomy. But I keep in touch with them very regularly and I think it becomes clear pretty quickly if somebody is not doing work. We look at performance, and we look at communication at a distributed company. Communication is oxygen.”&nbsp;</p>



<h2><a href=\"https://distributed.blog/2019/09/05/managing-distributed-teams/\">Observe, Don’t Surveil: Managing Distributed Teams with Respect (Scott Berkun)</a></h2>



<p>“To work at a remote company demanded great communication skills, and everyone had them. It was one of the great initial delights. Every corporation has the same platitudes for the importance of clear communication, yet utterly fails to practice it. There was little jargon at Automattic. No ‘deprioritized action items’ or ‘catalyzing of crossfunctional objectives.’ People wrote plainly, without pretense and with great charm.”&nbsp;</p>



<h2><a href=\"https://distributed.blog/2019/08/22/build-distributed-engineering-teams/\">How to Build and Strengthen Distributed Engineering Teams (Cate Huston, Automattic)</a></h2>



<p>“A senior engineer makes the whole team better, but we don’t want to be prescriptive about how people made the team better. That was up to them. There were options, but that was the expectation for everyone on the team. You come in, you’re an experienced engineer, we expect you to be making the whole team better in some way, and what that looks like is up to you.”&nbsp;</p>



<h2><a href=\"https://distributed.blog/2019/08/08/stay-connected-in-a-distributed-world/\">How to Stay Connected in a Distributed World (Leo Widrich)</a>&nbsp;</h2>



<p>“I started to feel like I was hitting a wall. This thing that I always dreamt of, to have a profitable company, to be financially secure, to have a team… I felt that having that success, having some of that financial security — it left me unfulfilled in a lot of other areas. — in the sense of deep lasting connection and also a lack of emotional resilience to deal with the ups and downs that startup life comes with.”</p>



<h2><a href=\"https://distributed.blog/2019/07/25/helping-creativity-happen-from-a-distance/\">Helping Creativity Happen from a Distance (John Maeda)&nbsp;</a></h2>



<p>“My point is blogging is good for you. It’s mental health, it’s expression, it’s sharing your process with the world. And when you relate to the world, your standard of quality floats to that value of the world. It’s a market economy of ideas and by putting ourselves out there, you become relevant.”</p>



<h2><a href=\"https://distributed.blog/2019/07/11/engineering-with-empathy/\">Engineering with Empathy (Han Yuan, Upwork)&nbsp;</a></h2>



<p>“We really want to encourage empathy in general. And so a key part of empathy is being able to try to see the other person’s point of view. And in an organization as distributed as ours where people come from all around the world, we view it as an essential ingredient to developing deep and meaningful collaboration.”</p>



<h2><a href=\"https://distributed.blog/2019/07/11/how-to-do-hr-in-a-blended-company/\">How to Do HR in a Blended Company (Zoe Harte, Upwork)&nbsp;</a></h2>



<p>“That means saying, ‘Okay, our entire organization will connect this many times a year in this many ways. There will be an all-department meeting once a month, once a quarter — whatever is appropriate — and that we will cover these three priorities and in broad progress and how it’s impacting the business overall.’ And then the expectation would be that the smaller subsets of teams are meeting in this way.”</p>



<h2><a href=\"https://distributed.blog/2019/07/02/on-building-automattic/\">On Building Automattic (Me)</a></h2>



<p>“Our distributed roots did not come from some grand vision, but instead emerged from cold realities. Colocation (being in the same place, at the same time) is expensive!”</p>



<h2><a href=\"https://distributed.blog/2019/06/13/is-remote-work-bs/\">Is Remote Work Bulls&#8212;t? (Arianna Simpson)</a></h2>



<p>“I think having people come and interrupt you every 25 seconds, as is often the case in open floor plans, is definitely not the most productive situation. So the model I’ve seen work well, or the model I lean towards, is having an office where people are working from, but having private offices or spaces where people can plug in their headphones and just do work alone while still being in the same place as, hopefully, all of their colleagues.”</p>



<h2><a href=\"https://distributed.blog/2019/05/30/could-vr-replace-the-office/\">For Years, VR Promised to Replace the Office. Could It Really Happen Now? (John Vechey, Pluto VR)</a></h2>



<p>“The technology forces you to be present — in a way flatscreens do not — so that you gain authentic experiences, as authentic as in real life. People remember VR experiences not as a memory of something they saw but as something that happened to them.”</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Nov 2019 03:53:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"WPTavern: WordPress Black Friday Sales Roundup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95552\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wptavern.com/wordpress-black-friday-sales-roundup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11633:\"<div class=\"wp-block-cover alignfull has-background-dim-80 has-gray-900-background-color has-background-dim has-parallax bg-gray-900\"><div class=\"wp-block-cover__inner-container\">
<h1 class=\"text-white\">WordPress Black Friday Sales Roundup</h1>



<p class=\"has-medium-font-size font-secondary text-base\"><a href=\"https://wptavern.com/author/justintadlock\">Justin Tadlock</a>&nbsp;<span class=\"sep mx-2\">&middot;</span>&nbsp;November 26, 2019&nbsp;<span class=\"sep mx-2\">&middot;</span>&nbsp;<a href=\"https://wptavern.com/category/news\">News</a></p>
</div></div>



<p>&lsquo;Tis the largest shopping season of the year.  While you are gearing up for a big weekend of finding that perfect gift for your family and friends, you might take a moment to consider giving your website a little something for the holiday.</p>



<p>The following is our roundup of WordPress hosting, services, and plugins that are on sale this week and next.</p>



<h2>Hosting and Domain Deals</h2>



<p>If you are in the market for a new host or have been sitting on a new domain name to purchase, now might be the time to start looking around to see if you can snag a good price.</p>



<h3>BlueHost</h3>



<p>BlueHost is running a weeklong event, which began on November 25.  The web host is offering 60% off WordPress, 50% off VPS, and 40% off WordPress Pro hosting. The offer includes a free domain for the first year.</p>



<p><a href=\"https://www.bluehost.com/\">Visit BlueHost&rsquo;s site &rarr;</a></p>



<h3>DreamHost</h3>



<p>DreamHost is cutting their prices on new domain registrations from November 25 through December 3, which ranges from a low $0.79 for <code>.xyz</code> to $6.99 for <code>.com</code> registrations. Beginning on Friday, November 29, they are offering deals on their Shared Unlimited hosting for 1-year ($5.95/month) and 3-year ($4.95/month) paid plans.</p>



<p><a href=\"http://dreamhost.com/\">Visit DreamHost&rsquo;s site &rarr;</a></p>



<h2>WordPress Services</h2>



<p>A couple of WordPress companies are offering markdowns on their services rather than products this shopping season.</p>



<h3>WPScan</h3>



<p>WPScan, an online WordPress vulnerability scanner, is giving a 20% discount for the first three months on any of their paid plans.  Use the coupon code <code>BLACKFRIDAY20</code> at checkout.</p>



<p><a href=\"http://wpscan.io\">Visit WPScan&rsquo;s site &rarr;</a></p>



<h3>WPDandy</h3>



<p>WPDandy offers WordPress maintenance, management, and support, which includes backup and security services.  The team is currently running 50% off each plan available.  The Black Friday deal is currently open, but there is no mention of when it ends.</p>



<p><a href=\"https://wpdandy.com/black-friday-2019\">See WPDandy&rsquo;s sale &rarr;</a></p>



<h2>Plugins</h2>



<p>If you have had your eye on a particular plugin but have yet to pull the trigger, now may be a good chance to grab it.  The following is a roundup of several plugins and plugin bundles.  Some are currently on sale.  Others will begin on Black Friday.  Most sales will last several days.</p>



<h3>Saturday Drive</h3>



<p>Saturday Drive, the company behind <a href=\"https://ninjaforms.com/\">Ninja Forms</a> and <a href=\"https://calderaforms.com/\">Caldera Forms</a>, has the most interesting Black Friday deal.  Users have a chance of getting between 40% and 100% off either plugin by using the spinner at checkout.  The company is also donating 10% of all sales to Operation Smile.  The promotion runs between November 29 and December 3.</p>



<p>Read more about Saturday Drive&rsquo;s <a href=\"https://saturdaydrive.com/save-it-forward/\">Save it Forward event &rarr;</a></p>



<h3>iThemes</h3>



<p>iThemes has a large selection of products, including its popular BackupBuddy and iThemes Security Pro plugins.  The site is cutting prices 50% off any new plugin, combo pack, hosting, theme, Stash, or annual Sync plan from November 23 &ndash; December 2.</p>



<p><a href=\"https://ithemes.com/coupon/black-friday-cyber-monday-sale/\">See iTheme&rsquo;s sale &rarr;</a></p>



<h3>GiveWP</h3>



<p>GiveWP is a donations plugin that allows visitors to contribute to your cause directly from your website. They are running a 50%-off special for the next week.  However, the sale is limited to the first 500 customers.  This would be a good time to snag the plugin if you plan on collecting donations for Giving Tuesday next week.</p>



<p><a href=\"https://givewp.com/lps/black-friday/\">See GiveWP&rsquo;s sale &rarr;</a></p>



<h3>Pootlepress</h3>



<p>Pootlepress, a WordPress plugin and theme shop, is slashing 40% off their WooBuilder Blocks and Storefront Blocks plugins, which integrate WooCommerce and Gutenberg.  The sale begins on November 29 and ends on December 4.</p>



<p><a href=\"https://www.pootlepress.com/\">Visit Pootlepress&rsquo; site &rarr;</a></p>



<h3>Starfish Reviews</h3>



<p>Starfish Reviews, a plugin designed to help businesses get more reviews on Google, Facebook, and other platforms, is currently on sale for 83% off. The lifetime deal ends on November 30.</p>



<p><a href=\"https://starfish.reviews/2019-bfcm-ltd/\">See Starfish Review&rsquo;s sale &rarr;</a></p>



<h3>ProjectHuddle</h3>



<p>ProjectHuddle is a WordPress feedback plugin for use by agencies and freelancers to communicate with their clients. It allows clients to provide comments on mockups and more.  Each pricing plan has been cut by 40%.  The sale began on November 25 and runs through December 2.</p>



<p><a href=\"https://projecthuddle.com/friday\">See ProjectHuddle&rsquo;s sale &rarr;</a></p>



<h3>Paid Memberships Pro</h3>



<p>Paid Memberships Pro is a WordPress community and memberships plugin that works with several payment gateways and integrates with community plugins such as bbPress and BuddyPress.  The website is cutting $100 from its Plus plan and $200 from its Unlimited plan, both of which locks in a lifetime renewal rate.  The offer runs from November 29 through December 2.  Use the <code>blackfriday</code> discount code at checkout.</p>



<p><a href=\"https://www.paidmembershipspro.com/press/resources/\">See Paid Memberships Pro&rsquo;s sale &rarr;</a></p>



<h3>Dev4Press</h3>



<p>Dev4Press is a plugin shop that has a range of plugins, including bbPress tools, security, ratings, and more.  Customers can grab 25% off using the <code>BLACKCYBER</code> coupon code at checkout.  The discount can be applied to all plugins, add-ons, and club memberships.  The sale runs from November 27 through December 3.  </p>



<p><a href=\"https://www.dev4press.com/promotion/2019/black-friday-cyber-monday-2019/\">See Dev4Press&rsquo; sale &rarr;</a></p>



<h3>SiteOrigin</h3>



<p>SiteOrigin is slashing 50% off their premium product bundle on Black Friday, November 29, which includes over 20 add-ons for their theme and plugin products.  Use the <code>NOVEMBER30</code> coupon code at checkout for the discount.  On Giving Tuesday, November 3, the team will provide email support to all users, which is typically only available on paid plans.</p>



<p><a href=\"https://siteorigin.com/downloads/premium/\">Visit SiteOrigin&rsquo;s Premium page &rarr;</a></p>



<h3>Stackable</h3>



<p>Stackable, a premium blocks collection plugin, kicked off its version 2 launch on November 25.  The site is currently holding a flash sale that ends on November 27.  Use the discount code <code>LTD30</code> to grab 30% off.  After the flash sale, they will continue with a 20% discount for all annual plans when using the <code>LAUNCH20</code> discount code. This deal ends on December 9.  The website is also offering limited-time lifetime purchases during the event.</p>



<p><a href=\"https://wpstackable.com/\">Visit Stackable&rsquo;s website &rarr;</a></p>



<h3>Hookturn</h3>



<p>Hookturn, a company that specializes in add-on plugins for Advanced Custom Fields, is currently offering 40% off their ACF Theme Code Pro, ACF Custom Database Tables, and Advanced Forms Pro plugins.  The sale runs until December 3.</p>



<p><a href=\"https://hookturn.io\">Visit Hookturn&rsquo;s website &rarr;</a></p>



<h3>SearchWP</h3>



<p>SearchWP is an advanced search form plugin that offers a more robust search of content for WordPress.  The company&rsquo;s sale this year begins on Friday, November 29, and lasts until Tuesday, December 3.  The site is offering a 30%-50% discount on new plugin licenses and 40% off upgrades for existing customers at checkout.</p>



<p><a href=\"https://searchwp.com/\">Visit SearchWP&rsquo;s website &rarr;</a></p>



<h3>OrganizeWP</h3>



<p>OrganizeWP, a drag-and-drop plugin that allows users to manage their WordPress admin, will be on sale for 50% off support and update licenses.  The runs November 29 through December 3.  Discounts are automatically applied at checkout.</p>



<p><a href=\"https://organizewp.com/\">Visit OrganizeWP&rsquo;s website &rarr;</a></p>



<h3>Gravity PDF</h3>



<p>Gravity PDF, a plugin for automatically creating PDF documents for Gravity Forms, is currently holding a sale for 40% off their access passes.  The sale will end on Monday, December 2.</p>



<p><a href=\"https://gravitypdf.com/l/2019-black-friday-and-cyber-monday-sale/\">See Gravity PDF&rsquo;s sale &rarr;</a></p>



<h3>Meta Box</h3>



<p>Meta Box, a custom fields plugin for developers, is offering 60% off their lifetime bundle, which brings the price from $499 down to $199.  The sales event lasts from November 26 through December 6.</p>



<p><a href=\"https://metabox.io/black-friday/\">See Meta Box&rsquo;s sale &rarr;</a></p>



<h3>WisdmLabs</h3>



<p>WisdmLabs, a shop with various WooCommerce and LearnDash add-ons, will begin offering 30% discount on all products and bundles available through their site on November 28 and last through December 2.  Use the <code>BFCM30</code> coupon code at checkout.</p>



<p><a href=\"https://wisdmlabs.com/premium-wordpress-plugins/\">See WisdmLabs&rsquo; sale &rarr;</a></p>



<h3>MailOptin</h3>



<p>MailOptin is an email opt-in form plugin that allows website visitors to sign up for an email subscription.  The site is offering a 25% discount for customers who use the <code>BCFM2019</code> coupon code from November 29 through December 3.</p>



<p><a href=\"https://mailoptin.io\">Visit MailOptin&rsquo;s website &rarr;</a></p>



<h3>Social Rocket</h3>



<p>Social Rocket, a social sharing plugin for WordPress that works with all the major social networks, is currently on sale for 33% off using the <code>BFCM2019</code> coupon code.  The discount is available through December 2.</p>



<p><a href=\"https://wpsocialrocket.com/\">Visit Social Rocket&rsquo;s website &rarr;</a></p>



<h3>Charitable</h3>



<p>Charitable is a fundraising plugin for WordPress that allows visitors to donate directly on users&rsquo; sites.  The website is offering 30% off its pro and agency payment options from November 29 through December 3.  Use the <code>PRO30BF19</code> code at checkout for the discount.</p>



<p><a href=\"https://www.wpcharitable.com/\">Visit Charitable&rsquo;s website &rarr;</a></p>



<h3>Sandhills Development</h3>



<p>Sandhills Development is offering 25% off with the <code>BFCM2019</code> coupon code on all its products, which includes Easy Digital Downloads, AffiliateWP, Restrict Content Pro, Sugar Calendar, and WP Simple Pay.  The sale runs from November 29 through December 6.  They are also offering lifetime bundle deals and over $3,000 in prizes.</p>



<p><a href=\"https://sandhillsdev.com/2019/11/sandhills-sale-event-2019/\">See Sandhills Development&rsquo;s sale &rarr;</a></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 26 Nov 2019 21:29:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: WP Tavern’s New Design: No More Wood Grain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95513\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wptavern.com/wp-taverns-new-design-no-more-wood-grain\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4871:\"<img />Screenshot of the new homepage design.



<p>If you are viewing WP Tavern from your browser today, you might be a bit shocked.  Things are different &mdash; much different.  If you are reading this post via email or a feed reader, hop on over to the live site to take a look.</p>



<p>Welcome to the new design!</p>



<p>When I accepted the job to write for WP Tavern, some of you asked if I would be handling anything with the design and development aspects of the site.  Today, you have your answer.  I was tasked with overhauling our dated design and getting something fresh up.</p>



<p>From the moment I logged in and started peeking behind the curtain, the task seemed almost insurmountable.  WP Tavern has had nearly 5,000 posts over 12 years.  It has content mixed and matched with plugins that have not been used in years.  Being perfectly honest, I was unsure what some plugins did for a long while.  However, I have gotten to know the site and its inner-workings over the past couple of months, and the new design has taken shape around some of that.</p>



<p>Rather than taking the time to do a complete overhaul of everything, which is sorely needed, our team decided the best course of action was to get a new theme up and iterate.</p>



<p>The first step of the design process was to remove the wood-grain background.  There is likely some nostalgia attached to that for some of our readers (some of you may have grown accustomed to it over the last 12 years), but it is the one thing we universally agreed to drop.</p>



<p>The second step was to move to a sidebar-less design.  Our team at the Tavern decided that nearly everything in the previous design&rsquo;s sidebar offered few benefits to our readers.  It was a distraction that took away from the content.</p>



<p>The next step of the design process was to add complete compatibility with the block editor (Gutenberg).  With no sidebar, this will open the door for us to do more interesting things with media and other elements over the long term.</p>



<p>Overall, the goal was to make the reading process nicer for all of you who visit the site.  I hope that we have accomplished that.</p>



<h2>The Future Design of the Site</h2>



<p>This is version 1.0 of the new design.  A large part of the process was laying the groundwork in a way that it would be easy to make changes going forward.</p>



<p>There are still some missing elements that will be re-added soon.  Primarily, the site needs a search form in the header/navigation area.  Redesigning the email subscription form and moving it to a different location is high on the list.</p>



<p>The site should load faster than before. However, there is still a lot of cleanup to do with plugins over the long haul. Page loads should be even snappier as we continue to iterate.</p>



<p>I also hope we can add a custom logo and other Tavern-<em>esque</em> elements that bring more personality to the site as we move along in this ongoing process.</p>



<p>However, this is the point where you, the WP Tavern audience, get to join the conversation.  Before pushing too far with additional changes, it is important to get your feedback about what you want to see in the coming days, weeks, and months.  Ultimately, the goal is to serve you WordPress news and information in the best way possible.</p>



<p>Feedback is certainly welcome.  If there is a missing element you want to see return, post it in the comments.  If there is something you would like to see added, don&rsquo;t be shy about letting us know.</p>



<p>The <a href=\"https://wptavern.com/contact-me\">contact form</a> is also always open for private feedback or for letting us know about a problem with the site.</p>



<h2>What Is Under the Hood?</h2>



<p>To get the theme up and running, I reused a ton of code from my previous theme-related work before joining WP Tavern. It made sense to use a build system I already knew from top to bottom and not reinvent the wheel.</p>



<p>The CSS system is a customized and stripped-down version of <a href=\"https://tailwindcss.com/\">Tailwind CSS</a>.  Tailwind is a utility-first CSS framework.  For most of my professional career, I have shied away from utility-based frameworks.  However, Tailwind is a well-designed framework with a smart naming scheme that strikes a balance between readability and practicality.  It is one of the few that has clicked with me.  WordPress also uses several utility classes, especially with the block editor.  The two systems made sense together.</p>



<p>WordPress front-end output and some plugins (I&rsquo;m looking at you, Jetpack) do not make it easy to take a full utility-class approach.  Everything else was addressed on a case-by-case basis.</p>



<p>If any WordPress developers want to know more about the technical aspects, I am happy to answer questions.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 25 Nov 2019 20:32:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"bbPress: bbPress 2.6.2 is out!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://bbpress.org/?p=206111\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://bbpress.org/blog/2019/11/bbpress-2-6-2-is-out/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1342:\"<p>bbPress 2.6.2 fixes <a href=\"https://bbpress.trac.wordpress.org/query?status=closed&group=resolution&milestone=2.6.2\">5 more small bugs</a> that were reported by community members in our support forums:</p>



<ul><li>Hierarchical replies in threaded discussion topics were broken for sites that were enabling the visual editor, so we unbroke it.</li><li>Sites with custom <code>bbpress.css</code> files were not having their custom styling applied in some cases. We fixed at least one case that we could find. Let us know if this is still not working correctly for you.</li><li>BuddyPress Notifications stopped working completely, but that wasn&#8217;t on purpose so we made them work completely again.</li><li>The &#8220;Edit&#8221; part of a URL pattern was not customizable inside of Forum Settings. Now it is!</li><li>One of the repair tools had a typo in it, so we untypo&#8217;ed it.</li></ul>



<p>Thanks to everyone in the forums for being persistent and helping us identify all these annoyances. </p>



<p>We&#8217;re going to continue minor releases as bugs get reported and fixed. The team is committed to making sure your forums are running as smoothly as can be, so don&#8217;t be surprised if you see 2.6.3 soon too! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f41d.png\" alt=\"🐝\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Nov 2019 18:24:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Optimizing Code in a World That Doesn’t Want to Optimize\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95433\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wptavern.com/optimizing-code-in-a-world-that-doesnt-want-to-optimize\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6757:\"<p><em>Premature optimization is the root of all evil.</em></p>



<p>It is a common saying among developers.  It makes sense.  Optimizing prematurely can mean redoing work down the line, and time is the developer&rsquo;s most finite resource.  It can mean spending that precious time optimizing for scenarios that do not yet exist for a product&rsquo;s users.  It can mean writing code that is harder to understand with unclear performance gains.</p>



<p>While participating with the WordPress theme review team about a year ago, I came across that nugget of advice once again.  <em>Premature optimization is the root of all evil.</em>  The reply was to a theme author who was looking to decrease the number and weight of scripts their theme needed to load.  On one hand, the theme author could load a 1.29 kb script with no dependencies to get the job done.  The other option was to use the jQuery-dependent script included in core WordPress for a total of 105 kb because &ldquo;most&rdquo; WordPress sites are loading jQuery anyway.</p>



<p>For me, the answer was simple.  Use the smaller script unless the core script was already loaded on the front end.  I did not think of it in terms of <em>premature optimization</em>.  I thought of it as plain old, run-of-the-mill, everyday optimization.</p>



<p>Developers should not confuse <em>premature optimization</em> with the concept of making smart design decisions early in the process.  Nor should they wait until the final stage of development to start optimizing, a time when the focus is on getting a product out to end-users.  That is a sign of a poor product design process.</p>



<p>Over the past year, that conversation stuck with me.  It helped me become more cognizant of a terrifying trend, not just in the WordPress developer community, but with web development in general.  Far too often, developers are so far removed from normal users and the technology those users rely on that optimization is little more than an afterthought.  Instead, it should always be at the forefront of any developer&rsquo;s mind.</p>



<p>The overreliance on this misused quote has helped push the trend of measuring page weight in megabytes instead of kilobytes.  It is too often used as a catchall justification for not doing any optimization in the development phase while making up for it with file compression and caching in production.</p>



<p>Part of writing quality code is optimizing that code during every stage of the development process.  It is about making hard decisions to cut unnecessary things as the software comes together.  Caching should be a last resort after everything else has been cleaned up.</p>



<p>Premature optimization is more about attempting to optimize when there are no clear gains or working on micro-optimizations that alter the software&rsquo;s design for little-to-no benefit.  It does not mean overlooking obvious performance boosts during development.</p>



<h2>Not Everyone is on Gigabit Internet</h2>



<p>Most developers I know are on super-fast internet connections, often with 1 Gbps download speeds and unlimited data.  In that situation, it is easy to forget that large chunks of the world are still on slow connections with data caps.</p>



<p>Some may even associate slow connections with third-world countries where millions of people are on 2G cell phone technology.  However, there are large swaths of the United States and other developed countries that have no direct cable or DSL lines, which are commonly available in cities and suburbs.</p>



<p>This disconnect is directly evident when other developers have initiated chats with me.  In the past couple of years, it has been increasingly common for them to ask for a video chat.  It is not even questioned whether such a thing is possible (video chats are unreliable at best for me).  The ability to video chat at any time is taken for granted.</p>



<p>There are two internet service options in the area that I live in:  satellite or dial-up.  Even the local telephone company refuses to offer DSL in this area because of infrastructural costs with decades-old phone lines.  Because of the prohibitive costs of satellite internet access, which typically comes with data limits, many are stuck with dial-up.  Cell phone companies are changing the game to a degree, assuming service is reliable, but there are downfalls with going that route, which can include data or hotspot limitations.</p>



<p>For such a technologically-advanced country, many of its people are barely catching up to where others were a decade ago.</p>



<p>While I am fortunate enough to choose where I live and have nothing holding me back from moving, most do not have that option.  They are stuck with the best they can afford.  Even in rural areas, the internet is an inescapable part of daily life, and developers are not making it easy for these people.</p>



<p>While this is anecdotal, it is the stark reality of rural life in pockets of the US.</p>



<p>The upside of living in the backwoods of Alabama is that it has changed my perspective as a developer.  It has meant that I needed to question every code decision for every plugin and theme I built.  With data caps, I needed to make sure that I was not using too many resources.  </p>



<p>More than anything, having a data cap changed how I used the internet.  I now run an ad-blocker.  I have an extension to kill videos from auto-loading.  I disable JavaScript on heavy sites that I need to use.  Some sites seem interesting, but I never return to them because they are resource hogs.</p>



<p>When you live in a place where every byte matters, you tend to avoid wasting them.</p>



<p>While not always successful, since my transition to small-town life, I have attempted to build applications in a way that served people who are not privileged enough to have blazing-fast internet access.</p>



<p>Pointing this out is about making sure developers are aware that optimization matters.  It matters at every stage of the development process.  It matters because these people with slow connections and data caps also need to buy products, use services, read content, and do all the other things that people do on the web.</p>



<p>If you are a developer who is thinking about adding that slider, swiping mechanism for mobile, or some other slick gadget, think about those of who must wait for that feature to load.  Check that its dependencies are not loading too many extra resources.  Do some research to see if you can locate a lighter-weight implementation.  But, first, ask yourself if it is necessary.</p>



<p>The themes and plugins that WordPress developers build should never be the bottleneck for a website.  We can do better.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Nov 2019 21:31:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:11:\"
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"HeroPress: Five Years Since The Dream Began\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://heropress.com/?p=3019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"https://heropress.com/five-years-since-the-dream-began/#utm_source=rss&utm_medium=rss&utm_campaign=five-years-since-the-dream-began\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3140:\"<p>Exactly five years ago today I woke up to an email from Dave Rosen telling me my life was about to change.  He didn&#8217;t know yet what we&#8217;d build, but he offered me the chance to build something.</p>



<p>From that seed we crafted HeroPress. It was a battle, filled with uncertainty, and at times tears, but I can say without hesitation that HeroPress has changed my life, and the life of my family, for the better.</p>



<p>Never, ever did I expect to become friends with so many people from so many places. HeroPress has changed the way I look at the world, and the people in it. It&#8217;s influenced my job opportunities. It&#8217;s opened doors for me to places that I didn&#8217;t know existed.</p>



<p>As always, I want to say thank you.  Thank you to Dave for planting the seed.  Thank you to all the contributors over the years, building something great.  Thank you to people willing to retweet for me every week. Thank you to all the people who&#8217;ve trusted me with their stories.</p>



<p>Here&#8217;s hoping for another five years!</p>



<img />Dave Rosen and I doing the X-Team X.
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\"><div class=\"rtsocial-twitter-horizontal\"><div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Five Years Since The Dream Began\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Five%20Years%20Since%20The%20Dream%20Began&via=heropress&url=https%3A%2F%2Fheropress.com%2Ffive-years-since-the-dream-began%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-fb-horizontal fb-light\"><div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Five Years Since The Dream Began\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Ffive-years-since-the-dream-began%2F\" rel=\"nofollow\" target=\"_blank\"></a></div></div><div class=\"rtsocial-linkedin-horizontal\"><div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Ffive-years-since-the-dream-began%2F&title=Five+Years+Since+The+Dream+Began\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Five Years Since The Dream Began\"></a></div></div><div class=\"rtsocial-pinterest-horizontal\"><div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/five-years-since-the-dream-began/&media=https://heropress.com/wp-content/plugins/rtsocial/images/default-pinterest.png&description=Five Years Since The Dream Began\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Five Years Since The Dream Began\"></a></div></div><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/five-years-since-the-dream-began/\" title=\"Five Years Since The Dream Began\"></a></div><p>The post <a rel=\"nofollow\" href=\"https://heropress.com/five-years-since-the-dream-began/\">Five Years Since The Dream Began</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 21 Nov 2019 15:21:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: WP Agency Summit Kicks Off December 6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95420\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wptavern.com/wp-agency-summit-kicks-off-december-6\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4819:\"<div class=\"wp-block-image\"><img /></div>



<p><a href=\"https://wpagencysummit.com/\">WP Agency Summit</a>, a virtual event for WordPress agencies, will kick off December 6, 2019, and last through December 16.  The event will feature daily sessions by over 30 WordPress professionals that are designed to help agencies grow their business.  Each session will be free to view, but there will be a price tag attached after the event closes.</p>



<p>Jan Koch, owner WP Mastery, is running the event.  WP Agency Summit is for profit, but Koch expressed a desire to give something back to the community that has helped him over the years.  &ldquo;I want this event to deliver value to the WP community, because I myself have received free support countless times from Facebook groups, forums, etc.,&rdquo; he said.  &ldquo;That&rsquo;s why the event is free to watch online while it&rsquo;s running.&rdquo;</p>



<p>The event is primarily aimed at WordPress agencies, but others may find value in it.  &ldquo;This event is also interesting for WordPress freelancers and digital agencies who occasionally use WordPress,&rdquo; said Koch.  &ldquo;However, being a WordPress agency owner myself, I wanted to ensure that business owners like myself and those in similar situations get the most value from the event.&rdquo;</p>



<p>Video sessions will be available to view for 48 hours at no cost.  For those who sign up for a free pass, they can upgrade to lifetime access for $127. That lifetime access will go up to $197 during the event and $497 afterward.</p>



<p>Potential buyers may want to opt for the free option before deciding whether future access to the sessions and bonus materials are worth plunking down the cash.  For an agency, the cost is minimal either way.  However, for a solo freelancer, the $497 price is high enough to warrant caution.  Most will want to check out the material first.</p>



<p>Each of the video sessions is prerecorded and edited rather than shot live.  Koch is using Vimeo Pro to host the videos.  There will be a live hangout to begin the event.  Attendees and speakers will also get a Facebook group invite for asking questions and engaging with each other.</p>



<p>Cloudways, Siteground, and MainWP are sponsoring the event, which helps cover some of the up-front costs.  Outside of that, Koch is handling the remainder of those costs out of his pocket but is hopeful for a positive return through the sale of lifetime access to the materials.</p>



<p>Koch first ran a virtual summit called &ldquo;The WP Summit&rdquo; in 2015, which was a more broad event based on various WordPress topics.  That event had over 2,000 registrations.  &ldquo;As you can imagine, just talking about topics related to WP resulted in a very wide-spread speaker lineup, so there weren&rsquo;t any clear takeaways,&rdquo; said Koch.</p>



<p>The idea for WP Agency Summit has been in Koch&rsquo;s mind since 2018.  It wasn&rsquo;t until some conversations with others at WordCamp Europe (WCEU) in 2019 that it started coming together.  &ldquo;After WCEU, I invested in a virtual training for summits and hired a mentor to properly set up the WP Agency Summit,&rdquo; he said.  &ldquo;My goal is to run 4 events like this in 2020, so this summit is serving as &lsquo;crash test dummy&rsquo; and foundation at the same time.&rdquo;</p>



<h2>The Speaker Lineup</h2>



<p>There are over 30 speakers signed on for the event.  Kim Doyal, a content marketer formerly known as &ldquo;The WordPress Chick,&rdquo; will teach agencies how to write copy that attracts higher-paying clients.  Ahmad Awais, core WordPress contributor, will teach how to save time writing code in the VS Code editor.</p>



<p>Most sessions will focus on how agencies can grow their business with topics related to recurring revenue, marketing, and working with clients.  Each day of the event will feature three or four sessions.</p>



<p>WP Agency Summit is hosting a diverse male lineup of over 20 speakers from Europe, Asia, Australia, Africa, and the US.  However, there are only four sessions lead by women within the industry.  &ldquo;I recognize this as a problem with my event,&rdquo; said Koch.  &ldquo;The reason I have so much more male than female speakers is quite simple, the current speaker line-up is purely based on connections I had when I started planning for the event. It was a relatively short amount of time for me, so I wasn&rsquo;t able to build relationships with more female WP experts beforehand.&rdquo;</p>



<p>Koch assures that he will have a more balanced ratio for upcoming summits in 2020 and beyond.  &ldquo;Even in this prelaunch phase, I already got in touch with many outstanding women in the WP community which would make perfect speakers for the next events,&rdquo; he said.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Nov 2019 19:50:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:110:\"HeroPress: Building A WordPress Business In Iran – ساختن یک زندگی وردپرسی در ایران\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://heropress.com/?post_type=heropress-essays&p=3012\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"https://heropress.com/essays/building-a-wordpress-business-in-iran/#utm_source=rss&utm_medium=rss&utm_campaign=building-a-wordpress-business-in-iran\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:19728:\"<img width=\"960\" height=\"480\" src=\"https://s20094.pcdn.co/wp-content/uploads/2019/11/112019-min-1024x512.jpg\" class=\"attachment-large size-large wp-post-image\" alt=\"Pull quote: Over the years, WordPress transformed my personal and profesional life. In Persian: در طی این سالها، وردپرس زندگی شخصی و حرفه‌ای من را تغییر داد.\" /><div class=\"c-message__content c-message__content--feature_sonic_inputs\">
<div class=\"c-message__message_blocks c-message__message_blocks--rich_text\">
<div class=\"p-block_kit_renderer p-block_kit_renderer--absorb_margin\">
<div class=\"p-block_kit_renderer__block_wrapper p-block_kit_renderer__block_wrapper--first\">
<div class=\"p-rich_text_block\" dir=\"auto\">
<div class=\"p-rich_text_section\"><a href=\"https://heropress.com/feed/#fas\">این مقاله به زبان فارسی نیز در دسترس است.</a></div>
</div>
</div>
</div>
</div>
</div>
<p>I purchased my first computer set when I was 19 years old, but several years before that, at the age of 15, I took a computer and MS-DOS training course and without having a computer, by merely practicing on paper, I managed to get the perfect score on the final exam.</p>
<p>It was during those years that internet gradually entered our town. Well, don’t be shocked. Internet was introduced to our small town pretty late and we got acquainted with this technological phenomenon very late. However, internet instantly found its place in my daily routine and I was fascinated by it.  After surfing the internet for a year, I was little by little encouraged to find out what a website is and how it works. Thus, I familiarized myself with the first programming language, that is, HTML and began learning it and given my enthusiasm, I mastered it in less than 10 days.</p>
<p>I was increasingly attracted to the internet and the issues pertinent to it, and soon enough I was drawn to various internet technologies. In less than a year, I was able to learn PHP, CSS, and HTML and relying on my limited knowledge, I began testing different systems and scripts.</p>
<h3>Introduction to Blogging</h3>
<p>During those same years, I worked with various blog systems, one of which was B2 system. A little while later, while conducting tests, doing installations, and having fun, I encountered a system which was quite similar to B2. I installed it. Then, I entered its various parts.  I found its management system, templates and codes quite appealing and easy to work with. Thus, I began translating it into Persian for my personal purposes, and in less than a week, I turned most of its various parts into Persian and they were ready to be used. Yet, due to certain reasons, I failed to install this system on my host or test it online. But I kept the system on my computer and I worked with it and enjoyed it. Yes, that system was one of the first versions of WordPress.</p>
<p>Prior to working with WordPress, I had worked with various systems and scripts, and I was primarily accustomed to Joomla. However, simplicity, convenience, and interesting environment of WordPress drew me towards this system and I kept working with it.</p>
<p>I was by nature shy and reticent; therefore, I was not that active in any groups or forums –this was the case in my personal life as well as on the web. Consequently, during the first few years of my activity in the field of WordPress, I hardly ever participated in WordPress forums or local groups.</p>
<h3>Getting Involved</h3>
<p>However, one of my friends who was active in the field of Persian WordPress, invited me to collaborate with one of the Persian WordPress support forums and this was a new beginning for me in the area of localization of WordPress.</p>
<p>My keen interest in working with WordPress as well as helping others work and become more familiar with it made me spend a lot of time daily in the Persian WordPress forum. Nevertheless, due to the shortcomings and needs of the Persian WordPress community, we also created another support website. Following the creation of this new website, many users were attracted to it and gradually we got a lot of feedback from the Persian WordPress community. So, we became further involved with the Persian WordPress community and the scope of our activities expanded.</p>
<p>It was during these years that I got my first formal job offer in the field of WordPress and I launched the first WordPress website for a client and received money in return for my services.  This experience highly motivated me and helped me envision my future as a WordPress developer. Meanwhile, with the help of some of my friends, I started a small web design and development company which was supposed to focus on coding and programming electronic components, but my keen enthusiasm for web development drew the entire team to focus on web design and development. Due to my numerous activities in the field of WordPress and my growing recognition as a WordPress activist, over the course of a few years, virtually all of our company activities centered on WordPress as the main basis of our work, and now we are one of the active supporters of WordPress in Iran.</p>
<h3>Transformations</h3>
<p>Over the years, WordPress transformed my personal and professional life. My personal life was changed in the respect that from a shy, quiet and inactive guy, I turned into an energetic, active person interested in discussions and participation in social events. Along the way, I also met great and influential people, including my future spouse.</p>
<p>We organized various gatherings and meetups in the field of WordPress. We held WordPress seminars. We set up various public forums and groups to enhance the impact of WordPress and educate newcomers, and thus, many changes occurred in my overall mood and personality.</p>
<p>Besides, prior to the general change of direction in our company towards web and especially WordPress, our revenues were low and the company had a very slow growth; yet following our change of direction and basing the structure of the company on WordPress, our annual growth rate increased dramatically and there was a considerable increase in the size of the company, number of the personnel, and payments.</p>
<p>I should also mention that I am a graduate of textile engineering. However, my field of study has nothing to do with my career interests. Since from a very young age I dreamt of working in the field of computer science, even studying an irrelevant major did not stop me from pursuing my old dream and while studying textile engineering, I worked in the field of computer science and in my own company.</p>
<p>Now, 16 years after my first encounter with WordPress, it has pervaded every aspect of my life and has changed me personally, mentally, and professionally and has influenced my choice of career and business. And I am really glad that on that day I became familiar with WordPress and started working with it and am still involved with it up to this day, because not only my life changed as a result, but also I managed to educate so many people and help them transform their lives in a way that WordPress played a major role in their lives and contributed to their further success.</p>
<h1 id=\"fas\">ساختن یک زندگی وردپرسی در ایران</h1>
<p>من اولین کامپیوتر خود را وقتی ۱۹ ساله بودم خریدم ولی چندین سال قبل از آن  در سن 15 سالگی به کلاس آموزش کامپیوتر و دوره آموزشی کار با DOS رفتم  و بدون داشتن کامپیوتر و با تمرین روی کاغذ توانستم نمره کامل رو در آزمون نهایی کسب کنم.</p>
<p>در همان سالها بود که اینترنت کم کم وارد شهر ما شد، بله تعجب نکنید درشهرکوچک ما اینترنت خیلی دیر وارد شد و ما خیلی دیر با این پدیده آشنا شدیم اما اینترنت به سرعت جای خود را در کارهای روزمره من باز کرد و من شیفته آن شدم بعد از یک سال کار کردن با اینترنت من کم کم ترغیب شدم که بفهمم سایت چیست و چگونه کار میکند و با اولین زبان یعنی HTML آشنا شدم و شروع به یادگیری آن کردم و با اشتیاق فراوانی که داشتم آن را در کمتر از ۱۰ روز یاد گرفتم.</p>
<p>من هر روز بیشتر جذب اینترنت و موضوعات مرتبط با آن می شدم و به سرعت به سوی تکنولوژی های مختلف اینترنتی کشیده شدم. یک سال هم طول نکشید که توانستم HTML / CSS / PHP را یاد بگیرم و با همون دانش اندک، شروع به تست سیستم و اسکریپتهای مختلف کردم.</p>
<h3>مقدمه‌ای برای شروع</h3>
<p>در همان سال‌ها من با سیستم‌های وبلاگی مختلفی کار کردم که یکی از آن‌ها سیستم b2 بود. کمی بعدتر در همین تستها و نصب‌ها و بازیگوشی ها  با سیستمی مواجه شدم که بسیار شبیه b2 بود. آن را نصب کردم سپس وارد بخش‌های مختلف آن شدم، سیستم مدیریت، بخش قالب و کدهای آن و بسیار برایم ساده و جالب و جذاب به نظر رسید و به همین دلیل شروع به فارسی کردن آن برای کارهای شخصی خود کردم و کمتر از یک هفته بخش‌های مختلف آن را تا حدود زیادی فارسی و آماده استفاده کرده بودم. اما به دلایل خاصی موفق نشدم که آن را بر روی هاست خود نصب و به صورت آنلاین تست کنم. ولی آن سیستم را بر روی کامپیوتر خود نگه داشتم و با آن کار می کردم و لذت می بردم. بله آن سیستم یکی از اولین نسخه های وردپرس بود.</p>
<p>من قبل از کار با وردپرس با سیستم ها و اسکریپت های مختلفی کار کرده بودم و بیشترین اسکریپتی که با آن انس گرفته بودم جوملا بود اما سادگی و روانی و محیط جذاب مدیریت وردپرس باعث شد که من به سمت وردپرس کشیده شوم و کار با آن را ادامه دهم.</p>
<p>من ذاتا آدم کم حرف و خجالتی بودم و به همین دلیل خیلی در گروه ها و انجمن های خاصی فعالیت نمی‌کردم و این هم شامل وب و هم شامل زندگی عادی من میشد به همین دلیل تا چند سال اولیه فعالیت من در وردپرس، خیلی در انجمنهای تخصصی و یا گروه های محلی آن  فعالیتی نداشتم.</p>
<h3>شروع مشارکت</h3>
<p>تا اینکه یکی از دوستان من که از فعالان وردپرس در زبان فارسی بود من را دعوت به همکاری در یکی از انجمن های پشتیبانی وردپرس به زبان فارسی کرد و این شروعی دوباره برای من در زمینه محلی سازی وردپرس بود.</p>
<p>علاقه زیاد من به کار با وردپرس و همچنین کمک به دیگران برای کار و آشنایی بیشتر با وردپرس باعث شد که من روزانه زمان زیادی را در انجمن وردپرس فارسی صرف کنم. اما با توجه به کمبود ها و نیازهایی که جامعه فارسی داشت ما یک سایت پشتیبانی دیگر را نیز ایجاد کردیم با ایجاد سایت جدید کاربران زیادی جذب ما شدند و کم کم ما بازخوردهای زیادی را از جامعه فارسی گرفتیم به همین دلیل بیشتر درگیر جامعه فارسی وردپرس شدیم و دامنه فعالیت های ما نیز گسترش پیدا کرد.</p>
<h3>دگرگونی</h3>
<p>در همین سال‌ها اولین پیشنهاد کاری رسمی من در زمینه وردپرس رسید و من اولین سایت خود را برای یک مشتری با وردپرس برپا کردم و در قبال آن مبلغی را دریافت کردم که این موضوع باعث شد انگیزه زیادی در من شکل بگیرد و مسیر حرکتی آینده خود را در وردپرس ببینم. همزمان، با کمک چند نفر از دوستان خود یک شرکت طراحی و برنامه نویسی کوچک را تاسیس کردیم که روند آن قرار بود بر کدنویسی و برنامه نویسی برای قطعات الکترونیکی باشد اما اشتیاق فراوان من به طراحی وب باعث شد که نظر کلیه جمع نیز به سمت کدنویسی و طراحی وب کشیده شود. با توجه به فعالیت‌های زیاد من در وردپرس و بیشتر شناخته شدن من به عنوان یک فعال وردپرسی، در طی یک بازه زمانی چند ساله، کلیه فعالیت های شرکت ما نیز به سمت وردپرس کشیده شد و مبنای اصلی کارهای ما وردپرس شد و هم اکنون ما یکی از حامیان فعال وردپرس در ایران هستیم.</p>
<p>طی سالیان مختلف وردپرس زندگی شخصی و کاری من را تغییر داد. زندگی شخصی من را از این جهت تغییر داد که از یک آدم خجالتی و کم حرف و کم فعالیت به یک آدم فعال، پر انرژی و علاقمند به بحث و گفتگو و حضور در اجتماعات تبدیل شوم. در این مسیر با افراد بزرگ و تاثیرگذار منجمله با همسر آینده خود نیز آشنا شدم.</p>
<p>اجتماعات و میتاپهای مختلفی را در زمینه وردپرس راه اندازی نمودیم. سمینار های وردپرسی برگزار کردیم. انجمن ها و گروه‌های مردمی مختلفی را در جهت افزایش نفوذ وردپرس و آموزش آن به افراد تازه کار راه اندازی کردیم و به همین دلیل تغییرات زیادی در روحیه و خلقیات و شخصیت کلی من ایجاد شد.</p>
<p>همچنین تا قبل از تغییر روند کلی شرکت ما به سمت وب و علی‌الخصوص وردپرس، شرکت درآمد خاصی نداشت و بسیار کند رشد می کرد اما پس از تغییر رویه و راه اندازی بستر اصلی شرکت بر روی وردپرس روند سالانه ما به شدت رشد کرد و هم از نظر اندازه و هم تعداد کارکنان و هم از نظر سطح دستمزد و حقوق پیشرفت چشمگیری در شرکت ایجاد شد.</p>
<p>این را هم اضافه کنم که من فارغ التحصیل در رشته مهندی نساجی هستم. اما رشته تحصیلی من با رشته و علاقمندی کا ی من کاملا از هم جدا و نامرتبط هستند. چون من از جوانی آرزو و شوق کار کردن در زمینه کامپیوتر را داشتم و حتی تحصیل در رشته ای نامرتبط هم سبب نشد که دست از آرزوی قدیمی خود بردارم  و حتی همزمان با تحصیل در رشته نساجی، در زمینه کامپیوتر و در شرکت خود مشغول به کار بودم.</p>
<p>حالا ۱۶ سال از اولین برخورد و کار من با وردپرس می‌گذرد و وردپرس تقریباً در همه زمینه های مختلف زندگی من نفوذ کرده و باعث تغییر من در زمینه شخصی، روحی و کاری و کسب و کار  من شده است و از این بابت بسیار خوشحال هستم که آن روز توانستم با وردپرس آشنا شده و شروع به کار کنم و تا به امروز نیز درگیر آن باشم.</p>
<p>زیرا علاوه بر اینکه زندگی من تغییر کرد، توانستم افراد زیادی را نیز آموزش داده و به آنها کمک کنم تا زندگی‌ آنها نیز تغییر کند و وردپرس شاکله زندگی آنها را تشکیل داده و باعث موفقیت بیشتر آنها شود.</p>
<p>&nbsp;</p>
<div class=\"rtsocial-container rtsocial-container-align-right rtsocial-horizontal\">
<div class=\"rtsocial-twitter-horizontal\">
<div class=\"rtsocial-twitter-horizontal-button\"><a title=\"Tweet: Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران\" class=\"rtsocial-twitter-button\" href=\"https://twitter.com/share?text=Building%20A%20WordPress%20Business%20In%20Iran%20%2D%20%D8%B3%D8%A7%D8%AE%D8%AA%D9%86%20%DB%8C%DA%A9%20%D8%B2%D9%86%D8%AF%DA%AF%DB%8C%20%D9%88%D8%B1%D8%AF%D9%BE%D8%B1%D8%B3%DB%8C%20%D8%AF%D8%B1%20%D8%A7%DB%8C%D8%B1%D8%A7%D9%86&via=heropress&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-wordpress-business-in-iran%2F\" rel=\"nofollow\" target=\"_blank\"></a></div>
</div>
<div class=\"rtsocial-fb-horizontal fb-light\">
<div class=\"rtsocial-fb-horizontal-button\"><a title=\"Like: Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران\" class=\"rtsocial-fb-button rtsocial-fb-like-light\" href=\"https://www.facebook.com/sharer.php?u=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-wordpress-business-in-iran%2F\" rel=\"nofollow\" target=\"_blank\"></a></div>
</div>
<div class=\"rtsocial-linkedin-horizontal\">
<div class=\"rtsocial-linkedin-horizontal-button\"><a class=\"rtsocial-linkedin-button\" href=\"https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fheropress.com%2Fessays%2Fbuilding-a-wordpress-business-in-iran%2F&title=Building+A+WordPress+Business+In+Iran+%26%238211%3B+%D8%B3%D8%A7%D8%AE%D8%AA%D9%86+%DB%8C%DA%A9+%D8%B2%D9%86%D8%AF%DA%AF%DB%8C+%D9%88%D8%B1%D8%AF%D9%BE%D8%B1%D8%B3%DB%8C+%D8%AF%D8%B1+%D8%A7%DB%8C%D8%B1%D8%A7%D9%86\" rel=\"nofollow\" target=\"_blank\" title=\"Share: Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران\"></a></div>
</div>
<div class=\"rtsocial-pinterest-horizontal\">
<div class=\"rtsocial-pinterest-horizontal-button\"><a class=\"rtsocial-pinterest-button\" href=\"https://pinterest.com/pin/create/button/?url=https://heropress.com/essays/building-a-wordpress-business-in-iran/&media=https://heropress.com/wp-content/uploads/2019/11/112019-min-150x150.jpg&description=Building A WordPress Business In Iran - ساختن یک زندگی وردپرسی در ایران\" rel=\"nofollow\" target=\"_blank\" title=\"Pin: Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران\"></a></div>
</div>
<p><a rel=\"nofollow\" class=\"perma-link\" href=\"https://heropress.com/essays/building-a-wordpress-business-in-iran/\" title=\"Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران\"></a></div>
<p>The post <a rel=\"nofollow\" href=\"https://heropress.com/essays/building-a-wordpress-business-in-iran/\">Building A WordPress Business In Iran &#8211; ساختن یک زندگی وردپرسی در ایران</a> appeared first on <a rel=\"nofollow\" href=\"https://heropress.com\">HeroPress</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 20 Nov 2019 04:30:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Morteza Geransayeh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: 10up Releases GitHub Actions for Simplifying WordPress Plugin Deployment\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95388\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wptavern.com/10up-releases-github-actions-for-simplifying-wordpress-plugin-deployment\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6671:\"<p>10up announced the <a href=\"https://10up.com/blog/2019/wordpress-github-actions-streamline-plugin-deployment/\">public availability of two GitHub Actions</a> geared toward WordPress plugin developers yesterday.  The first Action allows developers to deploy plugin updates directly to the WordPress.org plugin directory by tagging a release on GitHub.  The second Action handles readme file and asset updates. </p>



<p>On November 14, GitHub <a href=\"https://github.blog/2019-11-14-powering-community-led-innovation-with-github-actions/\">announced the public launch</a> of their GitHub Actions feature.  GitHub Actions are a way for developers to automate workflows from their Git repositories.  Actions can also be shared with others, reused across projects, and forked like any other public repository.</p>



<p>Currently, there are over 1,300 GitHub Actions with more being added every day.  At least <a href=\"https://github.com/marketplace?utf8=%E2%9C%93&type=actions&query=wordpress\">nine of the current Actions</a> are related to WordPress, including an Action to <a href=\"https://wptavern.com/rtcamp-releases-github-actions-for-automated-code-review-deploying-wordpress-and-slack-notifications\">deploy WordPress by rtCamp</a>, but there will certainly be more to come in the future.</p>



<p>With GitHub Actions out of beta, it opens the door for companies like 10up to share their custom workflows and for others to build upon them.  It will also be interesting to see what Actions other developers within the WordPress ecosystem release.</p>



<p>The 10up team initially <a href=\"https://10up.com/blog/2019/introducing-github-actions-for-wordpress-plugins/\">launched their custom Actions</a> for WordPress in March 2019, which was during GitHub Actions beta period.  &ldquo;Everybody has been very positive,&rdquo; said Helen Hou-Sand&iacute;, director of open source initiatives at 10up and WordPress lead developer.  &ldquo;We&rsquo;ve had a number of people report bugs, request enhancements, and contribute code and documentation. That&rsquo;s been a really great measure of adoption and attention for me &mdash; having people give thoughtful critical feedback and help us improve this tool for everybody.&rdquo;</p>



<p>Hou-Sand&iacute; is interested in seeing other ideas for adding workflows or potentially new Actions from the community.  &ldquo;An example of something we&rsquo;ve just started doing without writing a whole new Action is generating hook documentation and deploying that to GitHub Pages, which eliminates the need to generate locally, commit manually, and decide on where to host things,&rdquo; she said.</p>



<p>&ldquo;Development was actually smoother than I anticipated,&rdquo; said Hou-Sand&iacute; of creating and testing the team&rsquo;s GitHub Actions.  &ldquo;Maybe because I spent a fairly long time planning and obsessing over potential issues and chose to use Bash.&rdquo;  For testing, she was able to use an inactive plugin repo on WordPress.org.  &ldquo;I&rsquo;m sure I could have come up with a method to test completely locally, but being able to use actual environments without repercussions was helpful.&rdquo;</p>



<p>The 10up team has already been deploying plugin updates with the Actions.  Hou-Sand&iacute; said that she does not think about this in terms of saving time, even though the team is already tagging releases via GitHub.  </p>



<p>&ldquo;What it&rsquo;s really done for us is, along with well-documented release processes, made it so that anybody can jump in and get a plugin updated or released without worrying about modifying commit permissions or their personal knowledge of SVN,&rdquo; she said.  &ldquo;This makes it much easier to get releases out especially when it&rsquo;s an urgent bugfix.&rdquo;</p>



<h2>Deploying and Updating WordPress Plugins</h2>



<p>Both of the GitHub Actions created by 10up help ease the pain of deploying plugin updates to the official WordPress plugin directory.  They are designed to streamline plugin release management and simplify the process of getting code out to end-users.</p>



<p>WordPress plugin authors must use Subversion (SVN) to commit and tag plugin releases in the directory.  Often, this is an issue because Git is the most-used version control system.  Some developers have no experience with SVN, and the number of developers unfamiliar with it will likely only grow as Git continues to gain popularity.  Even with those who do understand SVN, switching between version control systems can hinder workflows, particularly with larger teams.</p>



<p>With so many WordPress plugin developers using Git, it makes sense to use tools that are a part of their daily workflow rather than jumping into a system only used during releases.  That is where both of these GitHub Actions developed by 10up can help.  </p>



<p>Adding Actions to a repository is a fairly straightforward process.  All repositories have a new &ldquo;Actions&rdquo; tab.  Developers can create new workflows directly from the Actions page for their repository.  When adding a new workflow, it is simply a matter of copying and pasting a particular Action&rsquo;s code snippet.</p>



<div class=\"wp-block-image\"><img />Adding a custom GitHub workflow.</div>



<p>The <a href=\"https://github.com/marketplace/actions/wordpress-plugin-deploy\">WordPress Plugin Deploy</a> Action is for deploying plugin updates directly to the WordPress plugin directory.  When developers tag a release on GitHub, it will automatically commit the update to the WordPress.org SVN repository.  The Action respects <code>.distignore</code> and <code>.gitattributes</code> for ignoring files that should not be distributed to users.  It also allows developers to add their plugin assets to a <code>.wordpress-org</code> folder, which will be committed to the top-level <code>assets</code> directory.</p>



<p><a href=\"https://github.com/marketplace/actions/wordpress-plugin-readme-assets-update\">WordPress.org Plugin Readme/Assets Update</a> is a separate Action that allows developers to commit changes to their plugin&rsquo;s readme or assets.  It is useful when plugin authors need to update their plugin&rsquo;s <code>Tested up to</code> version number or update screenshots, banners, and icons.  This Action watches for changes on a specified branch.</p>



<p>Both Actions require developers to set up secret values for their WordPress SVN username and password.  Secrets are encrypted data that can be set via a repository&rsquo;s &ldquo;Settings &gt; Secrets&rdquo; screen.  The SVN username and password are required so that GitHub can deploy commits to WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 Nov 2019 23:00:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WordPress.org blog: WordPress 5.2.4 Update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7787\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/news/2019/11/wordpress-5-2-4-update/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1100:\"<p>Late-breaking news on the<a href=\"https://wordpress.org/news/2019/10/wordpress-5-2-4-security-release/\"> 5.2.4 short-cycle security release </a>that landed October 14. When we released the news post, I inadvertently missed giving props to Simon Scannell of <a href=\"https://blog.ripstech.com/\">RIPS Technologies</a> for finding and disclosing an issue where path traversal can lead to remote code execution. </p>



<p>Simon has done a <a href=\"https://wordpress.org/news/2018/12/wordpress-5-0-1-security-release/\">great</a> <a href=\"https://wordpress.org/news/2019/03/wordpress-5-1-1-security-and-maintenance-release/\">deal</a> of <a href=\"https://wordpress.org/news/2019/09/wordpress-5-2-3-security-and-maintenance-release/\">work</a> on the WordPress project, and failing to mention his contributions is a huge oversight on our end.</p>



<p>Thank you to all of the reporters for <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">privately disclosing</a> vulnerabilities, which gave us time to fix them before WordPress sites could be attacked.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 19 Nov 2019 04:47:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jake Spurlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: Gutenberg 6.9 Introduces Image Titles, Block Patterns, and New Theme Features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95365\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"https://wptavern.com/gutenberg-6-9-introduces-image-titles-block-patterns-and-new-theme-features\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5671:\"<p>On November 13, the Gutenberg team <a href=\"https://make.wordpress.org/core/2019/11/13/whats-new-in-gutenberg-13-november/\">launched version 6.9</a> with several features, most of which were aimed at developers.  Users can now add custom image title attributes.  Plugin developers can start diving into the new Block Patterns API.  Plus, theme authors can begin tinkering with the experimental gradient presets and block templates features.</p>



<p>Gutenberg 6.9 fixed numerous bugs, including an annoying <a href=\"https://github.com/WordPress/gutenberg/issues/16429\">invalid content error</a> when selecting a color for the pullquote block.  The update included several enhancements and changes to the underlying codebase.</p>



<p>Much of the work in version 6.9 went toward experimental features, including the navigation block.  At this point, the nav block still needs a ton of work for practical use.  The interface is still a bit clunky.  Undoubtedly, this is one of the toughest user experience challenges to solve and will take time before it is ready for widespread usage.  Right now, it is about continually iterating upon the work from previous versions.</p>



<h2>Image Title Attribute Field</h2>



<div class=\"wp-block-image\"><img />Editing the image title field in Gutenberg.</div>



<p>The ability to add image titles is perhaps the biggest user-facing feature added in Gutenberg 6.9.  The <a href=\"https://github.com/WordPress/gutenberg/issues/11054\">original ticket</a> for adding the feature has been simmering for over a year.</p>



<p>The Gutenberg team added the title field under the &ldquo;Advanced&rdquo; tab when editing an image block. This was a smart decision because image titles are often used incorrectly to describe an image, which is the job of the &ldquo;Alt Text&rdquo; field located under the &ldquo;Image Settings&rdquo; tab.  Image titles are also generally unnecessary.  When used, they should describe the role of the image on the page.</p>



<h2>Initial Block Patterns API Merged</h2>



<div class=\"wp-block-image\"><img />Choosing a column layout in the block editor.</div>



<p>The Block Patterns API is a developer feature primarily for creating initial setup states for complex blocks.  For example, the columns block has several common patterns that users may want to choose. By providing those patterns when first inserting a block, the user does not have to go through the routine of configuring all of the settings for it.</p>



<p>The idea is to cut back on the complexities of configuring some blocks so that users can more quickly get to the point of adding their custom content and getting their desired results.</p>



<p>The first step toward the Block Patterns API was <a href=\"https://github.com/WordPress/gutenberg/pull/18270\">merged into Gutenberg 6.9</a>, but it is still in the experimental stage at this point.</p>



<h2>Block Gradient Presets</h2>



<div class=\"wp-block-image\"><img />Adding a gradient background to a button in Gutenberg.</div>



<p>Gutenberg introduced gradient backgrounds in <a href=\"https://wptavern.com/gutenberg-6-7-introduces-storybook-and-gradient-backgrounds\">version 6.7</a> for the button block. The feature launched with a set of gradients that did not match users&rsquo; themes, which meant the feature was little more than a fun experiment.</p>



<p>In version 6.9, developers can register custom gradients that are less of an eyesore by using colors that fit into the theme&rsquo;s color palette.</p>



<p>Currently, <a href=\"https://developer.wordpress.org/block-editor/developers/themes/theme-support/#block-gradient-presets\">block gradient presets</a> are marked as an experimental feature and use the <code>__experimental-editor-gradient-presets</code> theme support flag.  Now is a good time for theme authors to begin exploring this feature so they can be ready when the experimental flag is removed.</p>



<h2>Block Templates for Themes</h2>



<p>For theme authors, block templates were the most exciting aspect of Gutenberg&rsquo;s potential when it first launched.  Throughout all of WordPress&rsquo; history, creating custom page templates, particularly front page templates, has been an exercise in frustration.  Theme authors have always had great ideas about what their themes&rsquo; front pages should look like.  In a way, it is an author&rsquo;s signature on a theme project.  It is often what sets one theme apart from another.</p>



<p>However, creating an interface that allows users to change what is traditionally a blog post list to something more ornate and complex is not an easy thing to do.  Hundreds, perhaps thousands, of varying implementations are currently in the wild, each with their take on how to create a custom front page.</p>



<p>Enter Gutenberg.  Theme authors, regardless of whether they love or hate it, usually see the potential of a block-based editor in terms of laying out a front page.  The idea of having complete control over where specific blocks sit and how they appear on the front end is an alluring one, especially if there is a standardized experience for users to figure out how to plug their content into the blocks.</p>



<p>Gutenberg 6.9 <a href=\"https://github.com/WordPress/gutenberg/pull/18247\">laid the groundwork</a> toward this reality by resolving block templates from a theme&rsquo;s <code>/block-templates</code> folder.</p>



<p>At this point, theme block templates are still in the experimental stage as part of the <a href=\"https://github.com/WordPress/gutenberg/issues/17512\">full site editing feature</a>.  From a theme development perspective, this could be revolutionary.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 18 Nov 2019 19:03:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"Post Status: Scott Bolinger on WordPress, JAMstack, and the future of the independent developer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=71326\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://poststatus.com/wordpress-jamstack/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1790:\"<p>In this episode, Scott and I dig into his experience as an indie developer within the WordPress landscape.</p>



<p>Scott has long used JavaScript as a core technology with AppPresser. I think he\'s on the forefront of thinking about and using technologies that are new to WordPress but out in full force in other ecosystems. </p>



<p>Scott is really into <a href=\"https://jamstack.org/\">JAMstack</a> (JavaScript, APIs, Markup). He\'s working on <a href=\"https://staticfuse.com/\">Static Fuse</a> now, which helps connect WordPress to <a href=\"https://www.gatsbyjs.org/\">Gatsby</a>. Gatsby has a <em>lot</em> of attention in web tech right now.</p>



<p>We also dig pretty deeply into the challenges and opportunities facing independent developers, and the interest levels in WordPress from the indie dev crowd. It\'s an interesting episode, and I learned a lot from Scott. I hope you do too. Enjoy our conversation!</p>







<h3>Other links from the show</h3>



<ul><li><a href=\"https://graphql.org/\">GraphQL</a> and <a href=\"https://www.wpgraphql.com/\">WPGraphQL</a></li><li><a href=\"https://scottbolinger.com/\">Scott\'s website</a></li><li><a href=\"https://theproductbusiness.com/podcast/\">The Product Business podcast</a></li><li>Zac Gordon\'s <a href=\"https://javascriptforwp.com/product-category/courses/\">JavascriptforWP</a> courses</li></ul>



<h3>Sponsor: Sandhills Development</h3>



<p><a href=\"http://sandhillsdev.com/\">Sandhills Development</a>&nbsp;makes a suite of excellent plugins to power your WordPress website. Whether you need to sell digital downloads, restrict content, create an affiliate program, or manage an events calendar, they’ve got you covered. Thanks to&nbsp;<a href=\"http://sandhillsdev.com/\">Sandhills</a>&nbsp;for being a Post Status partner.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 16 Nov 2019 16:36:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: 24 WordPress Snippets ’til Christmas, Submissions Open for 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95346\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"https://wptavern.com/24-wordpress-snippets-til-christmas-submissions-open-for-2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5943:\"<div class=\"wp-block-image\"><img /></div>



<p>After a multi-year hiatus, Elliott Richmond has relaunched his WordPress advent calendar and is looking for volunteers.  The <a href=\"https://advent.elliottrichmond.co.uk/\">WP Snippets &rsquo;til Christmas</a> site will host 24 days of WordPress code snippets starting on December 1 and lasting until December 24.  With each passing day, a new code snippet will be revealed.</p>



<p>Advent calendars are special types of calendars used to count down the days until Christmas.  They are often a part of religious celebrations but can be used for other purposes such as family traditions and games.  For Richmond&rsquo;s advent calendar, it is a way to contribute something back to the WordPress community.</p>



<p>Richmond opened the site for developers to make contributions to the 24-day event.  &ldquo;I&rsquo;ve been in touch with the original contributors in the hope that they&rsquo;ll submit again and registration is also open to anyone else who wishes to contribute,&rdquo; he said.  &ldquo;Otherwise, it will just be the Elliott Richmond show.&rdquo;  </p>



<p>He would rather have community submissions than attempting to write all 24 code snippets alone.  Jeff Starr, Zac Gordon, and Tom McFarlin, all prominent developers in the WordPress community, have already signed on to submit code.  <em>Author&rsquo;s note: I am also considering joining because it sounds like fun.</em></p>



<p>Anyone who wants to receive updates each day of the event can register for free on the <a href=\"https://advent.elliottrichmond.co.uk/\">WP Snippets &rsquo;til Christmas</a> website.  The same signup form is available for contributors.</p>



<p>There are no limitations on the types of code snippets that contributors can submit, only that they should be related to WordPress.  Richmond says he has some ideas such as a WP-CLI script and a deployment tool for use on the command line.  However, code snippets can be something as simple as sticking a basic function into a theme to more complex scripts.</p>



<p>&ldquo;I come from a frontend world and I&rsquo;m a self-taught PHP developer,&rdquo; said Richmond.  &ldquo;I&rsquo;m evolving constantly and always eager to learn new things. I think WordPress is similar, it&rsquo;s always evolving and inspiring innovation. If you put any limitations on things they rapidly become stagnated.&rdquo;</p>



<p>The code snippets are not aimed at any type of WordPress user in particular.  &ldquo;I think it&rsquo;s really useful to see bite-size code snippets to help those in the community who are taking that next step into development,&rdquo; said Richmond.  &ldquo;To those more seasoned developers, I think it&rsquo;s always useful to see how other developers approach things.&rdquo;</p>



<p>Each code snippet will have an open comments section similar to a traditional blog.  This will allow others to say thanks for sharing or to jump-start a conversation.</p>



<h2>The Road Back to the Advent Calendar</h2>



<p>Richmond has been a WordPress user and developer since the launch of the platform.  He is the director of <a href=\"https://squareone.software/\">Square One Software</a>, a software development company that specializes in WordPress development.</p>



<p>He <a href=\"https://wptavern.com/wordpress-snippets-til-christmas-submissions-opened-for-2013\">last ran the advent calendar</a> in 2013.  After the success of the first year in 2012, he decided to put it together for a second round.  He wanted to keep it going beyond the first two years, but work and other commitments took priority.</p>



<p>In the years since, Richmond met other local WordPress enthusiasts at WordCamp London.  He now helps host the local meetup in Cheltenham, UK.  With the help of the community, he organized four teams of local project managers, designers, developers, and content writers for a <a href=\"https://doaction.org/event/cheltenham-2019/\">local do_action event</a>.  &ldquo;I&rsquo;m still an enthusiastic proponent of giving back to the community and actively encourage others in our local community to share their experience and knowledge,&rdquo; said Richmond.</p>



<p><a href=\"https://doaction.org/\">do_action</a> events are charity hackathons that use WordPress to help provide local charity organizations an online presence.</p>



<p>&ldquo;Every single team and team member did an amazing job on the day for four local non-profit charities, putting together a functional WordPress website for each charity while I personally gave a charity representative some hands-on training,&rdquo; said Richmond.  &ldquo;Taking away some of the overhead of creating a website for the charities allows them to concentrate on what they do best, which is raising money for their own community.&rdquo;</p>



<p>Richmond described needing to find something to do next while still riding the buzz from the event.  That is when he decided to relaunch the WP Snippets &rsquo;til Christmas event.</p>



<hr class=\"wp-block-separator\" />



<p>Because it is the season, Richmond crowned &ldquo;It&rsquo;s a Wonderful Life&rdquo; as the greatest Christmas movie.</p>



<p>&ldquo;I love classics and this one is a true classic, pretty apt in the current move to make people aware of mental health,&rdquo; said Richmond.  &ldquo;The movie starts with depression and pending suicide when a guardian angel is bestowed to the main character George Bailey. George is shown how many lives he&rsquo;s impacted on in his own local community and how things would have been if he didn&rsquo;t exist, a real heartwarming feel-good reflection on the things that we take for granted in our own existence.&rdquo;</p>



<p>With this upcoming holiday season, considering taking the time to give back to both your local community and the WordPress community.  One great way to do that is to contribute a code snippet to WP Snippets &rsquo;til Christmas.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 15 Nov 2019 21:10:28 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"bbPress: bbPress 2.6.1 is out!\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://bbpress.org/?p=205662\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://bbpress.org/blog/2019/11/bbpress-2-6-1-is-out/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2442:\"<p>It seems like only <a href=\"https://bbpress.org/blog/2019/11/bbpress-2-6/\">yesterday that 2.6.0</a> was released, and depending on where you live that might actually be true! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f5d3.png\" alt=\"🗓\" class=\"wp-smiley\" /></p>



<p>bbPress 2.6.1 fixes a few small (but very annoying bugs) that warranted some immediate attention:</p>



<ul><li><a href=\"https://bbpress.trac.wordpress.org/ticket/3232\">One</a> was causing subforums not to be listed underneath their parents anymore.</li><li><a href=\"https://bbpress.trac.wordpress.org/ticket/3281\">Another</a> was causing styling issues for a few of the themes that come bundled with WordPress itself.</li><li><a href=\"https://bbpress.trac.wordpress.org/ticket/3280\">The last one</a> was causing issues with posting content within WordPress Admin, because of incompatibility with a few plugins that were interacting with the REST API in admin area pages in fun ways that we hadn&#8217;t anticipated yet.</li></ul>



<p>Thanks to the quick reporting of <a href=\"https://bbpress.org/forums/profile/stevehammatt/\">stevehammatt</a> and <a href=\"https://bbpress.org/forums/profile/pdvwp/\">pdvwp</a>, we were able to identify all of these problems and get them into bbPress 2.6.1 right away. You both rock! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f44f.png\" alt=\"👏\" class=\"wp-smiley\" /></p>



<p class=\"has-text-color has-background has-very-dark-gray-color has-very-light-gray-background-color\">One bug still remains that we could use your help with, that is affecting sites that have a custom <code>bbpress.css</code> file in their theme. If you need to fix this ASAP, you can rename it to <code>bbpress.min.css</code> temporarily. If you&#8217;re able to chime into <a href=\"https://bbpress.org/forums/topic/child-css/\">this topic in the forums</a>, that would be super helpful!</p>



<p>If you have a few moments, the great Justin Tadlock from WPTavern <a href=\"https://wptavern.com/bbpress-2-6-released-after-6-years-includes-per-forum-moderation-and-engagements-api\">asked me a few questions about bbPress 2.6</a>, so consider giving it a read.</p>



<p>Lastly, thank you everyone for the positive comments and responses to seeing bbPress 2.6 finally happen. It made my day, and I really appreciate it. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f49a.png\" alt=\"💚\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Nov 2019 23:48:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"WPTavern: bbPress 2.6 Released After 6 Years, Includes Per-Forum Moderation and Engagements API\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95336\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"https://wptavern.com/bbpress-2-6-released-after-6-years-includes-per-forum-moderation-and-engagements-api\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7007:\"<p>On Tuesday, John James Jacoby announced that bbPress 2.6 was available to the public after a six-year wait in a post titled <a href=\"https://bbpress.org/blog/2019/11/bbpress-2-6/\">bbPress 2.6 &mdash; Better Great Than Never</a>.  The announcement landed with a whimper as it was overshadowed by the release of WordPress 5.3 on the same day.</p>



<p><a href=\"https://wordpress.org/plugins/bbpress/\">bbPress</a> is an official WordPress project for powering forums.  It was <a href=\"https://bbpress.org/blog/2004/12/soft-launch/\">initially launched</a> on December 28, 2004, by Matt Mullenweg as a standalone project.  During the first iteration&rsquo;s heyday, it was popular within the WordPress community as a simple forum solution.  In 2011, <a href=\"https://bbpress.org/blog/2011/09/bbpress-2-0-now-available/\">bbPress 2.0 relaunched</a> as a WordPress plugin with Jacoby as the lead developer.</p>



<p>The bbPress team is primarily comprised of four part-time contributors with nearly no volunteers available for user testing.  Stephen Edgar, Brandon Allen, and Sergey Biryukov were the primary developers other than Jacoby behind version 2.6.</p>



<p>&ldquo;Jennifer M. Dodd deserves a mention for her contributions to 2.6 early on; she&rsquo;s largely moved on but is wonderful,&rdquo; said Jacoby.  &ldquo;Behind the scenes in the meta and forums teams are Samuel &lsquo;Otto&rsquo; Wood, Dion Hulse, Mika Epstein, Marius Jensen, and countless others who provide feedback and feature requests upstream based on how WordPress.org uses bbPress.&rdquo;</p>



<p>Contributors resolved 420 open tickets with 1,737 code commits over the multi-year span it took for version 2.6 to drop.  The new version ships with hundreds of bug fixes and improvements.  Its features include per-forum moderation, new platforms to import forum content from, and an Engagements API.</p>



<p>The new Engagements API connects user IDs to the various types of content in bbPress, such as forums, topics, replies, and topic tags.  This works as a sort of relationship system between users and any content they interact with on the forums.  In previous versions of bbPress, all of this data was saved in the user metadata table.</p>



<p>Per-forum moderation is a key feature for forums, but it has been one of the missing elements in bbPress.  The new feature takes advantage of the Engagements API to connect user IDs to forum IDs.  In turn, this allows site owners to create moderators for individual forums.  This feature works in contrast to the existing &ldquo;moderator&rdquo; role in bbPress, which provides users global moderation powers.</p>



<h2>Why the 6-Year Wait?</h2>



<p>You could be forgiven for wondering if bbPress was all but dead.  The last minor release happened in 2017 when the team dropped version 2.5.14.  The same year, bbPress 2.6 was <a href=\"https://wptavern.com/bbpress-2-6-beta-3-likely-as-team-focuses-on-solid-data-migration-path\">headed toward a third beta</a> and even had a <a href=\"https://bbpress.org/forums/topic/bbpress-2-6-beta/\">few release candidates</a>.</p>



<p>&ldquo;There was not very much feedback on the 2.6 beta or RC, and I had just transitioned into my role at Sandhills Development,&rdquo; said Jacoby. &ldquo;I decided it was better to concentrate on doing a good job where I could make a direct impact on people&rsquo;s lives, rather than have no idea if I was doing a good job at all with bbPress.&rdquo;</p>



<p>Jacoby did not want to release a potentially buggy version 2.6 and take on the support burden at the time.  Doing so would have interfered with his responsibilities at his new job.  &ldquo;Younger me would have tried to do both, and failed at both,&rdquo; said Jacoby.</p>



<p><em>Why such a long wait between releases?</em>  Most likely, it was for the same reason the <a href=\"https://twitter.com/bbPress/status/1194327563407122432\">Twitter announcement</a> got fewer than a couple of dozen likes and even fewer retweets.  There is not much community engagement with the project.  On the flip side, the bbPress team has not been active on social media or the project&rsquo;s official blog in the past two years.  </p>



<p>Despite the lack of community engagement, bbPress is currently installed on over 300,000 sites.  It runs the forums at WordPress.org, WordPress.com, CSS-Tricks, and other large communities.  However, there is not much help sent back to the bbPress project from most places.</p>



<p>&ldquo;On WordPress.org, bbPress is just one piece of a very complex puzzle, and everything is mostly in maintenance mode all the time,&rdquo; said Jacoby.  &ldquo;The forums team focuses on the needs of the forums and the meta team helps maintain the code itself, but WordPress has made it easier and more rewarding to contribute to; so contributors graduate up to WordPress core and rarely look back.&rdquo;</p>



<p>The idea behind switching bbPress 2.x to a WordPress plugin from its standalone roots was that it would be simpler for the larger WordPress community to pitch in.  Jacoby said that contributions have improved since the pre-plugin era, but it has not helped enough.  &ldquo;There&rsquo;s more attention and accolades with WordPress and Gutenberg than there are with the bb&rsquo;s or GlotPress,&rdquo; he said.</p>



<p>One of bbPress&rsquo; biggest problems is the lack of resources.  There is no commercial element to the plugin and no major companies are funding anyone to work on the project full time.</p>



<p>&ldquo;For an open-source project to be sustainable long-term, it needs to have an economy behind it,&rdquo; said Jacoby.  &ldquo;Without an economy, what&rsquo;s the real goal? Market share? Building better forum software? Those are not enough by itself when people need to make a living, and when less work with WooCommerce can help you earn a better living.&rdquo;</p>



<h2>The Future of Forums</h2>



<p>Six years between major releases is a lifetime in technological years, plenty enough time for another company to claim the WordPress forum market share.  However, bbPress managed to keep its crown as the most-used WordPress forum plugin during the wait.  It does beg the question of whether companies or developers see a future for forums.</p>



<p>With so many alternative options for user engagement, are forums a dying breed of software?</p>



<p>&ldquo;If forums are dying, it&rsquo;s a slow death, according to the numbers anyway,&rdquo; said Jacoby.  &ldquo;Chat apps like Slack and Discord (or Twitch and YouTube) are where people do forum-type stuff these days. Moderating your own community takes dedication and work, and if you&rsquo;re going to do work, why not build an audience someplace else instead?&rdquo;</p>



<p>Jacoby has hope for the future, however.  &ldquo;I can imagine a bunch of reasons why forums seem unattractive,&rdquo; he said, &ldquo;but to me they are still what everyone circles back around to, just like having their own blogs!&rdquo;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Nov 2019 20:17:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: WordCamp US 2020 Date and Location Announced, New Weekday Schedule\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95327\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"https://wptavern.com/wordcamp-us-2020-date-and-location-announced-new-weekday-schedule\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3394:\"<p>Mark your calendars, folks.  WordCamp US 2020 will start on a&hellip;<em>Tuesday</em>.</p>



<p>On November 11, the WordCamp US team announced that next year&rsquo;s event will happen during the middle of the week, from October 27 through October 29.  This is a change from the usual three-day weekend event.  The time frame puts the event&rsquo;s days on Tuesday, Wednesday, and Thursday.  The yearly conference will remain in St. Louis, Missouri, in 2020.</p>



<p>Those planning ahead can sign up for updates via the new <a href=\"https://2020.us.wordcamp.org/\">WordCamp US 2020 site</a>.</p>



<p>Thus far, the switch away from a weekend has been met with generally positive <a href=\"https://twitter.com/WordCampUS/status/1193910076244996096\">responses via Twitter</a> and Slack. However, some people fear the schedule will not allow them to attend.  </p>



<p>The WordCamp US Twitter account cited date availability, Halloween, and giving the weekend back to attendees as the reason behind the change.</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Number of reasons from date availability, letting folks get home for Halloween, and letting folks have a their weekend back on an out-of-town event</p>&mdash; WordCamp US (@WordCampUS) <a href=\"https://twitter.com/WordCampUS/status/1193912839725101056?ref_src=twsrc%5Etfw\">November 11, 2019</a></blockquote>
</div>



<p>For professionals in the WordPress space, this move will likely be a welcome change.  They are often able to get extra time off from work, sometimes paid leave, to attend the event.  The company they work for may even be funding their travel.  For them, attending a WordCamp is a part of their work.  </p>



<p>The unfortunate side effect of attending a WordCamp over the weekend is that some attendees usually have to wake up for work on Monday morning after traveling back home on Sunday.  Many are essentially working two weeks straight without any downtime.  This helps pile on the problem of developer burnout.  Rest days, time with friends and family, and getting away from code-related things is a part of a healthy work-life balance.</p>



<p>Moving the event to the middle of the week should allow professionals to better maintain that balance.</p>



<p>On the other hand, some attendees may find it harder to attend during the week.  This is particularly true for WordCamp-goers who do not work with WordPress professionally.  They may not be able to get the time off work.</p>



<p>As a general rule, Americans tend to have little paid leave they can take advantage of throughout the year.  The average worker in the private sector only gets <a href=\"https://www.cnbc.com/2018/07/05/heres-how-many-paid-vacation-days-the-typical-american-worker-gets-.html\">10 paid vacation days</a> per year after one year of employment.  Those numbers rise the longer an employee sticks with a single company.  The US does not guarantee paid leave for workers.</p>



<p>Without support from their employer, some people may have to choose between using their paid time off to attend and keeping those days in reserve for family vacation or holidays.</p>



<p>Unlike local WordCamps, the US conference is more of an industry event that sees professionals from across the US and the world.  The move to a weekday schedule should be a nice change for many.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 13 Nov 2019 21:27:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"WPTavern: WordPress 5.3 “Kirk” Released, Brings New Default Theme, Editor Improvements, and UI Tweaks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95290\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"https://wptavern.com/wordpress-5-3-kirk-released-brings-new-default-theme-editor-improvements-and-ui-tweaks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7770:\"<div class=\"wp-block-image\"><img />Rahsaan Roland Kirk<br />Credit:  <a href=\"https://www.flickr.com/photos/heiner1947/4485444348/in/photostream/\">Heinrich Klaffs</a> CC BY-SA 2.0</div>



<p><a href=\"https://wordpress.org/news/2019/11/kirk/\">WordPress 5.3 &ldquo;Kirk,&rdquo;</a> named in honor American jazz musician Rahsaan Roland Kirk, is now available for download.  The update includes a new default theme named Twenty Twenty, user interface improvements aimed at accessibility, and new block editor features.</p>



<p>This release saw contributions from 645 volunteers, which is the largest contributor group ever for a WordPress release.</p>



<p>The release was led by <a href=\"https://ma.tt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/francina/\">Francesca Marano</a>, and <a href=\"https://profiles.wordpress.org/davidbaumwald\">David Baumwald</a>.  They were joined by the following contributors in supporting roles in getting version 5.3 released.</p>



<ul><li>Editor Tech Lead &ndash; <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a></li><li>Editor Design Lead &ndash; <a href=\"https://profiles.wordpress.org/mapk/\">Mark Uraine</a></li><li>Core Tech Lead &ndash; <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a></li><li>Default Theme Design Lead &ndash; <a href=\"https://profiles.wordpress.org/anlino/\">Anders Nor&eacute;n</a></li><li>Default Theme Wrangler &ndash; <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a></li><li>Docs Coordinator &ndash; <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a></li><li>Accessibility Lead &ndash; <a href=\"https://profiles.wordpress.org/audrasjb/\">JB Audras</a></li><li>Marketing Lead &ndash; <a href=\"https://profiles.wordpress.org/mikerbg/\">Mike Reid</a></li><li>Media Focus Lead &ndash; <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a></li></ul>



<p>WordPress 5.2 had 84 million downloads before WordPress 5.3&rsquo;s release.</p>



<p>The PHP native JSON extension is now required for any site running WordPress 5.3 or later.  This should not be an issue for the majority of users because the extension has been bundled with PHP by default since 2006.  WordPress will output an error and cancel the update procedure if it detects the extension is missing.  Users who are unable to update will need to contact their web hosts to have the extension enabled.</p>



<h2>Twenty Twenty: New Default Theme</h2>



<div class=\"wp-block-image\"><img />Screenshot of the Twenty Twenty WordPress theme.</div>



<p>WordPress is getting a fresh coat of paint.  Anders Nor&eacute;n led the design team for the new <a href=\"https://wptavern.com/twenty-twenty-bundled-in-core-beta-features-overview\">Twenty Twenty</a> theme, which was a <a href=\"https://wptavern.com/first-look-at-twenty-twenty-new-wordpress-default-theme-based-on-chaplain\">fork of his original Chaplin theme</a>.</p>



<p>The Twenty Twenty theme is completely geared toward creating content with the block editor with its bold and opinionated styling.  It comes with a cover page template and has a custom color system designed to keep the site&rsquo;s color contrast accessible.</p>



<h2>Block Editor Features and Improvements</h2>



<div class=\"wp-block-image\"><img />Nesting any block inside the Cover block.</div>



<p>WordPress 5.3 includes features from the versions 5.4 &ndash; 6.5 of the Gutenberg plugin along with bug fixes and performance improvements from versions 6.6 and 6.7.  For users who have not been running the plugin, they should see faster loading times and quicker responses from keystrokes.</p>



<p>WP Tavern has covered every major release of the Gutenberg plugin that will be bundled in WordPress 5.3, except Gutenberg 5.6.  Catch up on any features you missed with the following articles.</p>



<ul><li><a href=\"https://wptavern.com/gutenberg-5-5-adds-new-group-block-for-nesting-child-blocks\">Gutenberg 5.5 Adds New Group Block for Nesting Child Blocks</a></li><li><a href=\"https://wptavern.com/gutenberg-5-7-adds-new-block-appender-for-group-and-columns-blocks\">Gutenberg 5.7 Adds New Block Appender for Group and Columns Blocks</a></li><li><a href=\"https://wptavern.com/gutenberg-5-8-released-with-prototype-of-new-block-based-widgets-screen\">Gutenberg 5.8 Released with Prototype of New Block-based Widgets Screen</a></li><li><a href=\"https://wptavern.com/gutenberg-5-9-brings-major-improvements-to-block-grouping-introduces-snackbar-notices\">Gutenberg 5.9 Brings Major Improvements to Block Grouping, Introduces Snackbar Notices</a></li><li><a href=\"https://wptavern.com/gutenberg-6-0-adds-layout-picker-to-columns-block\">Gutenberg 6.0 Adds Layout Picker to Columns Block </a></li><li><a href=\"https://wptavern.com/gutenberg-6-1-introduces-animation-to-block-moving-actions-adds-block-based-widgets-screen-experiments\">Gutenberg 6.1 Introduces Animation to Block Moving Actions, Adds Block-Based Widgets Screen Experiments</a></li><li><a href=\"https://wptavern.com/gutenberg-6-2-adds-nesting-capabilities-to-cover-media-text-blocks\">Gutenberg 6.2 Adds Nesting Capabilities to Cover, Media &amp; Text Blocks</a></li><li><a href=\"https://wptavern.com/gutenberg-6-3-improves-accessibility-with-new-navigation-and-edit-modes\">Gutenberg 6.3 Improves Accessibility with New Navigation and Edit Modes</a></li><li><a href=\"https://wptavern.com/gutenberg-6-4-adds-new-typewriter-experience-cover-block-resizing-and-block-inserter-help-panel\">Gutenberg 6.4 Adds New Typewriter Experience, Cover Block Resizing, and Block Inserter Help Panel</a></li><li><a href=\"https://wptavern.com/gutenberg-6-5-adds-experimental-block-directory-search-to-inserter-and-new-social-links-block\">Gutenberg 6.5 Adds Experimental Block Directory Search to Inserter and New Social Links Block</a></li></ul>



<h2>Other Core Features</h2>



<p>Work toward <a href=\"https://wptavern.com/wordpress-5-3-improves-large-image-handling\">large image handling</a> went into the update.  Instead of checking file sizes, images larger than 2,560 pixels are scaled down and used as the &ldquo;full&rdquo; image size.  This change makes large images web ready and will significantly decrease file sizes for many users who upload images without optimizing them beforehand.  This is common with mobile phone uploads.  </p>



<p>For those who prefer to maintain the original sizes of image uploads, which is sometimes the case with photography sites, grab the <a href=\"https://wordpress.org/plugins/disable-big-image-threshold/\">Disable &ldquo;BIG Image&rdquo; Threshold</a> plugin.</p>



<p>The site health screen introduced in WordPress 5.2 has some user experience improvements, such as tweaking how the grading indicator works for clarity.  WordPress site owners will also need to <a href=\"https://wptavern.com/wordpress-5-3-to-introduce-new-admin-email-verification-screen\">verify their admin email</a> every six months.  This feature is to help make sure site recovery emails are being sent to the right place when an error occurs.  It also lays the groundwork for future features that may build upon it.</p>



<h2>Developer Changes</h2>



<p>Developers should read the full <a href=\"https://make.wordpress.org/core/2019/10/17/wordpress-5-3-field-guide/\">WordPress 5.3 field guide</a> to make sure none of the changes affect their plugins or themes. Some of the changes include the following.</p>



<ul><li>Full support for PHP 7.4.</li><li>Improved date/time handling.</li><li>Robots meta tag now used for discouraging search engines from listing a site.</li><li>New meta key comparison operators added.</li><li>Integers are no longer allowed for nav menu slugs.</li><li><code>wp_die()</code> now allows custom HTML.</li></ul>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Nov 2019 22:12:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"WordPress.org blog: WordPress 5.3 “Kirk”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7684\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"https://wordpress.org/news/2019/11/kirk/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:60274:\"<div class=\"wp-block-image\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/11/5.3-album-cover.png?resize=632%2C632&ssl=1\" alt=\"Album cover for WordPress 5.3 Kirk, showcasing a duotone red/cream Rahsaan Roland Kirk playing the saxophone on a red background.\" class=\"wp-image-7710\" /></div>



<p class=\"has-text-color has-background\">Introducing our most refined user experience with the improved block editor in WordPress 5.3! Named “Kirk” in honour of jazz multi-instrumentalist Rahsaan Roland Kirk, the latest and greatest version of WordPress is available for <a href=\"https://wordpress.org/download/\">download</a> or update in your dashboard.</p>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/11/divider.png?resize=632%2C159&ssl=1\" alt=\"\" class=\"wp-image-7721\" />



<p><strong>5.3 expands and refines the block editor</strong> with more intuitive <strong>interactions</strong> and improved <strong>accessibility</strong>. New features in the editor increase design freedoms, provide additional layout options and style variations to allow designers more control over the look of a site.</p>



<p>This release also introduces the <strong>Twenty Twenty theme</strong> giving the user more design flexibility and integration with the block editor. Creating beautiful web pages and advanced layouts has never been easier.</p>



<hr class=\"wp-block-separator\" />



<h2>Block Editor Improvements</h2>







<p>This enhancement-focused update introduces over 150 new features and usability improvements, including improved large image support for uploading non-optimized, high-resolution pictures taken from your smartphone or other high-quality cameras. Combined with larger default image sizes, pictures always look their best.</p>



<p>Accessibility improvements include the integration of block editor styles in the admin interface. These improved styles fix many accessibility issues: color contrast on form fields and buttons, consistency between editor and admin interfaces, new snackbar notices, standardizing to the default WordPress color scheme, and the introduction of Motion to make interacting with your blocks feel swift and natural. </p>



<p>For people who use a keyboard to navigate the dashboard, the block editor now has a Navigation mode. This lets you jump from block to block without tabbing through every part of the block controls.</p>



<hr class=\"wp-block-separator\" />



<h2>Expanded Design Flexibility</h2>







<p>WordPress 5.3 adds even more robust tools for creating amazing designs.</p>



<ul><li>The new Group block lets you easily divide your page into colorful sections.</li><li>The Columns block now supports fixed column widths.</li><li>The new predefined layouts make it a cinch to arrange content into advanced designs.</li><li>Heading blocks now offer controls for text and background color.</li><li>Additional style options allow you to set your preferred style for any block that supports this feature.</li></ul>



<hr class=\"wp-block-separator\" />



<h2>Introducing Twenty Twenty</h2>



<div class=\"wp-block-image\"><img src=\"https://i0.wp.com/wordpress.org/news/files/2019/11/twentytwenty-desktop.png?resize=632%2C626&ssl=1\" alt=\"A desktop preview of the Twenty Twenty theme, showing both the front-end and the editor view.\" class=\"wp-image-7686\" /></div>



<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-top\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/11/twentytwenty-mobile.png?w=632&ssl=1\" alt=\"A mobile image of the Twenty Twenty  theme, over a decorative backgorund of brown-grey bars.\" class=\"wp-image-7714\" /><div class=\"wp-block-media-text__content\">
<p>As the block editor celebrates its first birthday, we are proud that Twenty Twenty is designed with flexibility at its core. Show off your services or products with a combination of columns, groups, and media blocks. Set your content to wide or full alignment for dynamic and engaging layouts. Or let your thoughts be the star with a centered content column!</p>



<p class=\"has-normal-font-size\">As befits a theme called Twenty Twenty, clarity and readability is also a big focus. The theme includes the typeface&nbsp;<a href=\"https://rsms.me/inter/\">Inter</a>, designed by Rasmus Andersson. Inter comes in a Variable Font version, a first for default themes, which keeps load times short by containing all weights and styles of Inter in just two font files.</p>
</div></div>



<hr class=\"wp-block-separator\" />



<h2>Improvements for Everyone</h2>



<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/11/Rotate.png?w=632&ssl=1\" alt=\"An icon showing an arrow rotating a square.\" class=\"wp-image-7731\" /><div class=\"wp-block-media-text__content\">
<h3>Automatic Image Rotation</h3>



<p>Your images will be correctly rotated upon upload according to the embedded orientation data. This feature was first proposed nine years ago and made possible through the perseverance of many dedicated contributors.</p>
</div></div>



<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><img src=\"https://i2.wp.com/wordpress.org/news/files/2019/11/Health.png?w=632&ssl=1\" alt=\"A plus in a square, indicating health.\" class=\"wp-image-7732\" /><div class=\"wp-block-media-text__content\">
<h3>Improved Site Health Checks</h3>



<p>The improvements introduced in 5.3 make it even easier to identify issues. Expanded recommendations highlight areas that may need troubleshooting on your site from the Health Check screen.</p>
</div></div>



<div class=\"wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile\"><img src=\"https://i1.wp.com/wordpress.org/news/files/2019/11/Email.png?w=632&ssl=1\" alt=\"A email icon.\" class=\"wp-image-7733\" /><div class=\"wp-block-media-text__content\">
<h3>Admin Email Verification</h3>



<p>You’ll now be periodically asked to confirm that your admin email address is up to date when you log in as an administrator. This reduces the chance of getting locked out of your site if you change your email address.</p>
</div></div>



<hr class=\"wp-block-separator\" />



<h2>For Developers</h2>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<h3>Date/Time Component Fixes</h3>



<p>Developers can now work with&nbsp;<a href=\"https://make.wordpress.org/core/2019/09/23/date-time-improvements-wp-5-3/\">dates and timezones</a>&nbsp;in a more reliable way. Date and time functionality has received a number of new API functions for unified timezone retrieval and PHP interoperability, as well as many bug fixes.</p>
</div>



<div class=\"wp-block-column\">
<h3>PHP 7.4 Compatibility</h3>



<p>WordPress 5.3 aims to fully support PHP 7.4. This release contains&nbsp;<a href=\"https://make.wordpress.org/core/2019/10/11/wordpress-and-php-7-4/\">multiple changes</a>&nbsp;to remove deprecated functionality and ensure compatibility. WordPress continues to encourage all users to run the latest and greatest versions of PHP.</p>
</div>
</div>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/11/divider.png?resize=632%2C159&ssl=1\" alt=\"\" class=\"wp-image-7721\" />



<h2>The Squad</h2>



<p>This release was led by&nbsp;<a href=\"http://ma.tt/\">Matt Mullenweg</a>,&nbsp;<a href=\"https://profiles.wordpress.org/francina\">Francesca Marano</a>, and <a href=\"https://dream-encode.com/blog/\">David Baumwald</a>. They were enthusiastically supported by a large release squad:</p>



<ul><li><strong>Editor Tech</strong>: Riad Benguella (<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://profiles.wordpress.org/youknowriad/\"><strong>@youknowriad</strong></a>)</li><li><strong>Editor Design</strong>: Mark Uraine (<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://profiles.wordpress.org/mapk/\"><strong>@mapk</strong></a>)</li><li><strong>Core Tech</strong>: Andrew Ozz (<a rel=\"noreferrer noopener\" target=\"_blank\" href=\"https://profiles.wordpress.org/azaozz/\"><strong>@azaozz</strong></a>)</li><li><strong>Docs Coordinator</strong>:&nbsp;Justin Ahinon (<a href=\"https://profiles.wordpress.org/justinahinon/\"><strong>@justinahinon</strong></a>)</li><li><strong>Marketing/Release Comms</strong>:&nbsp;Mike Reid (<a href=\"https://profiles.wordpress.org/mikerbg/\"><strong>@mikerbg</strong></a>)</li><li><strong>Media/Uploader</strong>:&nbsp;Mike Schroder (<a href=\"https://profiles.wordpress.org/mikeschroder/\"><strong>@mikeschroder</strong></a>)</li><li><strong>Accessibility</strong>:&nbsp;JB Audras (<a href=\"https://profiles.wordpress.org/audrasjb/\"><strong>@audrasjb</strong></a>)</li><li><strong>Default Theme</strong> <strong>Wrangler</strong>: Ian Belanger (<a href=\"https://profiles.wordpress.org/ianbelanger/\"><strong>@ianbelanger</strong></a>)</li><li><strong>Default Theme Designer</strong>: Anders Norén (<a href=\"https://profiles.wordpress.org/anlino/\"><strong>@anlino</strong></a>)</li></ul>



<p>The squad was joined throughout the twelve week release cycle by 645 generous volunteer contributors (our largest group of contributors to date) who collectively fixed 658 bugs.</p>



<p>Put on a Rahsaan Roland Kirk playlist, click that update button (or <a href=\"https://wordpress.org/download/\">download it directly</a>), and check the profiles of the fine folks that helped:</p>


<a href=\"https://profiles.wordpress.org/123host/\">123host</a>, <a href=\"https://profiles.wordpress.org/1994rstefan/\">1994rstefan</a>, <a href=\"https://profiles.wordpress.org/5hel2l2y/\">5hel2l2y</a>, <a href=\"https://profiles.wordpress.org/irsdl/\">@irsdl</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell/\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin/\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/aksdvp/\">Aashish S</a>, <a href=\"https://profiles.wordpress.org/abhijitrakas/\">Abhijit Rakas</a>, <a href=\"https://profiles.wordpress.org/abrightclearweb/\">abrightclearweb</a>, <a href=\"https://profiles.wordpress.org/acalfieri/\">acalfieri</a>, <a href=\"https://profiles.wordpress.org/acosmin/\">acosmin</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein/\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/adamsoucie/\">Adam Soucie</a>, <a href=\"https://profiles.wordpress.org/adhitya03/\">Adhitya Rachman</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais/\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/ajayghaghretiya1/\">Ajay Ghaghretiya</a>, <a href=\"https://profiles.wordpress.org/ajitbohra/\">Ajit Bohra</a>, <a href=\"https://profiles.wordpress.org/atachibana/\">Akira Tachibana</a>, <a href=\"https://profiles.wordpress.org/aljullu/\">Albert Juh&#233; Lluveras</a>, <a href=\"https://profiles.wordpress.org/albertomake/\">albertomake</a>, <a href=\"https://profiles.wordpress.org/xknown/\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/xavortm/\">Alex Dimitrov</a>, <a href=\"https://profiles.wordpress.org/ajlende/\">Alex Lende</a>, <a href=\"https://profiles.wordpress.org/alexclassroom/\">Alex Lion</a>, <a href=\"https://profiles.wordpress.org/viper007bond/\">Alex Mills</a>, <a href=\"https://profiles.wordpress.org/alexsanford1/\">Alex Sanford</a>, <a href=\"https://profiles.wordpress.org/xyfi/\">Alexander Botteram</a>, <a href=\"https://profiles.wordpress.org/xel1045/\">Alexandre D\'Eschambeault</a>, <a href=\"https://profiles.wordpress.org/alexvorn2/\">Alexandru Vornicescu</a>, <a href=\"https://profiles.wordpress.org/alexeyskr/\">alexeyskr</a>, <a href=\"https://profiles.wordpress.org/alextran/\">alextran</a>, <a href=\"https://profiles.wordpress.org/ayubi/\">Ali Ayubi</a>, <a href=\"https://profiles.wordpress.org/allancole/\">allancole</a>, <a href=\"https://profiles.wordpress.org/allendav/\">Allen Snook</a>, <a href=\"https://profiles.wordpress.org/alvarogois/\">Alvaro Gois dos Santos</a>, <a href=\"https://profiles.wordpress.org/arush/\">Amanda Rush</a>, <a href=\"https://profiles.wordpress.org/amolv/\">Amol Vhankalas</a>, <a href=\"https://profiles.wordpress.org/anantajitjg/\">Anantajit JG</a>, <a href=\"https://profiles.wordpress.org/anlino/\">Anders Norén</a>, <a href=\"https://profiles.wordpress.org/afercia/\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/andg/\">Andrea Gandino</a>, <a href=\"https://profiles.wordpress.org/agengineering/\">Andrea Grillo</a>, <a href=\"https://profiles.wordpress.org/andreamiddleton/\">Andrea Middleton</a>, <a href=\"https://profiles.wordpress.org/abrain/\">Andreas Brain</a>, <a href=\"https://profiles.wordpress.org/andraganescu/\">Andrei Draganescu</a>, <a href=\"https://profiles.wordpress.org/aduth/\">Andrew Duthie</a>, <a href=\"https://profiles.wordpress.org/nacin/\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/anevins/\">Andrew Nevins</a>, <a href=\"https://profiles.wordpress.org/azaozz/\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/andrewtaylor-1/\">Andrew Taylor</a>, <a href=\"https://profiles.wordpress.org/rarst/\">Andrey Savchenko</a>, <a href=\"https://profiles.wordpress.org/nosolosw/\">Andrés Maneiro</a>, <a href=\"https://profiles.wordpress.org/afragen/\">Andy Fragen</a>, <a href=\"https://profiles.wordpress.org/andizer/\">Andy Meerwaldt</a>, <a href=\"https://profiles.wordpress.org/angelagibson/\">Angela Gibson</a>, <a href=\"https://profiles.wordpress.org/rilwis/\">Anh Tran</a>, <a href=\"https://profiles.wordpress.org/anischarolia/\">anischarolia</a>, <a href=\"https://profiles.wordpress.org/ahdeubzer/\">Anja Deubzer</a>, <a href=\"https://profiles.wordpress.org/antpb/\">Anthony Burchell</a>, <a href=\"https://profiles.wordpress.org/atimmer/\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/apermo/\">Apermo</a>, <a href=\"https://profiles.wordpress.org/arafat/\">Arafat Rahman</a>, <a href=\"https://profiles.wordpress.org/aravindajith/\">Aravind Ajith</a>, <a href=\"https://profiles.wordpress.org/archon810/\">archon810</a>, <a href=\"https://profiles.wordpress.org/arena/\">arena</a>, <a href=\"https://profiles.wordpress.org/aristath/\">Ari Stathopoulos</a>, <a href=\"https://profiles.wordpress.org/arunsathiya/\">Arun Sathiya</a>, <a href=\"https://profiles.wordpress.org/artisticasad/\">Asad Shahbaz</a>, <a href=\"https://profiles.wordpress.org/asadkn/\">asadkn</a>, <a href=\"https://profiles.wordpress.org/mrasharirfan/\">Ashar Irfan</a>, <a href=\"https://profiles.wordpress.org/ashwinpc/\">ashwinpc</a>, <a href=\"https://profiles.wordpress.org/wpboss/\">Aslam Shekh</a>, <a href=\"https://profiles.wordpress.org/ate-up-with-motor/\">Ate Up With Motor</a>, <a href=\"https://profiles.wordpress.org/atlasmahesh/\">atlasmahesh</a>, <a href=\"https://profiles.wordpress.org/au87/\">au87</a>, <a href=\"https://profiles.wordpress.org/aubreypwd/\">Aubrey Portwood</a>, <a href=\"https://profiles.wordpress.org/augustuswm/\">augustuswm</a>, <a href=\"https://profiles.wordpress.org/aurooba/\">Aurooba Ahmed</a>, <a href=\"https://profiles.wordpress.org/avinapatel/\">Avina Patel</a>, <a href=\"https://profiles.wordpress.org/aksl95/\">Axel DUCORON</a>, <a href=\"https://profiles.wordpress.org/ayeshrajans/\">Ayesh Karunaratne</a>, <a href=\"https://profiles.wordpress.org/backermann1978/\">backermann1978</a>, <a href=\"https://profiles.wordpress.org/b-07/\">Bappi</a>, <a href=\"https://profiles.wordpress.org/toszcze/\">Bartosz Romanowski</a>, <a href=\"https://profiles.wordpress.org/pixolin/\">Bego Mario Garde</a>, <a href=\"https://profiles.wordpress.org/bfintal/\">Benjamin Intal</a>, <a href=\"https://profiles.wordpress.org/benjamin_zekavica/\">Benjamin Zekavica</a>, <a href=\"https://profiles.wordpress.org/bennemann/\">bennemann</a>, <a href=\"https://profiles.wordpress.org/bgermann/\">bgermann</a>, <a href=\"https://profiles.wordpress.org/bhaktirajdev/\">Bhaktii Rajdev</a>, <a href=\"https://profiles.wordpress.org/bibliofille/\">bibliofille</a>, <a href=\"https://profiles.wordpress.org/biranit/\">Biranit</a>, <a href=\"https://profiles.wordpress.org/birgire/\">Birgir Erlendsson</a>, <a href=\"https://profiles.wordpress.org/bitcomplex/\">bitcomplex</a>, <a href=\"https://profiles.wordpress.org/bjornw/\">BjornW</a>, <a href=\"https://profiles.wordpress.org/boblinthorst/\">boblinthorst</a>, <a href=\"https://profiles.wordpress.org/boga86/\">Boga86</a>, <a href=\"https://profiles.wordpress.org/boonebgorges/\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/bor0/\">Boro Sitnikovski</a>, <a href=\"https://profiles.wordpress.org/crazyjaco/\">Bradley Jacobs</a>, <a href=\"https://profiles.wordpress.org/bradleyt/\">Bradley Taylor</a>, <a href=\"https://profiles.wordpress.org/kraftbj/\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/brentswisher/\">Brent Swisher</a>, <a href=\"https://profiles.wordpress.org/bronsonquick/\">Bronson Quick</a>, <a href=\"https://profiles.wordpress.org/bsetiawan88/\">bsetiawan88</a>, <a href=\"https://profiles.wordpress.org/burhandodhy/\">Burhan Nasir</a>, <a href=\"https://profiles.wordpress.org/cbravobernal/\">Carlos Bravo</a>, <a href=\"https://profiles.wordpress.org/poena/\">Carolina Nymark</a>, <a href=\"https://profiles.wordpress.org/cdog/\">Catalin Dogaru</a>, <a href=\"https://profiles.wordpress.org/cathibosco1/\">Cathi Bosco</a>, <a href=\"https://profiles.wordpress.org/chandrapatel/\">Chandra Patel</a>, <a href=\"https://profiles.wordpress.org/caercam/\">Charlie Merland</a>, <a href=\"https://profiles.wordpress.org/chetan200891/\">Chetan Prajapati</a>, <a href=\"https://profiles.wordpress.org/ketuchetan/\">Chetan Satasiya</a>, <a href=\"https://profiles.wordpress.org/blogginglife/\">Chico</a>, <a href=\"https://profiles.wordpress.org/chintan1896/\">Chintan hingrajiya</a>, <a href=\"https://profiles.wordpress.org/chrico/\">ChriCo</a>, <a href=\"https://profiles.wordpress.org/aprea/\">Chris Aprea</a>, <a href=\"https://profiles.wordpress.org/chrisvanpatten/\">Chris Van Patten</a>, <a href=\"https://profiles.wordpress.org/christian1012/\">Christian Chung</a>, <a href=\"https://profiles.wordpress.org/needle/\">Christian Wach</a>, <a href=\"https://profiles.wordpress.org/lovememore/\">christianoliff</a>, <a href=\"https://profiles.wordpress.org/christophherr/\">Christoph Herr</a>, <a href=\"https://profiles.wordpress.org/cleancoded/\">cleancoded</a>, <a href=\"https://profiles.wordpress.org/cmagrin/\">cmagrin</a>, <a href=\"https://profiles.wordpress.org/compilenix/\">CompileNix</a>, <a href=\"https://profiles.wordpress.org/salzano/\">Corey Salzano</a>, <a href=\"https://profiles.wordpress.org/courtney0burton/\">courtney0burton</a>, <a href=\"https://profiles.wordpress.org/cristianozanca/\">Cristiano Zanca</a>, <a href=\"https://profiles.wordpress.org/littlebigthing/\">Csaba (LittleBigThings)</a>, <a href=\"https://profiles.wordpress.org/dswebsme/\">D.S. Webster</a>, <a href=\"https://profiles.wordpress.org/xendo/\">Dademaru</a>, <a href=\"https://profiles.wordpress.org/daleharrison/\">daleharrison</a>, <a href=\"https://profiles.wordpress.org/danmicamediacom/\">Dan Foley</a>, <a href=\"https://profiles.wordpress.org/goodevilgenius/\">Dan Jones</a>, <a href=\"https://profiles.wordpress.org/danbuk/\">DanBUK</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber/\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/redsweater/\">Daniel Jalkut (Red Sweater)</a>, <a href=\"https://profiles.wordpress.org/danieltj/\">Daniel James</a>, <a href=\"https://profiles.wordpress.org/diddledan/\">Daniel Llewellyn</a>, <a href=\"https://profiles.wordpress.org/talldanwp/\">Daniel Richards</a>, <a href=\"https://profiles.wordpress.org/mte90/\">Daniele Scasciafratte</a>, <a href=\"https://profiles.wordpress.org/danieliser/\">danieliser</a>, <a href=\"https://profiles.wordpress.org/daniloercoli/\">daniloercoli</a>, <a href=\"https://profiles.wordpress.org/dvankooten/\">Danny van Kooten</a>, <a href=\"https://profiles.wordpress.org/nerrad/\">Darren Ethier</a>, <a href=\"https://profiles.wordpress.org/darthhexx/\">darthhexx</a>, <a href=\"https://profiles.wordpress.org/deapness/\">Dave Parker</a>, <a href=\"https://profiles.wordpress.org/get_dave/\">Dave Smith</a>, <a href=\"https://profiles.wordpress.org/drw158/\">Dave Whitley</a>, <a href=\"https://profiles.wordpress.org/davetgreen/\">davetgreen</a>, <a href=\"https://profiles.wordpress.org/davilera/\">David Aguilera</a>, <a href=\"https://profiles.wordpress.org/davidanderson/\">David Anderson</a>, <a href=\"https://profiles.wordpress.org/david.binda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/davidbinda/\">David Binovec</a>, <a href=\"https://profiles.wordpress.org/daveshine/\">David Decker</a>, <a href=\"https://profiles.wordpress.org/dlh/\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/daviedr/\">David Rozando</a>, <a href=\"https://profiles.wordpress.org/dshanske/\">David Shanske</a>, <a href=\"https://profiles.wordpress.org/daxelrod/\">daxelrod</a>, <a href=\"https://profiles.wordpress.org/dkarfa/\">Debabrata Karfa</a>, <a href=\"https://profiles.wordpress.org/dennis_f/\">Deni</a>, <a href=\"https://profiles.wordpress.org/dehisok/\">Denis Cherniavsky</a>, <a href=\"https://profiles.wordpress.org/denisco/\">Denis Yanchevskiy</a>, <a href=\"https://profiles.wordpress.org/wpdennis/\">Dennis</a>, <a href=\"https://profiles.wordpress.org/dionysous/\">Dennis Hipp</a>, <a href=\"https://profiles.wordpress.org/dmsnell/\">Dennis Snell</a>, <a href=\"https://profiles.wordpress.org/dsifford/\">Derek Sifford</a>, <a href=\"https://profiles.wordpress.org/derweili/\">derweili</a>, <a href=\"https://profiles.wordpress.org/dfangstrom/\">dfangstrom</a>, <a href=\"https://profiles.wordpress.org/dharmin16/\">Dharmin Shah</a>, <a href=\"https://profiles.wordpress.org/dhavalkasvala/\">Dhaval kasavala</a>, <a href=\"https://profiles.wordpress.org/dhuyvetter/\">dhuyvetter</a>, <a href=\"https://profiles.wordpress.org/dianeco/\">Diane Co</a>, <a href=\"https://profiles.wordpress.org/diedeexterkate/\">DiedeExterkate</a>, <a href=\"https://profiles.wordpress.org/diego-la-monica/\">Diego La Monica</a>, <a href=\"https://profiles.wordpress.org/digitalapps/\">digitalapps</a>, <a href=\"https://profiles.wordpress.org/dilipbheda/\">Dilip Bheda</a>, <a href=\"https://profiles.wordpress.org/odminstudios/\">Dima</a>, <a href=\"https://profiles.wordpress.org/dingo_d/\">dingo-d</a>, <a href=\"https://profiles.wordpress.org/dd32/\">Dion hulse</a>, <a href=\"https://profiles.wordpress.org/dency/\">Dixita Dusara</a>, <a href=\"https://profiles.wordpress.org/ocean90/\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/drewapicture/\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/dukex/\">Dukex</a>, <a href=\"https://profiles.wordpress.org/dushanthi/\">dushanthi</a>, <a href=\"https://profiles.wordpress.org/seedsca/\">ecotechie</a>, <a href=\"https://profiles.wordpress.org/ediamin/\">Edi Amin</a>, <a href=\"https://profiles.wordpress.org/etoledom/\">Eduardo Toledo</a>, <a href=\"https://profiles.wordpress.org/ehtis/\">ehtis</a>, <a href=\"https://profiles.wordpress.org/ellatrix/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/iseulde/\">Ella van Durpe</a>, <a href=\"https://profiles.wordpress.org/elliotcondon/\">Elliot Condon</a>, <a href=\"https://profiles.wordpress.org/codex-m/\">Emerson Maningo</a>, <a href=\"https://profiles.wordpress.org/edocev/\">Emil Dotsev</a>, <a href=\"https://profiles.wordpress.org/emiluzelac/\">Emil Uzelac</a>, <a href=\"https://profiles.wordpress.org/epiqueras/\">Enrique Piqueras</a>, <a href=\"https://profiles.wordpress.org/nrqsnchz/\">Enrique S&#225;nchez</a>, <a href=\"https://profiles.wordpress.org/erikkroes/\">erikkroes</a>, <a href=\"https://profiles.wordpress.org/estelaris/\">estelaris</a>, <a href=\"https://profiles.wordpress.org/evalarumbe/\">evalarumbe</a>, <a href=\"https://profiles.wordpress.org/faazshift/\">faazshift</a>, <a href=\"https://profiles.wordpress.org/fabifott/\">Fabian</a>, <a href=\"https://profiles.wordpress.org/fabiankaegy/\">Fabian K&#228;gy</a>, <a href=\"https://profiles.wordpress.org/fblaser/\">fblaser</a>, <a href=\"https://profiles.wordpress.org/felipeelia/\">Felipe Elia</a>, <a href=\"https://profiles.wordpress.org/flixos90/\">Felix Arntz</a>, <a href=\"https://profiles.wordpress.org/fencer04/\">Fencer04</a>, <a href=\"https://profiles.wordpress.org/flaviozavan/\">flaviozavan</a>, <a href=\"https://profiles.wordpress.org/flipkeijzer/\">flipkeijzer</a>, <a href=\"https://profiles.wordpress.org/mista-flo/\">Florian TIAR</a>, <a href=\"https://profiles.wordpress.org/foysalremon/\">Foysal Remon</a>, <a href=\"https://profiles.wordpress.org/galbaras/\">Gal Baras</a>, <a href=\"https://profiles.wordpress.org/garrett-eclipse/\">Garrett Hyder</a>, <a href=\"https://profiles.wordpress.org/voldemortensen/\">Garth Mortensen</a>, <a href=\"https://profiles.wordpress.org/garyj/\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento/\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/guddu1315/\">Gaurang Dabhi</a>, <a href=\"https://profiles.wordpress.org/gchtr/\">gchtr</a>, <a href=\"https://profiles.wordpress.org/soulseekah/\">Gennady Kovshenin</a>, <a href=\"https://profiles.wordpress.org/loyaltymanufaktur/\">Gesundheit Bewegt GmbH</a>, <a href=\"https://profiles.wordpress.org/sachyya-sachet/\">ghoul</a>, <a href=\"https://profiles.wordpress.org/girlieworks/\">girlieworks</a>, <a href=\"https://profiles.wordpress.org/glauberglauber/\">glauberglauber</a>, <a href=\"https://profiles.wordpress.org/hometowntrailers/\">Glenn</a>, <a href=\"https://profiles.wordpress.org/gravityview/\">GravityView</a>, <a href=\"https://profiles.wordpress.org/gregsullivan/\">gregsullivan</a>, <a href=\"https://profiles.wordpress.org/gziolo/\">Grzegorz Ziółkowski</a>, <a href=\"https://profiles.wordpress.org/grzegorzjanoszka/\">Grzegorz.Janoszka</a>, <a href=\"https://profiles.wordpress.org/gwwar/\">gwwar</a>, <a href=\"https://profiles.wordpress.org/hardeepasrani/\">Hardeep Asrani</a>, <a href=\"https://profiles.wordpress.org/thakkarhardik/\">Hardik Thakkar</a>, <a href=\"https://profiles.wordpress.org/hareesh-pillai/\">Hareesh Pillai</a>, <a href=\"https://profiles.wordpress.org/hareesh pillai/\">Hareesh Pillai</a>, <a href=\"https://profiles.wordpress.org/harryfear/\">harryfear</a>, <a href=\"https://profiles.wordpress.org/harshbarach/\">harshbarach</a>, <a href=\"https://profiles.wordpress.org/haszari/\">haszari</a>, <a href=\"https://profiles.wordpress.org/hesyifei/\">He Yifei</a>, <a href=\"https://profiles.wordpress.org/helen/\">Helen Hou-Sandi</a>, <a href=\"https://profiles.wordpress.org/henrywright/\">Henry Wright</a>, <a href=\"https://profiles.wordpress.org/herbmiller/\">herbmiller</a>, <a href=\"https://profiles.wordpress.org/herregroen/\">herregroen</a>, <a href=\"https://profiles.wordpress.org/hirofumi2012/\">hirofumi2012</a>, <a href=\"https://profiles.wordpress.org/hkandulla/\">HKandulla</a>, <a href=\"https://profiles.wordpress.org/howdy_mcgee/\">Howdy_McGee</a>, <a href=\"https://profiles.wordpress.org/hoythan/\">hoythan</a>, <a href=\"https://profiles.wordpress.org/hlashbrooke/\">Hugh Lashbrooke</a>, <a href=\"https://profiles.wordpress.org/ianbelanger/\">Ian Belanger</a>, <a href=\"https://profiles.wordpress.org/iandunn/\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianmjones/\">ianmjones</a>, <a href=\"https://profiles.wordpress.org/zinigor/\">Igor Zinovyev</a>, <a href=\"https://profiles.wordpress.org/gsayed786/\">Imran Sayed</a>, <a href=\"https://profiles.wordpress.org/intimez/\">intimez</a>, <a href=\"https://profiles.wordpress.org/ipstenu/\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/iqbalbary/\">iqbalbary</a>, <a href=\"https://profiles.wordpress.org/ireneyoast/\">Irene Strikkers</a>, <a href=\"https://profiles.wordpress.org/isabel_brison/\">Isabel Brison</a>, <a href=\"https://profiles.wordpress.org/ismailelkorchi/\">Ismail El Korchi</a>, <a href=\"https://profiles.wordpress.org/ispreview/\">ispreview</a>, <a href=\"https://profiles.wordpress.org/jdgrimes/\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jagirbaheshwp/\">jagirbaheshwp</a>, <a href=\"https://profiles.wordpress.org/whyisjake/\">Jake Spurlock</a>, <a href=\"https://profiles.wordpress.org/jalpa1984/\">Jalpa Panchal</a>, <a href=\"https://profiles.wordpress.org/macmanx/\">James Huff</a>, <a href=\"https://profiles.wordpress.org/jameskoster/\">James Koster</a>, <a href=\"https://profiles.wordpress.org/jnylen0/\">James Nylen</a>, <a href=\"https://profiles.wordpress.org/jameslnewell/\">jameslnewell</a>, <a href=\"https://profiles.wordpress.org/janak007/\">janak Kaneriya</a>, <a href=\"https://profiles.wordpress.org/jankimoradiya/\">Janki Moradiya</a>, <a href=\"https://profiles.wordpress.org/janwoostendorp/\">janw.oostendorp</a>, <a href=\"https://profiles.wordpress.org/jared_smith/\">jared_smith</a>, <a href=\"https://profiles.wordpress.org/jarocks/\">jarocks</a>, <a href=\"https://profiles.wordpress.org/jarretc/\">Jarret</a>, <a href=\"https://profiles.wordpress.org/studiotwee/\">Jasper van der Meer</a>, <a href=\"https://profiles.wordpress.org/javeweb/\">jave.web</a>, <a href=\"https://profiles.wordpress.org/javorszky/\">javorszky</a>, <a href=\"https://profiles.wordpress.org/jayswadas/\">Jay Swadas</a>, <a href=\"https://profiles.wordpress.org/iamjaydip/\">Jaydip</a>, <a href=\"https://profiles.wordpress.org/audrasjb/\">Jean-Baptiste Audras</a>, <a href=\"https://profiles.wordpress.org/jfarthing84/\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/jeffpaul/\">Jeff Paul</a>, <a href=\"https://profiles.wordpress.org/jeichorn/\">jeichorn</a>, <a href=\"https://profiles.wordpress.org/jenblogs4u/\">Jen Miller</a>, <a href=\"https://profiles.wordpress.org/jenkoian/\">jenkoian</a>, <a href=\"https://profiles.wordpress.org/jeremyclarke/\">Jer Clarke</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt/\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/engelen/\">Jesper van Engelen</a>, <a href=\"https://profiles.wordpress.org/luminuu/\">Jessica Lyschik</a>, <a href=\"https://profiles.wordpress.org/jffng/\">jffng</a>, <a href=\"https://profiles.wordpress.org/jikamens/\">jikamens</a>, <a href=\"https://profiles.wordpress.org/jipmoors/\">Jip Moors</a>, <a href=\"https://profiles.wordpress.org/jitendrabanjara1991/\">jitendrabanjara1991</a>, <a href=\"https://profiles.wordpress.org/jkitchen/\">jkitchen</a>, <a href=\"https://profiles.wordpress.org/jmmathc/\">jmmathc</a>, <a href=\"https://profiles.wordpress.org/joakimsilfverberg/\">joakimsilfverberg</a>, <a href=\"https://profiles.wordpress.org/jobthomas/\">Job</a>, <a href=\"https://profiles.wordpress.org/jodamo5/\">jodamo5</a>, <a href=\"https://profiles.wordpress.org/joedolson/\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joehoyle/\">Joe Hoyle</a>, <a href=\"https://profiles.wordpress.org/joemcgill/\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/joen/\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion/\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby/\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/johnregan3/\">John Regan</a>, <a href=\"https://profiles.wordpress.org/jojotjebaby/\">jojotjebaby</a>, <a href=\"https://profiles.wordpress.org/jrchamp/\">Jonathan Champ</a>, <a href=\"https://profiles.wordpress.org/jond/\">Jonathan Davis</a>, <a href=\"https://profiles.wordpress.org/desrosj/\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/jg-visual/\">Jonathan Goldford</a>, <a href=\"https://profiles.wordpress.org/spacedmonkey/\">Jonny Harris</a>, <a href=\"https://profiles.wordpress.org/jonoaldersonwp/\">Jono Alderson</a>, <a href=\"https://profiles.wordpress.org/joostdevalk/\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/koke/\">Jorge Bernal</a>, <a href=\"https://profiles.wordpress.org/jorgefilipecosta/\">Jorge Costa</a>, <a href=\"https://profiles.wordpress.org/josephscott/\">Joseph Scott</a>, <a href=\"https://profiles.wordpress.org/chanthaboune/\">Josepha Haden</a>, <a href=\"https://profiles.wordpress.org/shelob9/\">Josh Pollock</a>, <a href=\"https://profiles.wordpress.org/joshuanoyce/\">Joshua Noyce</a>, <a href=\"https://profiles.wordpress.org/joshuawold/\">JoshuaWold</a>, <a href=\"https://profiles.wordpress.org/joyously/\">Joy</a>, <a href=\"https://profiles.wordpress.org/jsnajdr/\">jsnajdr</a>, <a href=\"https://profiles.wordpress.org/juanfra/\">Juanfra Aldasoro</a>, <a href=\"https://profiles.wordpress.org/juiiee8487/\">Juhi Patel</a>, <a href=\"https://profiles.wordpress.org/jrf/\">Juliette Reinders Folmer</a>, <a href=\"https://profiles.wordpress.org/juliobox/\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/junktrunk/\">junktrunk</a>, <a href=\"https://profiles.wordpress.org/justdaiv/\">justdaiv</a>, <a href=\"https://profiles.wordpress.org/justinahinon/\">Justin Ahinon</a>, <a href=\"https://profiles.wordpress.org/greenshady/\">Justin Tadlock</a>, <a href=\"https://profiles.wordpress.org/kadamwhite/\">K. Adam White</a>, <a href=\"https://profiles.wordpress.org/kafleg/\">kafleg</a>, <a href=\"https://profiles.wordpress.org/trepmal/\">Kailey (trepmal)</a>, <a href=\"https://profiles.wordpress.org/kakshak/\">Kakshak Kalaria</a>, <a href=\"https://profiles.wordpress.org/kamrankhorsandi/\">Kamran Khorsandi</a>, <a href=\"https://profiles.wordpress.org/leprincenoir/\">Kantari Samy</a>, <a href=\"https://profiles.wordpress.org/karlgroves/\">karlgroves</a>, <a href=\"https://profiles.wordpress.org/katielgc/\">katielgc</a>, <a href=\"https://profiles.wordpress.org/kbrownkd/\">kbrownkd</a>, <a href=\"https://profiles.wordpress.org/ryelle/\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kellychoffman/\">Kelly Hoffman</a>, <a href=\"https://profiles.wordpress.org/kerfred/\">Kerfred</a>, <a href=\"https://profiles.wordpress.org/kingkero/\">kero</a>, <a href=\"https://profiles.wordpress.org/ketanumretiya030/\">Ketan Umretiya</a>, <a href=\"https://profiles.wordpress.org/kevinkovadia/\">kevIN kovaDIA</a>, <a href=\"https://profiles.wordpress.org/kharisblank/\">Kharis Sulistiyono</a>, <a href=\"https://profiles.wordpress.org/killerbishop/\">killerbishop</a>, <a href=\"https://profiles.wordpress.org/killua99/\">killua99</a>, <a href=\"https://profiles.wordpress.org/ixkaito/\">Kite</a>, <a href=\"https://profiles.wordpress.org/kjellr/\">Kjell Reigstad</a>, <a href=\"https://profiles.wordpress.org/knutsp/\">Knut Sparhell</a>, <a href=\"https://profiles.wordpress.org/kokers/\">kokers</a>, <a href=\"https://profiles.wordpress.org/obenland/\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/xkon/\">Konstantinos Xenos</a>, <a href=\"https://profiles.wordpress.org/kuus/\">kuus</a>, <a href=\"https://profiles.wordpress.org/kyliesabra/\">kyliesabra</a>, <a href=\"https://profiles.wordpress.org/laurelfulford/\">laurelfulford</a>, <a href=\"https://profiles.wordpress.org/lbenicio/\">lbenicio</a>, <a href=\"https://profiles.wordpress.org/leogermani/\">leogermani</a>, <a href=\"https://profiles.wordpress.org/leonblade/\">leonblade</a>, <a href=\"https://profiles.wordpress.org/lessbloat/\">lessbloat</a>, <a href=\"https://profiles.wordpress.org/lisota/\">lisota</a>, <a href=\"https://profiles.wordpress.org/lllor/\">lllor</a>, <a href=\"https://profiles.wordpress.org/lordlod/\">lordlod</a>, <a href=\"https://profiles.wordpress.org/loreleiaurora/\">LoreleiAurora</a>, <a href=\"https://profiles.wordpress.org/luan-ramos/\">Luan Ramos</a>, <a href=\"https://profiles.wordpress.org/luciano-croce/\">luciano-croce</a>, <a href=\"https://profiles.wordpress.org/luigipulcini/\">luigipulcini</a>, <a href=\"https://profiles.wordpress.org/luisherranz/\">luisherranz</a>, <a href=\"https://profiles.wordpress.org/lukaswaudentio/\">lukaswaudentio</a>, <a href=\"https://profiles.wordpress.org/wpfed/\">Luke</a>, <a href=\"https://profiles.wordpress.org/lukecarbis/\">Luke Carbis</a>, <a href=\"https://profiles.wordpress.org/lukecavanagh/\">Luke Cavanagh</a>, <a href=\"https://profiles.wordpress.org/m1tk00/\">m1tk00</a>, <a href=\"https://profiles.wordpress.org/maartenleenders/\">maartenleenders</a>, <a href=\"https://profiles.wordpress.org/palmiak/\">Maciej Palmowski</a>, <a href=\"https://profiles.wordpress.org/maciejmackowiak/\">maciejmackowiak</a>, <a href=\"https://profiles.wordpress.org/mahesh901122/\">Mahesh Waghmare</a>, <a href=\"https://profiles.wordpress.org/majemedia/\">Maje Media LLC</a>, <a href=\"https://profiles.wordpress.org/malthert/\">malthert</a>, <a href=\"https://profiles.wordpress.org/manooweb/\">manooweb</a>, <a href=\"https://profiles.wordpress.org/manuelaugustin/\">Manuel Augustin</a>, <a href=\"https://profiles.wordpress.org/manzoorwanijk/\">Manzoor Wani</a>, <a href=\"https://profiles.wordpress.org/marcelo2605/\">marcelo2605</a>, <a href=\"https://profiles.wordpress.org/marcguay/\">MarcGuay</a>, <a href=\"https://profiles.wordpress.org/iworks/\">Marcin Pietrzak</a>, <a href=\"https://profiles.wordpress.org/marcomartins/\">Marco Martins</a>, <a href=\"https://profiles.wordpress.org/marcosalexandre/\">MarcosAlexandre</a>, <a href=\"https://profiles.wordpress.org/mkaz/\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/marekhrabe/\">Marek Hrabe</a>, <a href=\"https://profiles.wordpress.org/chaton666/\">Marie Comet</a>, <a href=\"https://profiles.wordpress.org/maguiar/\">Mario Aguiar</a>, <a href=\"https://profiles.wordpress.org/nofearinc/\">Mario Peshev</a>, <a href=\"https://profiles.wordpress.org/clorith/\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/mdwolinski/\">Mark D Wolinski</a>, <a href=\"https://profiles.wordpress.org/markjaquith/\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/mapk/\">Mark Uraine</a>, <a href=\"https://profiles.wordpress.org/markoheijnen/\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/mspatovaliyski/\">Martin Spatovaliyski</a>, <a href=\"https://profiles.wordpress.org/splitti/\">Martin Splitt</a>, <a href=\"https://profiles.wordpress.org/m-e-h/\">Marty Helmick</a>, <a href=\"https://profiles.wordpress.org/marybaum/\">Mary Baum</a>, <a href=\"https://profiles.wordpress.org/masummdar/\">masummdar</a>, <a href=\"https://profiles.wordpress.org/matstars/\">Mat Gargano</a>, <a href=\"https://profiles.wordpress.org/mat-lipe/\">Mat Lipe</a>, <a href=\"https://profiles.wordpress.org/iceable/\">Mathieu Sarrasin</a>, <a href=\"https://profiles.wordpress.org/imath/\">Mathieu Viet</a>, <a href=\"https://profiles.wordpress.org/mattchowning/\">Matt Chowning</a>, <a href=\"https://profiles.wordpress.org/mboynes/\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheu/\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/matthiasthiel/\">matthias.thiel</a>, <a href=\"https://profiles.wordpress.org/mattyrob/\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/matveb/\">Matías Ventura</a>, <a href=\"https://profiles.wordpress.org/maximeculea/\">Maxime Culea</a>, <a href=\"https://profiles.wordpress.org/maximejobin/\">Maxime Jobin</a>, <a href=\"https://profiles.wordpress.org/maxme/\">maxme</a>, <a href=\"https://profiles.wordpress.org/mayanksonawat/\">mayanksonawat</a>, <a href=\"https://profiles.wordpress.org/mchavezi/\">mchavezi</a>, <a href=\"https://profiles.wordpress.org/immeet94/\">Meet Makadia</a>, <a href=\"https://profiles.wordpress.org/mehidi258/\">Mehidi Hassan</a>, <a href=\"https://profiles.wordpress.org/mehulkaklotar/\">Mehul Kaklotar</a>, <a href=\"https://profiles.wordpress.org/melchoyce/\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/melinedo/\">Melin Edomwonyi</a>, <a href=\"https://profiles.wordpress.org/meloniq/\">meloniq</a>, <a href=\"https://profiles.wordpress.org/michael-arestad/\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/mbabker/\">Michael Babker</a>, <a href=\"https://profiles.wordpress.org/mnelson4/\">Michael Nelson</a>, <a href=\"https://profiles.wordpress.org/donmhico/\">Michael Panaga</a>, <a href=\"https://profiles.wordpress.org/michelweimerskirch/\">michel.weimerskirch</a>, <a href=\"https://profiles.wordpress.org/michielatyoast/\">Michiel Heijmans</a>, <a href=\"https://profiles.wordpress.org/miette49/\">miette49</a>, <a href=\"https://profiles.wordpress.org/mcsf/\">Miguel Fonseca</a>, <a href=\"https://profiles.wordpress.org/miguelvieira/\">miguelvieira</a>, <a href=\"https://profiles.wordpress.org/mihaiiceyro/\">mihaiiceyro</a>, <a href=\"https://profiles.wordpress.org/mihdan/\">mihdan</a>, <a href=\"https://profiles.wordpress.org/miinasikk/\">Miina Sikk</a>, <a href=\"https://profiles.wordpress.org/simison/\">Mikael Korpela</a>, <a href=\"https://profiles.wordpress.org/mauteri/\">Mike Auteri</a>, <a href=\"https://profiles.wordpress.org/mdgl/\">Mike Glendinning</a>, <a href=\"https://profiles.wordpress.org/mikehansenme/\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/mikejolley/\">Mike Jolley</a>, <a href=\"https://profiles.wordpress.org/mikerbg/\">Mike Reid</a>, <a href=\"https://profiles.wordpress.org/mikeschroder/\">Mike Schroder</a>, <a href=\"https://profiles.wordpress.org/mikengarrett/\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/msaari/\">Mikko Saari</a>, <a href=\"https://profiles.wordpress.org/dimadin/\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/gdragon/\">Milan Petrovic</a>, <a href=\"https://profiles.wordpress.org/mobeen-abdullah/\">Mobeen Abdullah</a>, <a href=\"https://profiles.wordpress.org/mohsinrasool/\">Mohsin Rasool</a>, <a href=\"https://profiles.wordpress.org/monikarao/\">Monika Rao</a>, <a href=\"https://profiles.wordpress.org/boemedia/\">Monique Dubbelman</a>, <a href=\"https://profiles.wordpress.org/gwendydd/\">Morgan Kay</a>, <a href=\"https://profiles.wordpress.org/mor10/\">Morten Rand-Hendriksen</a>, <a href=\"https://profiles.wordpress.org/man4toman/\">Morteza Geransayeh</a>, <a href=\"https://profiles.wordpress.org/mt8biz/\">moto hachi ( mt8.biz )</a>, <a href=\"https://profiles.wordpress.org/mppfeiffer/\">mppfeiffer</a>, <a href=\"https://profiles.wordpress.org/mrmadhat/\">mrmadhat</a>, <a href=\"https://profiles.wordpress.org/msaggiorato/\">msaggiorato</a>, <a href=\"https://profiles.wordpress.org/mtias/\">mtias</a>, <a href=\"https://profiles.wordpress.org/phpdocs/\">Muhammad Afzal</a>, <a href=\"https://profiles.wordpress.org/mukesh27/\">Mukesh Panchal</a>, <a href=\"https://profiles.wordpress.org/munyagu/\">munyagu</a>, <a href=\"https://profiles.wordpress.org/mzorz/\">mzorz</a>, <a href=\"https://profiles.wordpress.org/nadir/\">nadir</a>, <a href=\"https://profiles.wordpress.org/nfmohit/\">Nahid Ferdous Mohit</a>, <a href=\"https://profiles.wordpress.org/naveenkharwar/\">Naveen Kharwar</a>, <a href=\"https://profiles.wordpress.org/nayana123/\">Nayana Maradia</a>, <a href=\"https://profiles.wordpress.org/greatislander/\">Ned Zimmerman</a>, <a href=\"https://profiles.wordpress.org/neelpatel7295/\">Neel Patel</a>, <a href=\"https://profiles.wordpress.org/nextendweb/\">Nextendweb</a>, <a href=\"https://profiles.wordpress.org/nextscripts/\">NextScripts</a>, <a href=\"https://profiles.wordpress.org/niallkennedy/\">Niall Kennedy</a>, <a href=\"https://profiles.wordpress.org/nickdaugherty/\">Nick Daugherty</a>, <a href=\"https://profiles.wordpress.org/celloexpressions/\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/nickylimjj/\">Nicky Lim</a>, <a href=\"https://profiles.wordpress.org/nicolad/\">nicolad</a>, <a href=\"https://profiles.wordpress.org/rahe/\">Nicolas Juen</a>, <a href=\"https://profiles.wordpress.org/nielsdeblaauw/\">Niels de Blaauw</a>, <a href=\"https://profiles.wordpress.org/nielslange/\">Niels Lange</a>, <a href=\"https://profiles.wordpress.org/nikschavan/\">Nikhil Chavan</a>, <a href=\"https://profiles.wordpress.org/nikolastoqnow/\">nikolastoqnow</a>, <a href=\"https://profiles.wordpress.org/niq1982/\">Niku Hietanen</a>, <a href=\"https://profiles.wordpress.org/rabmalin/\">Nilambar Sharma</a>, <a href=\"https://profiles.wordpress.org/nishitlangaliya/\">Nishit Langaliya</a>, <a href=\"https://profiles.wordpress.org/kailanitish90/\">Nitish Kaila</a>, <a href=\"https://profiles.wordpress.org/nmenescardi/\">nmenescardi</a>, <a href=\"https://profiles.wordpress.org/noahtallen/\">noahtallen</a>, <a href=\"https://profiles.wordpress.org/notnownikki/\">notnownikki</a>, <a href=\"https://profiles.wordpress.org/noyle/\">noyle</a>, <a href=\"https://profiles.wordpress.org/hideokamoto/\">Okamoto Hidetaka</a>, <a href=\"https://profiles.wordpress.org/lindstromer/\">Olaf Lindstr&#246;m</a>, <a href=\"https://profiles.wordpress.org/moonomo/\">Omaar Osmaan</a>, <a href=\"https://profiles.wordpress.org/omarreiss/\">Omar Reiss</a>, <a href=\"https://profiles.wordpress.org/onlanka/\">onlanka</a>, <a href=\"https://profiles.wordpress.org/ov3rfly/\">Ov3rfly</a>, <a href=\"https://profiles.wordpress.org/oxyc/\">oxyc</a>, <a href=\"https://profiles.wordpress.org/ozmatflc/\">ozmatflc</a>, <a href=\"https://profiles.wordpress.org/paaljoachim/\">Paal Joachim Romdahl</a>, <a href=\"https://profiles.wordpress.org/paragoninitiativeenterprises/\">Paragon Initiative Enterprises</a>, <a href=\"https://profiles.wordpress.org/paresh07/\">Paresh Shinde</a>, <a href=\"https://profiles.wordpress.org/hardipparmar/\">Parmar Hardip</a>, <a href=\"https://profiles.wordpress.org/swissspidy/\">Pascal Birchler</a>, <a href=\"https://profiles.wordpress.org/casiepa/\">Pascal Casier</a>, <a href=\"https://profiles.wordpress.org/patilvikasj/\">patilvikasj</a>, <a href=\"https://profiles.wordpress.org/patrelentlesstechnologycom/\">Patrick Baldwin</a>, <a href=\"https://profiles.wordpress.org/pbearne/\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/pbiron/\">Paul Biron</a>, <a href=\"https://profiles.wordpress.org/paulschreiber/\">Paul Schreiber</a>, <a href=\"https://profiles.wordpress.org/bassgang/\">Paul Vincent Beigang</a>, <a href=\"https://profiles.wordpress.org/pedromendonca/\">Pedro Mendon&#231;a</a>, <a href=\"https://profiles.wordpress.org/pputzer/\">pepe</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc/\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/phillipjohn/\">PhillipJohn</a>, <a href=\"https://profiles.wordpress.org/pierlo/\">Pierre Gordon</a>, <a href=\"https://profiles.wordpress.org/pikamander2/\">pikamander2</a>, <a href=\"https://profiles.wordpress.org/decrecementofeliz/\">Pilar Mera</a>, <a href=\"https://profiles.wordpress.org/wppinar/\">Pinar Olguc</a>, <a href=\"https://profiles.wordpress.org/powerbuoy/\">powerbuoy</a>, <a href=\"https://profiles.wordpress.org/promz/\">Pramod Jodhani</a>, <a href=\"https://profiles.wordpress.org/pratikthink/\">Pratik</a>, <a href=\"https://profiles.wordpress.org/pratikkry/\">Pratik K. Yadav</a>, <a href=\"https://profiles.wordpress.org/freewebmentor/\">Prem Tiwari</a>, <a href=\"https://profiles.wordpress.org/presskopp/\">Presskopp</a>, <a href=\"https://profiles.wordpress.org/priyankkpatel/\">Priyank Patel</a>, <a href=\"https://profiles.wordpress.org/quantumstate/\">Quantumstate</a>, <a href=\"https://profiles.wordpress.org/raajtram/\">Raaj Trambadia</a>, <a href=\"https://profiles.wordpress.org/raamdev/\">Raam Dev</a>, <a href=\"https://profiles.wordpress.org/raboodesign/\">raboodesign</a>, <a href=\"https://profiles.wordpress.org/larrach/\">Rachel Peter</a>, <a href=\"https://profiles.wordpress.org/rahulvaza/\">Rahul Vaza</a>, <a href=\"https://profiles.wordpress.org/superpoincare/\">Ramanan</a>, <a href=\"https://profiles.wordpress.org/ramiy/\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/ramon-fincken/\">ramon fincken</a>, <a href=\"https://profiles.wordpress.org/rclations/\">RC Lations</a>, <a href=\"https://profiles.wordpress.org/rebasaurus/\">rebasaurus</a>, <a href=\"https://profiles.wordpress.org/reikodd/\">ReikoDD</a>, <a href=\"https://profiles.wordpress.org/remcotolsma/\">Remco Tolsma</a>, <a href=\"https://profiles.wordpress.org/retrofox/\">retrofox</a>, <a href=\"https://profiles.wordpress.org/youknowriad/\">Riad Benguella</a>, <a href=\"https://profiles.wordpress.org/quicoto/\">Ricard Torres</a>, <a href=\"https://profiles.wordpress.org/rockfire/\">Richard Korthuis</a>, <a href=\"https://profiles.wordpress.org/riddhiehta02/\">Riddhi Mehta</a>, <a href=\"https://profiles.wordpress.org/rbrishabh/\">Rishabh Budhiraja</a>, <a href=\"https://profiles.wordpress.org/noisysocks/\">Robert Anderson</a>, <a href=\"https://profiles.wordpress.org/miqrogroove/\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/robi-bobi/\">Robert Ivanov</a>, <a href=\"https://profiles.wordpress.org/rogueresearch/\">rogueresearch</a>, <a href=\"https://profiles.wordpress.org/rconde/\">Roi Conde</a>, <a href=\"https://profiles.wordpress.org/murgroland/\">Roland Murg</a>, <a href=\"https://profiles.wordpress.org/ronakganatra/\">Ronak Ganatra</a>, <a href=\"https://profiles.wordpress.org/raubvogel/\">Ronny Harbich</a>, <a href=\"https://profiles.wordpress.org/karthost/\">Roy Randolph</a>, <a href=\"https://profiles.wordpress.org/roytanck/\">Roy Tanck</a>, <a href=\"https://profiles.wordpress.org/ryan/\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/ryankienstra/\">Ryan Kienstra</a>, <a href=\"https://profiles.wordpress.org/rmccue/\">Ryan McCue</a>, <a href=\"https://profiles.wordpress.org/welcher/\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/sebastienserre/\">S&#233;bastien SERRE</a>, <a href=\"https://profiles.wordpress.org/samgordondev/\">samgordondev</a>, <a href=\"https://profiles.wordpress.org/sasiddiqui/\">Sami Ahmed Siddiqui</a>, <a href=\"https://profiles.wordpress.org/solarissmoke/\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/otto42/\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/samuelfernandez/\">SamuelFernandez</a>, <a href=\"https://profiles.wordpress.org/progremzion/\">Sanket Mehta</a>, <a href=\"https://profiles.wordpress.org/tinkerbelly/\">sarah semark</a>, <a href=\"https://profiles.wordpress.org/sarathar/\">Sarath AR</a>, <a href=\"https://profiles.wordpress.org/saskak/\">saskak</a>, <a href=\"https://profiles.wordpress.org/sathyapulse/\">sathyapulse</a>, <a href=\"https://profiles.wordpress.org/sbardian/\">sbardian</a>, <a href=\"https://profiles.wordpress.org/coffee2code/\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic/\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scvleon/\">scvleon</a>, <a href=\"https://profiles.wordpress.org/sebastianpisula/\">Sebastian Pisula</a>, <a href=\"https://profiles.wordpress.org/assassinateur/\">Seghir Nadir</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov/\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/vjik/\">Sergey Predvoditelev</a>, <a href=\"https://profiles.wordpress.org/sergiomdgomes/\">sergiomdgomes</a>, <a href=\"https://profiles.wordpress.org/seuser/\">seuser</a>, <a href=\"https://profiles.wordpress.org/sgastard/\">sgastard</a>, <a href=\"https://profiles.wordpress.org/sgr33n/\">SGr33n</a>, <a href=\"https://profiles.wordpress.org/shadyvb/\">Shady Sharaf</a>, <a href=\"https://profiles.wordpress.org/shamim51/\">Shamim Hasan</a>, <a href=\"https://profiles.wordpress.org/sharaz/\">Sharaz Shahid</a>, <a href=\"https://profiles.wordpress.org/shashank3105/\">Shashank Panchal</a>, <a href=\"https://profiles.wordpress.org/shawfactor/\">shawfactor</a>, <a href=\"https://profiles.wordpress.org/shital-patel/\">Shital Marakana</a>, <a href=\"https://profiles.wordpress.org/siliconforks/\">siliconforks</a>, <a href=\"https://profiles.wordpress.org/simonjanin/\">simonjanin</a>, <a href=\"https://profiles.wordpress.org/simono/\">simono</a>, <a href=\"https://profiles.wordpress.org/sinatrateam/\">sinatrateam</a>, <a href=\"https://profiles.wordpress.org/sirreal/\">sirreal</a>, <a href=\"https://profiles.wordpress.org/sixes/\">Sixes</a>, <a href=\"https://profiles.wordpress.org/slaffik/\">Slava Abakumov</a>, <a href=\"https://profiles.wordpress.org/slobodanmanic/\">Slobodan Manic</a>, <a href=\"https://profiles.wordpress.org/smerriman/\">smerriman</a>, <a href=\"https://profiles.wordpress.org/snapfractalpop/\">snapfractalpop</a>, <a href=\"https://profiles.wordpress.org/socalchristina/\">socalchristina</a>, <a href=\"https://profiles.wordpress.org/soean/\">Soren Wrede</a>, <a href=\"https://profiles.wordpress.org/spectacula/\">Spectacula</a>, <a href=\"https://profiles.wordpress.org/spenserhale/\">spenserhale</a>, <a href=\"https://profiles.wordpress.org/spuds10/\">spuds10</a>, <a href=\"https://profiles.wordpress.org/sstoqnov/\">Stanimir Stoyanov</a>, <a href=\"https://profiles.wordpress.org/steevithak/\">steevithak</a>, <a href=\"https://profiles.wordpress.org/ryokuhi/\">Stefano Minoia</a>, <a href=\"https://profiles.wordpress.org/hypest/\">Stefanos Togoulidis</a>, <a href=\"https://profiles.wordpress.org/sabernhardt/\">Stephen Bernhardt</a>, <a href=\"https://profiles.wordpress.org/netweb/\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/dufresnesteven/\">Steve Dufresne</a>, <a href=\"https://profiles.wordpress.org/stevenkword/\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/studyboi/\">studyboi</a>, <a href=\"https://profiles.wordpress.org/subratamal/\">Subrata Mal</a>, <a href=\"https://profiles.wordpress.org/subrataemfluence/\">Subrata Sarkar</a>, <a href=\"https://profiles.wordpress.org/sudhiryadav/\">Sudhir Yadav</a>, <a href=\"https://profiles.wordpress.org/manikmist09/\">Sultan Nasir Uddin</a>, <a href=\"https://profiles.wordpress.org/tha_sun/\">sun</a>, <a href=\"https://profiles.wordpress.org/codesue/\">Suzen Fylke</a>, <a href=\"https://profiles.wordpress.org/svanhal/\">svanhal</a>, <a href=\"https://profiles.wordpress.org/patilswapnilv/\">Swapnil V. Patil</a>, <a href=\"https://profiles.wordpress.org/swapnild/\">swapnild</a>, <a href=\"https://profiles.wordpress.org/cybr/\">Sybre Waaijer</a>, <a href=\"https://profiles.wordpress.org/sergioestevao/\">Sérgio Estêvão</a>, <a href=\"https://profiles.wordpress.org/miyauchi/\">Takayuki Miyauchi</a>, <a href=\"https://profiles.wordpress.org/nevma/\">Takis Bouyouris</a>, <a href=\"https://profiles.wordpress.org/karmatosed/\">Tammie Lister</a>, <a href=\"https://profiles.wordpress.org/tanvirul/\">Tanvirul Haque</a>, <a href=\"https://profiles.wordpress.org/tazotodua/\">tazotodua</a>, <a href=\"https://profiles.wordpress.org/technote0space/\">technote</a>, <a href=\"https://profiles.wordpress.org/tellyworth/\">Tellyworth</a>, <a href=\"https://profiles.wordpress.org/tessak22/\">Tessa Kriesel</a>, <a href=\"https://profiles.wordpress.org/themes-1/\">them.es</a>, <a href=\"https://profiles.wordpress.org/themezly/\">Themezly</a>, <a href=\"https://profiles.wordpress.org/thulshof/\">Thijs Hulshof</a>, <a href=\"https://profiles.wordpress.org/kraftner/\">Thomas Kr&#228;ftner</a>, <a href=\"https://profiles.wordpress.org/thomaswm/\">thomaswm</a>, <a href=\"https://profiles.wordpress.org/tdh/\">Thord D. Hedengren</a>, <a href=\"https://profiles.wordpress.org/tfrommen/\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/thrijith/\">Thrijith Thankachan</a>, <a href=\"https://profiles.wordpress.org/tigertech/\">tigertech</a>, <a href=\"https://profiles.wordpress.org/n7studios/\">Tim Carr</a>, <a href=\"https://profiles.wordpress.org/timhavinga/\">Tim Havinga</a>, <a href=\"https://profiles.wordpress.org/hedgefield/\">Tim Hengeveld</a>, <a href=\"https://profiles.wordpress.org/timon33/\">timon33</a>, <a href=\"https://profiles.wordpress.org/spaceshipone/\">Timoth&#233;e Brosille</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs/\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/timph/\">timph</a>, <a href=\"https://profiles.wordpress.org/tmatsuur/\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tmdesigned/\">tmdesigned</a>, <a href=\"https://profiles.wordpress.org/tobiasbg/\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tobifjellner/\">tobifjellner (Tor-Bjorn Fjellner)</a>, <a href=\"https://profiles.wordpress.org/toddhalfpenny/\">toddhalfpenny</a>, <a href=\"https://profiles.wordpress.org/tosho/\">Todor Gaidarov</a>, <a href=\"https://profiles.wordpress.org/tjnowell/\">Tom J Nowell</a>, <a href=\"https://profiles.wordpress.org/tferry/\">Tommy Ferry</a>, <a href=\"https://profiles.wordpress.org/skithund/\">Toni Viemer&#246;</a>, <a href=\"https://profiles.wordpress.org/tonybogdanov/\">tonybogdanov</a>, <a href=\"https://profiles.wordpress.org/torres126/\">torres126</a>, <a href=\"https://profiles.wordpress.org/zodiac1978/\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/itowhid06/\">Towhidul Islam</a>, <a href=\"https://profiles.wordpress.org/trasweb/\">trasweb</a>, <a href=\"https://profiles.wordpress.org/travisnorthcutt/\">Travis Northcutt</a>, <a href=\"https://profiles.wordpress.org/travisseitler/\">travisseitler</a>, <a href=\"https://profiles.wordpress.org/triplejumper12/\">triplejumper12</a>, <a href=\"https://profiles.wordpress.org/truchot/\">truchot</a>, <a href=\"https://profiles.wordpress.org/truongwp/\">truongwp</a>, <a href=\"https://profiles.wordpress.org/dekervit/\">Tugdual de Kerviler</a>, <a href=\"https://profiles.wordpress.org/dinhtungdu/\">Tung Du</a>, <a href=\"https://profiles.wordpress.org/desaiuditd/\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/grapplerulrich/\">Ulrich</a>, <a href=\"https://profiles.wordpress.org/utsav72640/\">Utsav tilava</a>, <a href=\"https://profiles.wordpress.org/vaishalipanchal/\">Vaishali Panchal</a>, <a href=\"https://profiles.wordpress.org/vbaimas/\">vbaimas</a>, <a href=\"https://profiles.wordpress.org/veminom/\">Veminom</a>, <a href=\"https://profiles.wordpress.org/venutius/\">Venutius</a>, <a href=\"https://profiles.wordpress.org/fesovik/\">Viktor Veljanovski</a>, <a href=\"https://profiles.wordpress.org/vishalkakadiya/\">Vishal Kakadiya</a>, <a href=\"https://profiles.wordpress.org/vishitshah/\">Vishit Shah</a>, <a href=\"https://profiles.wordpress.org/vladlu/\">vladlu</a>, <a href=\"https://profiles.wordpress.org/vladwtz/\">Vladut Ilie</a>, <a href=\"https://profiles.wordpress.org/vortfu/\">vortfu</a>, <a href=\"https://profiles.wordpress.org/svovaf/\">Vova Feldman</a>, <a href=\"https://profiles.wordpress.org/vrimill/\">vrimill</a>, <a href=\"https://profiles.wordpress.org/w3rkjana/\">w3rkjana</a>, <a href=\"https://profiles.wordpress.org/waleedt93/\">waleedt93</a>, <a href=\"https://profiles.wordpress.org/webcommsat/\">webcommsat AbhaNonStopNewsUK</a>, <a href=\"https://profiles.wordpress.org/webdados/\">Webdados (Marco Almeida)</a>, <a href=\"https://profiles.wordpress.org/webmandesign/\">WebMan Design &#124; Oliver Juhas</a>, <a href=\"https://profiles.wordpress.org/westonruter/\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam/\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/wpdavis/\">William P. Davis</a>, <a href=\"https://profiles.wordpress.org/williampatton/\">William Patton</a>, <a href=\"https://profiles.wordpress.org/withinboredom/\">withinboredom</a>, <a href=\"https://profiles.wordpress.org/worldweb/\">worldweb</a>, <a href=\"https://profiles.wordpress.org/wpgurudev/\">wpgurudev</a>, <a href=\"https://profiles.wordpress.org/yanngarcia/\">yanngarcia</a>, <a href=\"https://profiles.wordpress.org/collet/\">Yannicki</a>, <a href=\"https://profiles.wordpress.org/yarnboy/\">yarnboy</a>, <a href=\"https://profiles.wordpress.org/yashar_hv/\">yashar_hv</a>, <a href=\"https://profiles.wordpress.org/yoavf/\">Yoav Farhi</a>, <a href=\"https://profiles.wordpress.org/yodiyo/\">yodiyo</a>, <a href=\"https://profiles.wordpress.org/fierevere/\">Yui</a>, <a href=\"https://profiles.wordpress.org/yvettesonneveld/\">Yvette Sonneveld</a>, <a href=\"https://profiles.wordpress.org/zaantar/\">zaantar</a>, <a href=\"https://profiles.wordpress.org/tollmanz/\">Zack Tollman</a>, <a href=\"https://profiles.wordpress.org/zalak151291/\">zalak151291</a>, <a href=\"https://profiles.wordpress.org/zebulan/\">Zebulan Stanphill</a>, <a href=\"https://profiles.wordpress.org/chesio/\">Česlav Przywara</a>, <a href=\"https://profiles.wordpress.org/airathalitov/\">АЙРАТ ХАЛИТОВ <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f525.png\" alt=\"🔥\" class=\"wp-smiley\" /></a>, and <a href=\"https://profiles.wordpress.org/ounziw/\">水野史土</a>.



<div class=\"wp-block-spacer\"></div>



<p>Many thanks to all of the community volunteers who contribute in the <a href=\"https://wordpress.org/support/\">support forums</a>. They answer questions from people across the world, whether they are using WordPress for the first time or since the first release. These releases are more successful for their efforts!</p>



<p>Finally, thanks to all the community translators who worked on WordPress 5.3. Their efforts bring WordPress fully translated to 47 languages at release time, with more on the way.</p>



<p>If you want learn more about volunteering with WordPress, check out&nbsp;<a href=\"https://make.wordpress.org/\">Make WordPress</a>&nbsp;or the&nbsp;<a href=\"https://make.wordpress.org/core/\">core development blog</a>.</p>



<hr class=\"wp-block-separator\" />



<p class=\"has-text-align-center has-medium-font-size\">Thanks for choosing WordPress!</p>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/11/image.png?fit=632%2C414&ssl=1\" alt=\"\" class=\"wp-image-7755\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Nov 2019 21:38:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Recurring Payments Feature Launches for WordPress.com and Jetpack Users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95300\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"https://wptavern.com/recurring-payments-feature-launches-for-wordpress-com-and-jetpack-users\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3978:\"<p>WordPress.com <a href=\"https://en.blog.wordpress.com/2019/11/12/recurring-payments/\">launched a new recurring payments feature</a> its users today.  The payments system will allow bloggers to earn money for their content directly from any page on their site.  The feature is also available for self-hosted WordPress users who have the Jetpack plugin installed.</p>



<p>The recurring payments system works alongside <a href=\"https://stripe.com\">Stripe</a>, so users must have a connected account to receive payments.  Stripe currently serves over 30 countries around the world.  WordPress.com&rsquo;s documentation maintains an up-to-date <a href=\"https://en.support.wordpress.com/recurring-payments-button/#stripe-supported-countries\">list of countries</a> currently allowed to use the payment gateway.</p>



<p>The new feature doesn&rsquo;t come for free.  Recurring payments access is only available to users on a premium WordPress.com plan.  Plus, on top of the 2.9% + $0.30 for each payment that Stripe collects, WordPress.com has a <a href=\"https://en.support.wordpress.com/recurring-payments-button/#related-fees\">tiered fee table</a> based on the user&rsquo;s plan.</p>



<ul><li>WordPress.com eCommerce &ndash; No fee</li><li>WordPress.com Business &ndash; 2% per sale</li><li>WordPress.com Premium &ndash; 4% per sale</li><li>WordPress.com Personal &ndash; 8% per sale</li></ul>



<p>At the lowest tier, users will see nearly 11% of sales go toward WordPress.com and Stripe fees.  If accepting large volumes of payments, it will make sense for most users to upgrade to a higher plan to offset the fees.  The tiers seem reasonably priced because the infrastructure is completely handled by WordPress.com.  </p>



<p>Self-hosted users can bypass the WordPress.com fees with a multitude of existing payment plugins.  They will have to decide whether the tools and support provided by WordPress.com is enough of a value-add to go for their service.</p>



<p>The Jetpack team first <a href=\"https://wptavern.com/jetpack-opens-signup-for-membership-block-beta\">opened a limited beta test</a> for this new feature on May 18, 2019.  At the time, the feature was referred to as a &ldquo;membership block.&rdquo;  The announcement post says that users can &ldquo;offer ongoing subscriptions, site memberships, monthly donations, and more.&rdquo;</p>



<p>However, members-based content seems to be limited in comparison to other fully-featured membership plugins and would require extra manual work to limit access to a site&rsquo;s premium content.  The WordPress.com recommendation is to <a href=\"https://en.support.wordpress.com/recurring-payments-button/#limit-access-to-content\">password-protect posts</a> and email out the password to subscribers or set up a newsletter.</p>



<p>This is far from a true membership system, but it could be enough for the average blogger who wants to make a few dollars on the side.  The groundwork is there for a more powerful membership system in the future if the WordPress.com and Jetpack teams want to pursue it.  The market is still ripe for innovation in the membership space.</p>



<h2>Recurring Payments Block</h2>



<div class=\"wp-block-image\"><img />Jetpack recurring payments editor block</div>



<p>The new recurring payments feature requires at least Jetpack version 7.4.  The feature comes in the form of a block for the block editor (Gutenberg) and is located under the &ldquo;Jetpack&rdquo; tab when inserting a new block.</p>



<p>The block has four fields that can be customized:</p>



<ul><li>Currency</li><li>Price</li><li>Description</li><li>Renewal Interval &ndash; limited to monthly and yearly renewals</li></ul>



<p>There is no limit on the number of different payment blocks users can add.  Users can create a new payment plan by adding a new block.  Previous options are backed up and will appear when inserting the block for users who need to output an existing plan on a new post or page.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Nov 2019 19:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"bbPress: bbPress 2.6 – Better Great Than Never\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://bbpress.org/?p=193159\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://bbpress.org/blog/2019/11/bbpress-2-6/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2501:\"<p>There&#8217;s no way for me to contain either my excitement or anxiety when I say that bbPress 2.6.0 is available now! <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f389.png\" alt=\"🎉\" class=\"wp-smiley\" /></p>



<p>This version of bbPress has been in development for just a bit under 6 years (yikes!) over which 420 tickets were resolved via 1737 individual code commits.</p>



<p>There are so many improvements that a changelog hardly seems fitting for this post, but the major features include per-forum moderation, a bunch of new platforms to import from, and an extensible engagements API that now powers the relationships between users, forums, topics, replies, subscriptions, and favorites.</p>



<p>At the time of this writing, bbPress is installed on approximately 336,000 WordPress installations, and is the most widely installed forum software in the world (according to BuiltWith.com and other sources.) Several of those are right here on bbPress.org, BuddyPress.org, and WordPress.org, the later of which includes a few dozen separate languages for non-English speaking communities of contributors all over the world.</p>



<p>The elephant in the room&#8230; the reason that 2.6.0 took so long, is pretty simple. bbPress has a small contributor pool, and none of us are 100% dedicated towards it. The project gets very little community feedback, which makes it hard to know if everything is working perfectly, or nobody is testing it at all. </p>



<p>So&#8230; 4 less-than part-time folks supporting over 300k sites, each with their own thousands of users, depending on us. </p>



<p>The pressure is high, and the chamber is echo&#8217;y, and as my own career has progressed these past 13 years, the numbers above make me increasingly nervous.</p>



<p>And the longer something takes to do is the higher the expectations are, and I personally locked up pretty hard multiple times on whether done was done enough to be trusted by so many having been tested by so few.</p>



<p>But&#8230; good things come to those who wait, and I’m sincerely sorry to have kept any of you waiting for too long.</p>



<p>bbPress 2.6.0 has been running smoothly on these forums since day 0. It’s stable, pretty, and a joy to use. We know you are gonna love it!</p>



<p><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f41d.png\" alt=\"🐝\" class=\"wp-smiley\" /><img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f49a.png\" alt=\"💚\" class=\"wp-smiley\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 12 Nov 2019 18:42:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Beyond Prefixing: A WordPress Developer’s Guide to PHP Namespaces\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95284\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wptavern.com/beyond-prefixing-a-wordpress-developers-guide-to-php-namespaces\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:9768:\"<p><em>Prefix everything.</em></p>



<p>It is an adage that is old as the WordPress software itself.  Prefixing has been a standard for WordPress developers for so long that it&rsquo;s hard to imagine doing anything different.  But, the time has come for something new.  Well, it is long past due, but WordPress lags a bit behind in standard practices in the larger PHP world.</p>



<p>Prefixing is the practice of creating a code-friendly version of your project name and sticking it to the front of functions, classes, and other things in the global namespace.  For example, you would name a function <code>tavern_get_post()</code> instead of <code>get_post()</code> to avoid function name clashes, which would result in a fatal error.</p>



<p>Prefixing is one form of &ldquo;namespacing,&rdquo; which is just a fancy way of saying that names in this space belong to a specific project.  However, prefixing (and suffixing, which is less common) is a hack from a time when no solution existed for the PHP language.</p>



<p>PHP 5.3 introduced an official method of namespacing, so the standard has existed for years.  Because WordPress 5.2 <a href=\"https://wptavern.com/wordpress-ends-support-for-php-5-2-5-5-bumps-minimum-required-php-version-to-5-6\">bumped the minimum PHP requirement</a> to 5.6, it is time for developers to shed their old habits and catch up to the rest of the PHP world.</p>



<h2>Namespace (Almost) Everything</h2>



<p>PHP namespacing only covers the following items.</p>



<ul><li>Classes</li><li>Interfaces</li><li>Traits</li><li>Functions</li><li>Constants declared with the <code>const</code> keyword but not <code>define()</code></li></ul>



<p>When it comes to script handles, image size names, database options, and other items in the global namespace, you must still prefix them.  Those are IDs and outside the scope of PHP namespacing.</p>



<h2>How to Create Namespaces</h2>



<p>Namespaces are simple to declare.  At the top of any PHP file that you want to use a particular namespace, declare it as shown in the following code snippet.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern;
</pre>


<p>What this line of code does is declare that everything within this particular file has the namespace of <code>Tavern</code>.</p>



<p>Take a look at a simple function under that namespace for outputting a <code>Hello, World!</code> message.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern;

function hello() {
    _e( \'Hello, World!\', \'example-textdomain\' );
}
</pre>


<p>If following the old rules of prefixing, <code>hello()</code> would have been named <code>tavern_hello()</code>.  However, that&rsquo;s not the case with namespaces.  The <code>hello()</code> function is encapsulated within the <code>Tavern</code> namespace and will not conflict with other functions named <code>hello()</code>.</p>



<p>Classes and interfaces work the same as functions.  With a class name of <code>Article</code>, the class file might look like the following.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern;

class Article {
    // ...
}
</pre>


<p><strong>Note:</strong> There should only ever be one class or interface per file. This is particularly important if you ever plan to use an autoloader.</p>



<h2>How to <em>Name</em> Namespaces</h2>



<p>Developers like to argue over how to name things, and there is no one-size-fits-all solution.  The most important rule is to be unique to avoid clashes with code from other projects.  One of the best ways to do that is to use a top-level <code>Vendor</code> namespace with a <code>Package</code> sub-namespace.</p>



<p>Suppose the vendor namespace was <code>Tavern</code> and the project in question was a WordPress theme named <code>News</code>.  The namespace for the project might look like the following.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern\\News;
</pre>


<p>That may be a bit verbose for some developers.  If your project&rsquo;s name is already fairly unique, such as &ldquo;Awesomesauce,&rdquo; you may simply want to use the following.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Awesomesauce;
</pre>


<p>You will want to come up with some sort of standard convention, at the very least, for yourself.  Eventually, you&rsquo;ll want to get into things like auto-loading, so having a system you follow in all your projects will help.  Feel free to peruse the PHP-FIG <a href=\"https://www.php-fig.org/psr/psr-4/\">Autoloader standard</a>.</p>



<h2>Importing Classes and Functions into a Different Namespace</h2>



<p>When you need to use a class or function from a different namespace than the current namespace, you need to import it.  This is done via the <code>use</code> keyword in PHP.</p>



<p>The <code>use</code> statement must come after the <code>namespace</code> declaration. It should also reference the fully-qualified class name.  The following code imports the <code>Tavern\\Helpers\\Post</code> class into a file with a different namespace.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern\\Template;

use Tavern\\Helpers\\Post;
</pre>


<p>Once it is imported, you are safe to use the <code>Post</code> class directly as shown in the next snippet.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
$post = new Post();
</pre>


<p>As of PHP 5.6, you can also import functions and constants from other namespaces using the <code>use function</code> and <code>use const</code> keywords, respectively.  The following code block demonstrates how to import both a function and a constant.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern\\Template;

use function Tavern\\Helpers\\func_name;
use const    Tavern\\Helpers\\CONSTANT_NAME;
</pre>


<h2>Aliasing Classes and Functions</h2>



<p>Eventually, you will run into a situation where you need to import a class or function that has the same name as a class or function within the current namespace.  You might be thinking that this is the problem that namespaces were meant to solve.  Fortunately, PHP provides a method of creating an alias on import.</p>



<p>Suppose you have a class named <code>Tavern\\User</code> and need to implement the <code>Tavern\\Contracts\\User</code> interface.  When importing the interface, you will need to create an alias as shown below.</p>


<pre class=\"brush: php; gutter: false; title: ; wrap-lines: false; notranslate\">
&lt;?php

namespace Tavern;

use Tavern\\Contracts\\User as UserContract;

class User implements UserContract {
    // ...
}
</pre>


<p>The <code>as UserContract</code> appended to the end of the <code>use</code> statement creates an alias for the <code>User</code> interface.  You can safely use the new <code>UserContract</code> name without error.</p>



<p>Classes, interfaces, functions, and constants all follow the same method for creating an alias.</p>



<h2>Organizing Folder Structure Based on Namespaces</h2>



<p>It is standard practice in the wider PHP world for namespaces and the project&rsquo;s file and folder structure to match.  Doing this makes it easy for other developers to easily locate code within your project.  It also makes it simple to build autoloaders for loading classes on demand.</p>



<p>Generally, all PHP code should go into a <code>/src</code>, <code>/inc</code>, or similarly-named folder in your project.  An example plugin file and folder structure might look like the following.</p>


<pre class=\"brush: plain; gutter: false; title: ; wrap-lines: false; notranslate\">
/plugin-name
    /src
        /Core
            /Activate.php
            /Setup.php
        /View
            /Post.php
            /Page.php
</pre>


<p>If following the same structure with namespaces, the above <code>.php</code> files would contain the following classes.</p>



<ul><li><code>Tavern\\Core\\Activate</code></li><li><code>Tavern\\Core\\Setup</code></li><li><code>Tavern\\View\\Post</code></li><li><code>Tavern\\View\\Page</code></li></ul>



<p>Take note that file and folder names are case-sensitive and should match the namespace and class name exactly.</p>



<p>Of course, you are free to follow any convention that you wish.  However, the preceding recommendation is good practice and will simplify how you organize your projects in the long term.</p>



<h2>Benefits of Using Namespaces</h2>



<p>The most obvious benefit is to avoid clashes between classes and functions with the same name.  You should use real namespaces for the same reason you used prefixes.</p>



<p>Namespaces help to avoid long class names.  Typing long names throughout a large project is a tedious practice at best.</p>



<p>More easily switch implementations by importing.  Once you get the hang of importing classes and interfaces from other namespaces, you can switch an implementation of an interface with a single line of code.</p>



<p>Autoloading classes is far easier if you follow the <a href=\"https://www.php-fig.org/psr/psr-4/\">PSR-4: Autoloader</a> standard, which requires at least a top-level namespace.</p>



<p>For developers in the professional space, you will gain a marketable skill beyond the WordPress ecosystem.  You will be hard-pressed to find PHP development work if you don&rsquo;t know how to use namespaces.  It is not a tough concept to grasp, but there can be a learning curve for some in practice.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 11 Nov 2019 18:43:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Matt: Farnam Street’s Great Mental Models, Presented by Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50433\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"https://ma.tt/2019/11/farnam-streets-great-mental-models-presented-by-automattic/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1075:\"<p>I&#8217;ve been a fan of Shane Parrish and his indispensable <a href=\"https://fs.blog/\">Farnam Street</a> for many years now. Shane is a <a href=\"https://www.nytimes.com/2018/11/11/business/intelligence-expert-wall-street.html\">fascinating person</a> — he&#8217;s a former cybersecurity expert for the Canadian intelligence agency and occasional blogger who turned his website into a full-time career. Oh and <a href=\"http://fs.blog\">fs.blog</a> is on WordPress, too. <img src=\"https://s.w.org/images/core/emoji/12.0.0-1/72x72/1f60e.png\" alt=\"😎\" class=\"wp-smiley\" /></p>



<p>His book, <a href=\"https://fs.blog/tgmm/\"><em>The Great Mental Models: General Thinking Concepts</em></a>, has been tremendously valuable to me in my work. So valuable, in fact, that Automattic is now sponsoring the next printing of the hardcover edition. <a href=\"https://www.amazon.com/Great-Mental-Models-Thinking-Concepts/dp/1999449002/\">You can pre-order it here</a>, then learn more about <a href=\"https://fs.blog/general-thinking-concepts/\">the mental models outlined in it</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 11 Nov 2019 15:59:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"BuddyPress: The road to BuddyPress blocks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://buddypress.org/?p=308912\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://buddypress.org/2019/11/the-road-to-buddypress-blocks/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5679:\"<p>Hi everyone!</p>



<p>First, we&#8217;d like to thank all the people who contributed to the poll we shared on our <a href=\"https://bpdevel.wordpress.com/2019/10/10/take-the-buddypress-blocks-poll/\">development updates blog</a> and into <a href=\"https://buddypress.org/support/topic/take-the-buddypress-blocks-poll/\">a topic of one of our forums</a> a month ago. It was really important for us to have your expectations about the content the plugin should provide to the WordPress Block Editor.</p>



<p>It&#8217;s now time for us to share with you the <a href=\"https://poll.fm/10425422/results\">results of this poll</a> and tell you how we plan to work on BuddyPress blocks for the next release(s) of your favorite community engine!</p>



<span id=\"more-308912\"></span>



<h2>The results of the Blocks Poll</h2>



<p>It received a total of 161 votes divided as follows:</p>



<ul><li>A block to share a post or a page via the Activity Stream : <strong>17 votes</strong>.</li><li>A block to list the recently published posts from across your network (Exists as a widget) : <strong>13 votes</strong>.</li><li>A block to display Sitewide Notices posted by the site administrator (Exists as a widget) : <strong>12 votes</strong>.</li><li>A block to dynamicaly list the recently active, popular, newest, or alphabetical groups (Exists as a widget) : <strong>11 votes</strong>.</li><li>A block to display Profile photos of online users (Exists as a widget) : <strong>10 votes</strong>.</li><li><em>A block to highlight a single Group</em> : <strong>10 votes</strong>.</li><li><em>A block to highlight a single Member</em> : <strong>10 votes</strong>.</li><li>A block to dynamicaly list the recently active, popular, and newest Friends of a given member (Exists as a widget) : <strong>9 votes</strong>.</li><li>A block to display the Profile photos of recently active members (Exists as a widget) : <strong>9 votes</strong>.</li><li>A block to restrict content to a Group type : <strong>9 votes</strong>.</li><li>A block to dynamicaly list the recently active, popular, and newest members (Exists as a widget) : <strong>8 votes</strong>.</li><li>A block to restrict content to a Member type : <strong>8 votes</strong>.</li><li>A block to restrict content to Group members : <strong>7 votes</strong>.</li><li>A block to list the Member types : <strong>7 votes</strong>.</li><li>A block to display a selected Activity as a quote : <strong>6 votes</strong>.</li><li>A block to list the Group types : <strong>5 votes</strong>.</li><li>A placeholder block for directory pages to eventually make them benefit from wide alignments : <strong>5 votes</strong>.</li><li>No blocks! : <strong>3 votes</strong>.</li><li>Other : <strong>2 votes</strong>.</li></ul>



<p>As you can see, top results are mostly corresponding to existing widgets except for:</p>



<ul><li>A block to share a post or a page via the Activity Stream.</li><li><em>A block to highlight a single Group or a single Member</em>.</li></ul>



<p>We also analyze from these results that there is no blocks expected to be a must have and it&#8217;s interesting to see that the 2 first blocks are about highlighting WordPress content. Finally only one suggestion was made : A &#8220;Block for Activity Stream component&#8221; (<em>PS: in Nouveau there&#8217;s an existing widget for it</em>).</p>



<h2>About the BuddyPress development team&#8217;s decision regarding BuddyPress blocks.</h2>



<div class=\"wp-block-image\"><img src=\"https://buddypress.org/wp-content/uploads/1/2019/11/starting-point-1024x520.png\" alt=\"\" class=\"wp-image-308935\" />Screen capture of the BuddyPress Blocks category when the <a href=\"https://github.com/buddypress/bp-blocks\">BP Blocks</a> plugin is active.</div>



<p>We think working on blocks to highlight a single Group or a single Member is a good starting point. Moreover it&#8217;s something we don&#8217;t make possible yet. We also think converting existing widgets to blocks is an obvious move to do.</p>



<p>We&#8217;ve decided to work on these blocks from a specific <a href=\"https://github.com/buddypress/bp-blocks\">GitHub repository</a> and to merge into the Core of the BuddyPress plugin the &#8220;JavaScript built&#8221; blocks as soon as they are ready. To the very least, we&#8217;ll have the 2 blocks to highlight a Group or a Member of your community site merged into BuddyPress for its next major release (<strong>6.0.0</strong>).</p>



<p>We&#8217;ve just pushed the <a href=\"https://github.com/buddypress/bp-blocks/commit/227a15814cfbf239fb382ee5b11d29240a6ae54f\">minimal code</a> to start working on BuddyPress blocks into the BP Blocks&#8217; GitHub repository. We&#8217;ll soon add contributing notes into this repository so that you can help us building beautiful BuddyPress blocks. You can already share with us your &#8220;Pull Requests&#8221; forking the repository.</p>



<p>If you can&#8217;t wait for the contributing notes to start working on BuddyPress Blocks, here&#8217;s a quick &#8220;how-to&#8221; :</p>



<ul><li>Once you cloned your fork into your development environment, do <code>npm install</code></li><li>The JavaScript (ESNext) code for your block needs to land into the <code>/src/bp-{ID of the BP Component}/js/blocks/</code> directory.</li><li>Have a look at the way the <code>bp/member</code> block is registered <a href=\"https://github.com/buddypress/bp-blocks/blob/master/build/bp-members/bp-members-blocks.php#L19-L29\">here</a> to build your registration code.</li><li>run <code>npm start</code> to see how your JavaScript code behaves at each edit.</li></ul>



<p>Let&#8217;s build awesome BuddyPress blocks, together &lt;3.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Nov 2019 18:30:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Mathieu Viet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WordPress.org blog: People of WordPress: Kim Parsell\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"https://wordpress.org/news/?p=7662\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2019/11/people-of-wordpress-kim-parsell/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6063:\"<p><em>You’ve probably heard that WordPress is open-source software, and may know that it’s created and run by volunteers. WordPress enthusiasts share many examples of how WordPress changed people’s lives for the better. This monthly series shares some of those lesser-known, amazing stories.</em></p>



<h2><strong>Meet Kim Parsell</strong></h2>



<p>We’d like to introduce you to Kim Parsell. Kim was an active and well-loved member of the WordPress community. Unfortunately, she passed away in 2015. Lovingly referred to as #wpmom, she leaves behind a legacy of service.&nbsp;</p>



<img src=\"https://i1.wp.com/wordpress.org/news/files/2019/11/Kim-Parsell-1.jpg?fit=632%2C252&ssl=1\" alt=\"\" class=\"wp-image-7664\" />Kim Parsell



<h2><strong>How Kim became #wpmom</strong></h2>



<p>In order to understand how highly valued the WordPress community was to Kim Parsell, you have to know a bit about her environment.</p>



<p>Kim was a middle-aged woman who lived off a dirt road, on top of a hill, in Southern rural Ohio. She was often by herself, taking care of the property with only a few neighbors up and down the road.</p>



<p>She received internet access from towers that broadcast wireless signals, similar to cell phones but at lower speeds.</p>



<h2><strong>Connecting through attending live podcast recordings</strong></h2>



<p>By listening to the regular podcast, WordPress Weekly, Kim met members of the WordPress community and was able to talk to them on a weekly basis. The show and its after-hours sessions provided Kim a chance to mingle with the who’s who of WordPress at the time. It helped establish long-lasting relationships that would open up future opportunities for her.</p>



<p>Since she lived in a location where few around her used or had even heard of WordPress, the community was an opportunity for her to be with like-minded people. Kim enjoyed interacting with the community, both online and at WordCamp events, and many community members became her second family, a responsibility she took very seriously.</p>



<blockquote class=\"wp-block-quote\"><p><em>&#8220;Many members of the WordPress community became her second family, a responsibility she took very seriously.&#8221;</em></p><cite><em>Jeff Chandler</em></cite></blockquote>



<h2><strong>One of the first women of WordPress</strong></h2>



<p>Kim is regarded as one of the first “women of WordPress,” investing a lot of her time in women who wanted to break into tech. She worked hard to create a safe environment sharing herself and her knowledge and was affectionately called #wpmom.</p>



<p>She contributed countless hours of volunteer time, receiving “props” for 5 major releases of WordPress, and was active on the documentation team.&nbsp;</p>



<blockquote class=\"wp-block-quote\"><p><em>&#8220;Affectionately called #wpmom, Kim was an investor. She invested countless hours into the WordPress project and in women who wanted to break into tech.&#8221;</em></p><cite><em>Carrie Dils</em></cite></blockquote>



<img src=\"https://i0.wp.com/wordpress.org/news/files/2019/11/KimParsell2.jpg?fit=632%2C468&ssl=1\" alt=\"\" class=\"wp-image-7663\" />Kim at WordCamp San Francisco



<h2><strong>Kim Parsell Memorial Scholarship</strong></h2>



<p>In 2014, she received a travel stipend offered by the WordPress Foundation that enabled her to attend the WordPress community summit, held in conjunction with WordCamp San Francisco. She shared with anyone who would listen, that this was a life-changing event for her.&nbsp;</p>



<p>The WordPress Foundation now offers that scholarship in her memory. The Kim Parsell Memorial Scholarship provides funding annually for a woman who contributes to WordPress to attend WordCamp US, a flagship event for the WordPress community.</p>



<p>This scholarship truly is a fitting memorial. Her contributions have been vital to the project. Moreover, the way she treated and encouraged the people around her has been an inspiration to many.&nbsp;&nbsp;</p>



<blockquote class=\"wp-block-quote\"><p><em>Her spirit lives on in the people she knew and inspired. Here’s hoping that the Kim Parsell Memorial Scholarship will serve to further inspire those who follow in her footsteps.</em></p><cite><em>Drew Jaynes</em></cite></blockquote>



<h2><strong>Kim is missed, but her spirit continues to live on</strong></h2>



<p>Sadly Kim died just a few short months later. But her spirit lives on in the people she knew and inspired within her communities. The Kim Parsell Memorial Scholarship will serve to further inspire those who follow in her footsteps.</p>



<h2><strong>Contributors</strong></h2>



<p>Alison Rothwell (<a href=\"https://profiles.wordpress.org/wpfiddlybits/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>wpfiddlybits</a>), Yvette Sonneveld (<a href=\"https://profiles.wordpress.org/yvettesonneveld/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>yvettesonneveld</a>), Josepha Haden (<a href=\"https://profiles.wordpress.org/chanthaboune/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>chanthaboune</a>), Topher DeRosia (<a href=\"https://profiles.wordpress.org/topher1kenobe/\" class=\"mention\"><span class=\"mentions-prefix\">@</span>topher1kenobe</a>), Jeff Chandler, Carrie Dils, Jayvee Arrellano, Jan Dembowski, Drew Jaynes</p>



<div class=\"wp-block-columns\">
<div class=\"wp-block-column\">
<img src=\"https://i1.wp.com/wordpress.org/news/files/2019/07/heropress_large_white_logo.jpg?resize=632%2C474&ssl=1\" alt=\"\" class=\"wp-image-7025\" />
</div>



<div class=\"wp-block-column\">
<p> <em>This post is based on an article originally published on HeroPress.com, a community initiative created by <a href=\"https://profiles.wordpress.org/topher1kenobe/\">Topher DeRosia</a>. HeroPress highlights people in the WordPress community who have overcome barriers and whose stories would otherwise go unheard.</em> </p>
</div>
</div>



<p> <em>Meet more WordPress community members over at </em><a href=\"https://heropress.com/\"><em>HeroPress.com</em></a><em>!</em> </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 08 Nov 2019 23:58:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Yvette Sonneveld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"Post Status: A Teenage Woman’s Perspective On The State of The Word\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=70959\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://poststatus.com/a-teenage-womans-perspective-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6914:\"<p>Hello everyone! This year I got the chance to go to the <a href=\"https://poststatus.com/matt-mullenweg-state-of-the-word-2019/\">State of the Word</a>, which is a talk given by Matt Mullenweg each year at WordCamp US (WCUS). Here are my thoughts and views on this year’s State of the Word.</p>



<p>Before he even got started with the State of the Word, Matt premiered a new documentary that focuses on the fact that WordPress is both open source and also a big community. The documentary takes you to WordCamp Phoenix, WordCamp US (2018), and others. It also gives you first-hand exposure to what the community is really like.</p>



<p>Another thing that the film emphasizes, is the fact that everyone wants everyone in the community to succeed, and this might be one of the unique features of the WordPress community — how members are supportive of each other.</p>



<h3>Let’s Get Started!</h3>



<p>Matt discussed several milestones and release notes for WordPress.</p>



<h4>Two different releases within a year:</h4>



<ul><li>WordPress 5.1: Developer Experience Improvements&nbsp;</li><li>WordPress 5.2: New Widgets, which can be shown or hidden</li></ul>



<h4>The future of releases:</h4>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<p><strong>WordPress 5.3</strong></p>



<ul><li>November 12</li><li>Over 150 block editor improvements</li><li>Twenty Twenty theme</li><li>Admin Email Verification</li><li>Time/Date Component Fixes</li><li>PHP 7.4 Cap</li><li>MinPHP 5.6.20</li></ul>



<p><strong>Mobile</strong></p>



<ul><li>Got Gutenberg on mobile&nbsp;</li><li><strong>Almost</strong> done with offline mode</li><li>DARK MODE 8</li></ul>



<p><strong>Social</strong></p>



<ul><li>141 WordCamps&nbsp;</li><li>About 15 KidsCamp</li><li>HeroPress</li><li>There is going to be a new scholarship to bring more people to WCUS</li></ul>
</div>



<div class=\"wp-block-column\">
<img src=\"https://cdn.poststatus.com/wp-content/uploads/2019/11/blocks.png\" alt=\"\" class=\"wp-image-71109\" />
</div>
</div>



<h3>Let’s Time Travel…</h3>



<div class=\"wp-block-columns has-3-columns\">
<div class=\"wp-block-column\">
<p><strong>A Year Ago</strong></p>



<ul><li>People did not like Gutenberg</li></ul>



<img src=\"https://cdn.poststatus.com/wp-content/uploads/2019/11/GUT.png\" alt=\"\" class=\"wp-image-71110\" />
</div>



<div class=\"wp-block-column\">
<p><strong>Today</strong></p>



<ul><li>They have added motion</li><li>Typewritter mode</li><li>Block previews</li></ul>
</div>



<div class=\"wp-block-column\">
<p><strong>Future</strong></p>



<ul><li>SOCIAL ICONS!!! (This is going to be a Gutenberg block)</li><li>The Navigation block/editor</li><li>GRADIENTS (I’m excited!)</li><li><span>Multi-Button Block</span></li><li>Block Directory&nbsp;</li><li>Block patterns&nbsp;</li></ul>
</div>
</div>



<h3>Community</h3>



<ul><li>There are so many different sites just using the block editor.</li><li>You are able to use Microsoft Word with the new editor using the Copy and Paste method.</li></ul>



<h3>Beyond</h3>



<p>Gutenberg is about 20% done. There are going to be 4 phases of Gutenberg:</p>



<ul><li>Easier Editing</li><li>Customization</li><li>Collaboration</li><li>Multilingual</li></ul>



<h3>Our Path Forward…</h3>



<div class=\"wp-block-columns has-2-columns\">
<div class=\"wp-block-column\">
<ul><li>Help be the change&nbsp;
<ul>
<li>Go to Contributor Day</li>
<li>Design Experiments by the WordPress team.</li>
</ul>
</li><li>More Blocks!
<ul>
<li>Learn JavaScript Deeply.&nbsp;</li>
</ul>
</li><li>Help <strong>Teach the change</strong></li><li>There are meetups everywhere</li><li>Help open the web.&nbsp;</li><li>Five for the future
<ul>
<li><a href=\"http://wordpress.org/5\">wordpress.org/5</a> or <a href=\"http://wordpress.org/five\">wordpress.org/five</a></li>
</ul>
</li></ul>



<p></p>
</div>



<div class=\"wp-block-column\">
<img src=\"https://cdn.poststatus.com/wp-content/uploads/2019/11/path.png\" alt=\"
\" class=\"wp-image-71111\" />
</div>
</div>



<h3>My Thoughts</h3>



<h4>As a young person…</h4>



<p>As I was listening to the talk, I did find some golden gems that I thought my generation might be able to take advantage of and use to the benefit of both our generation and also the WordPress community.</p>



<p>One of those things is the new documentary that shows how open the WordPress Community really is.</p>



<p>Another thing, and yes, I am serious about this, is the fact that they are adding gradients to the WordPress editor for the Gutenberg blocks. I think that addition is going to bring out the artistic side of those of us who do not know how to do gradients in code yet.</p>



<h4>That time I asked Matt Mullenweg a question…</h4>



<p>One of the major things that I did during my WordCamp US trip happened during the Q&A; Session which is right after the State of the Word. I decided to try to ask a question of my own.</p>



<div class=\"wp-block-embed__wrapper\">

</div>Me asking Matt Mullenweg a question



<p>And to summarize, I asked what was Matt’s plan for the inclusion of the next generation of WordPress users. His response to that is the fact that <a href=\"https://poststatus.com/automattic-has-purchased-tumblr/\">Automattic bought Tumblr</a> and is going to turn the back end of their site into a Gutenberg-centric WordPress interface.</p>



<p>I do not think that this is a bad thing. In fact, I think that this is a good thing because of the fact that Tumblr is something that is attracting the younger generation of users.</p>



<p>I think Tumblr’s addition is going to be targeted towards some of the same people who are already using WordPress, and I was just hoping for a start to something that is able to capture a new group of people who are not using Tumblr to blog.</p>



<p>And now I know what you are thinking, <em>Doesn’t KidsCamp already attract the younger generation</em>? I LOVE KidsCamp and everyone and everything to do with KidsCamp. But here is the thing, KidsCamp is something that happens in less than half of the WordCamps inside of the United States, and getting there might be difficult for some parents, especially if they are going to bring their kids with them.</p>



<h3>In conclusion</h3>



<p>The organization of the whole event played out nicely. The media (or the people who tweet the most) got to sit in the front rows for the convenience of taking photos and notes.</p>



<p>There was no line for any of it, therefore we got the chance to fully enjoy the afternoon break that came right before the State of the Word.</p>



<p>I’m glad I got to ask my question to Matt. I think that there are some different ways that different people from the WordPress community are able to step in and help, beyond Tumblr, and beyond KidsCamp.</p>



<p>But that is going to come inside of a different blog post later in the future.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 08 Nov 2019 23:15:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Olivia Bisset\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: Themes of the Future: A Design Framework and a Master Theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95267\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"https://wptavern.com/themes-of-the-future-a-design-framework-and-a-master-theme\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8863:\"<p>WordPress theming has a rich history.  Over the years, theme authors have brought a plethora of features to the platform.  In part, it is because they have often had to solve foundational issues with WordPress to create the features that end users want.</p>



<p>The post and body classes all theme authors use today?  Those were originally in a theme called Sandbox.  </p>



<p>Featured images?  Those were popularized by <em>magazine</em> themes a decade ago.  </p>



<p>You think post formats originated with Tumblr?  Matt Mullenweg, co-creator of WordPress, taught us how to <a href=\"https://ma.tt/2004/05/asides/\">create aside posts</a> in our themes in 2004, but they existed before that.</p>



<p>WordPress features often get their start in the theme world.  We sometimes take for granted the years of experimentation and iteration on ideas where theme authors are putting in the work.  Even the block editor is handling items that have traditionally been within the realm of theme design.  The cover block is a good example.  For years, theme authors built theme options for a basic hero image with text and buttons overlain.  The result was often clunky and not ideal for users.  By bringing this feature into core, it provided users the ability to put this cover block in any permitted block area.</p>



<p>The reason many theme features make it to core is that they simply work better when they are standardized.  Users know what to expect, and theme authors can focus on the design aspect rather than solving the user experience problem.</p>



<p>Part of the problem of the past is that each new feature adopted into core did not follow any standard design pattern or naming scheme.  A huge skill in designing WordPress themes is committing the mish-mash of hundreds of classes to memory.</p>



<p>The block editor is in a unique position to change that by creating a universal design framework.</p>



<h2>Does WordPress Need a Front-End Design Framework?</h2>



<p>With block patterns coming in the future and full-site customization at some point after that, theme authors are wondering just exactly where this ship is sailing.  It is exciting because the possibilities are boundless for end users.  It is frightening for theme authors who have built their empires upon one way of doing things, but development is more about adaptation than anything else.</p>



<p>Armed with the foreknowledge that the landscape is changing, this is the moment theme authors need to band together to shape their futures in a block-based world.</p>



<p>There is a bit of a running joke in one of the developer groups I am involved in that core developers are not theme authors.  From the theme author perspective, it can sometimes seem like ideas are haphazardly thrown together with no thought toward CSS design systems.</p>



<p><em>Oh, I see some BEM.  Why does this sub-element not follow the same naming scheme?  Wait. Is that a 38-character utility class?</em></p>



<p>What WordPress has always lacked is a universal front-end design system.  At times, that has been a good thing.  It has allowed theme authors to use their preferred framework.  Any theme author who has been in the game long enough will tell you, that sort of flexibility is great&hellip;<em>until it is not</em>.  Have you ever tried adding contextual classes to widgets?  What about adding a utility class to the comment form wrapper?  You will need an Aspirin.  Or two.</p>



<p>With WordPress, some things are set in stone and others are pluggable.  Some features follow a standard class-naming scheme and others make no sense.  The result for themes is often bloated CSS in an attempt to wrangle the various components.</p>



<p>It is next to impossible to fully use a utility-class framework like <a href=\"https://tailwindcss.com\">Tailwind CSS</a> in a theme without recreating core features.  </p>



<p>Much of this stems from years of legacy code piling up and WordPress&rsquo; commitment to backward compatibility.  But, the future does not have to resemble the past.  We are at the threshold of a new era, and now is the time for front end designers to jump into the conversation.</p>



<p>WordPress needs a solid front-end design framework.</p>



<p>That is a loaded statement.  If you put 20 designers in a room and ask them to discuss design frameworks, it could be a recipe for fisticuffs.  I tend to be an optimist and hope the debate provided results.</p>



<p>Gutenberg has pushed us partially in this direction, but it does not quite go far enough.  With full-site editing in the future, there is a need for a more holistic approach in tackling this problem.</p>



<p>More than anything, we need more front end designers in the conversation.  There is no way <code>.has-subtle-pale-green-background-color</code> should exist as a utility class over something like <code>.bg-pale-green</code>, <code>.bg-green-100</code>, or even <code>.background-pale-green</code>, if you want to be more verbose.  There was no concept of optimization that went into that decision.  In a time where developers are running on gigabyte internet connections, it is easy to forget that much of the world is following along at a slower pace.</p>



<p>A component-based naming scheme with a healthy dose of utility classes is one option that could hit several sweet spots.  This is not an argument for one CSS framework over another.  There are many good, existing options.  WordPress should tackle this head on by borrowing from the groundwork laid down by other projects and creating something uniquely WordPress.  It should be a leader in the field.</p>



<p>Design frameworks are also about plugins.  There is some crossover into the realm of themes where the two have been waging an ongoing war since the dawn of the theme system.  The battlefield between themes and plugins is littered with the deaths of good ideas.  Far too many never garnered the support they needed to land in core.  Some sort of universal design standard could stanch the flood of issues and call for a cease-fire.</p>



<p>A plugin that outputs a custom front-end component has no way of knowing how the current theme handles vertical rhythm, for example. <em>Does it use top or bottom margin? What is the value and unit used?</em>  This is foundational stuff, and it is almost always broken when the plugin attempts to add custom CSS to handle it.</p>



<p>WordPress needs a design framework, or language, that allows all of its moving parts to come together in harmony on the front end.  I am sure we will get there at some point.  I hope that it is more cohesive than the random components and naming schemes of the past.  We should also have a clear roadmap that fills in some of the technical details so developers and designers might be prepared.</p>



<h2>Is a One-Theme Future Possible?</h2>



<p>Rich Tabor makes the argument that core WordPress could provide a single parent theme in his article <a href=\"https://richtabor.com/the-future-of-wordpress-themes/\">A Look at WordPress Themes of the Future</a>.  The idea is that theme authors would be relegated to creating a child theme for this &ldquo;master&rdquo; theme.</p>



<p>The gut reaction for many would be that it would not work, themes would lose their personality and we would live in a world of cookie-cutter designs.  </p>



<p>The reality is that we are barreling toward a future where the idea of a single parent or master theme is a serious consideration.  </p>



<p>Most themes are custom groupings of standard elements that exist in nearly all themes.  There are some decisions, aside from stylistic concerns, that make themes different from one another, such as the layout of the header.  One theme might have a site title and nav menu in one block.  Another might have a nav menu, title, and a second nav menu below.  Yet, another theme might show a search box.  In a world where full-site customization belongs to the user, those decisions become a part of the user experience rather than the developer experience.</p>



<p>Themes will need to stand out with color palettes, typography, and their own brand of quirkiness &mdash; a return of the days of <a href=\"http://csszengarden.com/\">CSS Zen Garden</a> but on a much larger scale.</p>



<p>I won&rsquo;t be sad about that.  It would be interesting to see the competition between the top designers in the field.  It may also bring WordPress theming back to an era when anyone could do it with a little CSS knowledge and determination.</p>



<p>While we are not quite ready for a future in which one theme rules theme all, it is a place to start the conversation.  If we designed WordPress for this potential future, even if we never implement a master theme, what would the roadmap look like?  What obstacles stand in the way?  Is it feasible?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 08 Nov 2019 21:13:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"WPTavern: Oklahoma Watch Becomes First U.S. Publication on Newspack; 34 Pilot Newsrooms Announced for Second Round\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95252\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:123:\"https://wptavern.com/oklahoma-watch-becomes-first-u-s-publication-on-newspack-34-pilot-newsrooms-announced-for-second-round\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7869:\"<div class=\"wp-block-image\"><img />Homepage of the Oklahoma Watch website on Newspack.</div>



<p><a href=\"https://oklahomawatch.org/\">Oklahoma Watch</a> is the first U.S. publication to relaunch and the second publication to go live on Newspack, a platform created this year to bring WordPress to newsrooms.  Newspack <a href=\"https://newspack.blog/2019/11/07/newspack-announces-second-set-of-pilot-newsrooms-first-u-s-site-relaunches-on-new-platform/\">announced the relaunch</a> today.  The announcement includes the list of 34 new publications that will work with the Newspack team during its second phase.</p>



<p>Newspack is a project of Automattic, the parent company of WordPress.com. Its mission is to create a platform for more newsrooms to make the move to WordPress.  The team has been working alongside industry leaders and small publications during the pilot program this year to tackle issues with running online newsrooms.</p>



<p>Chilean news site El Soberano was the first newsroom to go live on the new system, <a href=\"https://wptavern.com/chilean-news-publication-el-soberano-first-to-launch-on-newspack\">relaunching their site</a> on October 16.  Oklahoma Watch follows them as only the second publication to take the next step.  The remaining participants in the pilot program are expected to launch in the coming weeks.</p>



<p>Oklahoma Watch is a non-partisan publication that does not publish opinion pieces.  It is a nonprofit news organization that covers stories on public-policy issues within the state of Oklahoma.  &ldquo;Those include education, criminal justice, public and mental health, state government, poverty, and human-needs issues that disproportionately affect women, children, and the disadvantaged,&rdquo; said executive editor David Fritze.  &ldquo;Our staples are in-depth stories, searchable data, interactives, public forums, live-tweeting and other social media, and, increasingly, video.&rdquo;</p>



<p>The publication distributes its stories for free republication to around 100 newspapers and radio and TV news outlets throughout the state.</p>



<h2>Oklahoma Watch&rsquo;s Move to Newspack</h2>



<p>In 2013, the Oklahoma Watch site moved to <a href=\"https://largo.inn.org/\">Largo</a>, a WordPress theme framework for news publishers.  It is developed and maintained by the Institute for Nonprofit News.</p>



<p>&ldquo;Our website was clean and bright, but was rather monotonous, with a long stack of same-sized headlines, excerpts and a right sidebar with typical fixtures, such as a newsletter sign-up ask and our Twitter feed,&rdquo; said Fritze.  After bringing on a visual journalist to bring the site up to date with media, they still felt tools were limited and needed a site refresh.</p>



<p>&ldquo;We went live with Newspack more than a week ago, and we&rsquo;re still gradually digging around &mdash; spelunking in a way &mdash; to learn how to make the most of it,&rdquo; said Fritze.  &ldquo;But I would say it already has and will make a world of difference.&rdquo;</p>



<p>He sent the following update to the publication&rsquo;s email subscribers.</p>



<blockquote class=\"wp-block-quote\"><p>[Newspack] gives smaller organizations more tools to deliver their content in engaging, creative ways. What you will notice: a faster mobile experience; a better showcasing of visuals, stories, and informational bits, and a more vibrant, flexible home page &ndash; with new features to come. The goal is to make oklahomawatch.org a richer experience for you and to enhance the investigative reporting that is central to our mission.</p></blockquote>



<p>The team switched from the classic editor and has been learning the block editor (Gutenberg) along with the Newspack tools.  Fritze said the team is happy about:</p>



<ul><li>Being able to serve donation and subscription forms anywhere.</li><li>Having the ability to more easily manage their homepage content, media, and headlines.</li><li>Making changes without spending valuable time that would be better spent investigating stories.</li></ul>



<p>As part of the initial pilot program, Oklahoma Watch was in a unique position to help make this an easier process for future publications on the platform.  &ldquo;We were fortunate to be a pilot site and have the full let&rsquo;s-develop-this attention of the Newspack team &mdash; on Slack, in regular video conference calls, in emails, and by phone,&rdquo; said Fritze.</p>



<p>&ldquo;Early on, it became clear that some of the news sites&rsquo; reps were more well-versed in web tech and other programs than we were, so it took me a while to get my bearings,&rdquo; said Fritze of the process. &ldquo;But I requested specific features and preservation of one or two of the tools we already have and prefer.&rdquo;  One such tool was the <a href=\"https://tablepress.org/\">TablePress plugin</a>.  The Oklahoma Watch team uses it to display interactive, tabular data from CSV files.</p>



<p>Fritze said he had a few requests for other features that are still pending, such as a film-strip-like homepage carousel.  However, the Newspack team was clear from the outset that not all plugins or features would be adopted for the system.</p>



<p>&ldquo;Perhaps that would give some clients pause, not being able to pull any fish you wanted out of the sea of WordPress plugins, based on some mention on the web,&rdquo; said Fritze.  &ldquo;On the other hand, the quality control is reassuring, especially for smaller organizations like ours that have little time to go kicking those tires.&rdquo;</p>



<p>In any controlled system, it makes sense that not every feature request will be granted.  It would increase the quality control burden.  However, without more control over tools or features, it could be a non-starter for some publications.</p>



<p>Fritze does have a big feature request for the long term.  &ldquo;If there is one thing that Newspack should make sure happens going forward, it&rsquo;s to promote easy interaction among Newspack sites, including the ability to communicate one on one and find peer sites that have similar needs and challenges,&rdquo; he said.</p>



<h2>Second Round of Pilot Newsrooms Announced</h2>



<p>Oklahoma Watch and the 11 other newsrooms currently in the program are being followed by a larger group of publications.  The 34 new sites will have the benefit of the past seven months of work the Newspack team and pilot newsrooms put into the initial launch.  Newsrooms in the second phase are expected to relaunch their sites on the platform by the end of February 2020.</p>



<p>Publications such as the <a href=\"https://www.hongkongfp.com/\">Hong Kong Free Press</a>, <a href=\"https://mlk50.com\">MLK50: Justice Through Journalism</a>, and <a href=\"https://www.dailyyonder.com/\">The Daily Yonder</a> are a part of the second group.  Most are small or medium-sized publications that focus on local news.  The full list is <a href=\"https://newspack.blog/2019/11/07/newspack-announces-second-set-of-pilot-newsrooms-first-u-s-site-relaunches-on-new-platform/\">available via the announcement post</a> on the Newspack blog.</p>



<p>Like the first group, the new newsrooms will work directly with the Newspack team to identify and address technical issues faced in online journalism.  They will continue helping to design and test the platform&rsquo;s features.</p>



<p>All pilot newsrooms will continue using Newspack for free until March 2020.  After that point, the price will jump to $1,000 per month.  The price includes priority access to Newspack developers, some level of premium support, quarterly benchmarking reports, and community membership with other Newspack users.</p>



<p>The Newspack team plans to consider additional applications in January 2020.  Nearly 500 applicants have applied for the program thus far.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 Nov 2019 18:50:49 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: The Power of Stories: Chris Lema and the Bridge Framework\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"https://wptavern.com/?p=95240\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://wptavern.com/the-power-of-stories-chris-lema-and-the-bridge-framework\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5474:\"<p>I would tell you that when Chris Lema, VP of Products at Liquid Web, is speaking, you should listen.  But, there is no need to say that.  He has an infectious quality that grabs your attention and doesn&#8217;t let go.  I found myself hanging onto every word in his session, <a href=\"https://2019.us.wordcamp.org/session/the-content-framework-that-powers-stories-landing-pages-more/\">The Content Framework that Powers Stories, Landing Pages, &amp; More</a>, via the WordCamp U.S. livestream this past weekend.</p>



<p>Telling stories is a uniquely human trait.  Our ability to weave narratives together is what separates us from lower animals.  Sure, other important things such as the ability to make fire, understand advanced mathematics, and build rocket-powered ships all set us apart.  But, it is the stories we tell that are the most interesting things about us as a species.</p>



<p>Any good story leaves you waiting to see what will happen next and how the people within those stories react.  How they grow.  How they change.</p>



<p>This fundamental human activity was at the heart of Lema&#8217;s 15-minute presentation.  &#8220;When people believe that you&#8217;ve been where they are and can see that you&#8217;ve gotten to the other side, they will follow,&#8221; said Lema of selling products.</p>



<p>Ultimately, the bridge framework is about guiding others through your journey and helping them cross the bridge you have found.  This framework can apply to your brand, your products, or any other content that you are providing to others.</p>



<p>One thing product makers often fail at is providing a solution before sharing how they have encountered the same problem.  &#8220;No one feels like they need a bridge until they are facing a river,&#8221; said Lema.  The struggle must come first.</p>



<h2>What Comes After the Product</h2>



<p>In 2007, I built one of the most popular themes ever in WordPress&#8217; short history.  It does not matter what theme it was.  It is long retired.  What mattered was it helped users get to their destination.</p>



<p>One theme user who stood out was building a Formula 1 racing website.  I was a mediocre designer at best, but this user would create some of the most beautiful customizations that I had ever seen.  It seemed like he would change the design every week.  Each time, I was in awe at his talent.  He continued using this same theme of mine for years, even after I archived it and moved onto other theme projects.</p>



<p>What I should have learned during those years was, without knowing, I had the story right.  I knew the technical aspects of why this specific theme was a leap forward.  However, I didn&#8217;t understand the story I was telling users was drawing people in.</p>



<p>I had been where they were.  I had struggled to get to where I was going.  I had braved the journey beyond that point and found a path for others to join me.</p>



<p>As time moved on, I became a better developer.  I had one more insanely popular theme.  Again, it was about the story.  I could recognize the problems.  I had the same frustrations as others.  I had a way to fix those problems and get people from Point A to Point B.  I invited others along.  I told them I would be there every step of the way.</p>



<p>I never recreated that early success with another theme, at least not on the same scale.</p>



<p>I stopped focusing on what mattered.</p>



<p>I marketed future themes based far too much on the technical aspects.  Essentially, I was flaunting my development skills.  After years of lucking into success by being a storyteller, I tried to follow the trends of others who were marketing their HTML5, CSS3, or whatever other keyword was popular at the time.</p>



<p>Fortunately, I had loyal users who stuck with me over the years.  There was one theme user who would often switch themes whenever I released a new one.  Like the racing enthusiast, this person would put his own spin on the design.  He used the themes on his photography site.  What was interesting about some of the themes was they were not specifically built with photography in mind.  That was never my goal when creating them.</p>



<p><em>What was it that made this user continue using different themes of mine?</em></p>



<p>It was never about all the bells and whistles.  Many of them were unused on the site.  It was about what came after activating the theme.  It wasn&#8217;t about me.  It was about the user being able to tell his own story through photos.</p>



<p>In hindsight, I could see that the projects I achieved the most success with were the projects I was the most passionate about.  I had built them to solve specific problems.  The technical details did not matter.  I had built or found a bridge to get to the place that I wanted to be.  My excitement and passion naturally transferred to how I spoke about those projects.  It changed how I sold them to users.  I told my story.</p>



<p>The biggest failures I had were when I did not have a good story to tell.</p>



<h2>Watch Chris Lema&#8217;s Speech</h2>



<p>For those that are running any type of business, you owe it to yourselves to listen to Lema explain how to connect with customers.</p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p><em>Lema&#8217;s session starts at the 2:59:46 mark if the videos doesn&#8217;t start at the correct point. The embedded video should begin at his introduction.</em></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Nov 2019 17:53:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Justin Tadlock\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Matt: State of the Word 2019\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"https://ma.tt/?p=50414\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://ma.tt/2019/11/state-of-the-word-2019/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2061:\"<p>In case you missed it, here&#8217;s the first-ever State of the Word&#8230; designed completely in Gutenberg: </p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p><a href=\"https://2019.us.wordcamp.org/\">WordCamp US</a> was a fantastic experience, as always. Thank you again to the hundreds of organizers and volunteers who made it happen, to the thousands who attended, and to the city of St. Louis for hosting us. We&#8217;ll be back there again next year.</p>



<p>And special thanks to this next generation of WordPress contributors. So exciting to see <a href=\"https://2019.us.wordcamp.org/kidscamp/\">KidsCamps</a> continue to expand and thrive:</p>



<div class=\"wp-block-embed__wrapper\">
<blockquote class=\"twitter-tweet\"><p lang=\"en\" dir=\"ltr\">Thank you <a href=\"https://twitter.com/photomatt?ref_src=twsrc%5Etfw\">@photomatt</a> for stopping by KidsCamp today. The kids loved your visit! <a href=\"https://twitter.com/hashtag/WordPress?src=hash&ref_src=twsrc%5Etfw\">#WordPress</a> <a href=\"https://twitter.com/hashtag/KidsCamp?src=hash&ref_src=twsrc%5Etfw\">#KidsCamp</a> <a href=\"https://twitter.com/hashtag/WCUS?src=hash&ref_src=twsrc%5Etfw\">#WCUS</a> <a href=\"https://t.co/cq65sHkjsI\">pic.twitter.com/cq65sHkjsI</a></p>&mdash; Sandy Edwards (@sunsanddesign) <a href=\"https://twitter.com/sunsanddesign/status/1191093861172559873?ref_src=twsrc%5Etfw\">November 3, 2019</a></blockquote>
</div>



<p>As you can see, my site is now featuring the new <a href=\"https://make.wordpress.org/core/2019/09/06/introducing-twenty-twenty/\">WordPress Twenty Twenty theme</a>. And for more coverage from my State of the Word, check out the recaps from <a href=\"https://wptavern.com/state-of-the-word-2019-recap-all-roads-lead-to-the-block-editor\">WP Tavern</a> and <a href=\"https://poststatus.com/matt-mullenweg-state-of-the-word-2019/\">Post Status</a>. Here&#8217;s my full audience Q&amp;A below: </p>



<div class=\"wp-block-embed__wrapper\">

</div>



<p>You can see my previous <a href=\"https://ma.tt/tag/sotw/\">State of the Word keynotes here</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Nov 2019 06:38:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";O:42:\"Requests_Utility_CaseInsensitiveDictionary\":1:{s:7:\"\0*\0data\";a:8:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Tue, 17 Dec 2019 14:41:39 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Tue, 17 Dec 2019 14:30:08 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:9:\"HIT ord 2\";s:16:\"content-encoding\";s:4:\"gzip\";}}s:5:\"build\";s:14:\"20130911040210\";}","no");
INSERT INTO `wp_options` VALUES("140","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1576636900","no");
INSERT INTO `wp_options` VALUES("141","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1576593700","no");
INSERT INTO `wp_options` VALUES("142","_transient_timeout_dash_v2_f69de0bbfe7eaa113146875f40c02000","1576636900","no");
INSERT INTO `wp_options` VALUES("143","_transient_dash_v2_f69de0bbfe7eaa113146875f40c02000","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ru.wordpress.org/news/2019/11/2019-annual-survey/\'>Ежегодный опрос пользователей и разработчиков WordPress 2019</a></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://ma.tt/2019/12/comments-and-collatz-conundrum/\'>Matt: Comments and Collatz Conundrum</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/slim-seo-keeps-options-simple-and-handles-the-legwork-of-seo\'>WPTavern: Slim SEO Keeps Options Simple and Handles the Legwork of SEO</a></li><li><a class=\'rsswidget\' href=\'https://wptavern.com/inserting-special-characters-into-the-block-editor\'>WPTavern: Inserting Special Characters Into the Block Editor</a></li></ul></div>","no");
INSERT INTO `wp_options` VALUES("144","_transient_timeout_plugin_slugs","1576682026","no");
INSERT INTO `wp_options` VALUES("145","_transient_plugin_slugs","a:3:{i:0;s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";i:1;s:33:\"classic-editor/classic-editor.php\";i:2;s:24:\"wordpress-seo/wp-seo.php\";}","no");
INSERT INTO `wp_options` VALUES("146","recently_activated","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("147","ftp_credentials","a:3:{s:8:\"hostname\";s:9:\"127.0.1.1\";s:8:\"username\";s:5:\"admin\";s:15:\"connection_type\";s:3:\"ftp\";}","yes");
INSERT INTO `wp_options` VALUES("148","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1576604620","no");
INSERT INTO `wp_options` VALUES("149","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","O:8:\"stdClass\":100:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";i:4650;}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";i:3807;}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";i:2651;}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";i:2531;}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";i:1946;}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";i:1779;}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";i:1760;}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";i:1475;}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";i:1460;}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";i:1450;}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";i:1441;}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";i:1397;}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";i:1373;}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";i:1296;}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";i:1163;}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";i:1147;}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";i:1114;}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";i:1078;}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";i:1072;}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";i:972;}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";i:863;}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";i:853;}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";i:851;}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";i:832;}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";i:767;}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";i:757;}s:10:\"e-commerce\";a:3:{s:4:\"name\";s:10:\"e-commerce\";s:4:\"slug\";s:10:\"e-commerce\";s:5:\"count\";i:744;}s:6:\"slider\";a:3:{s:4:\"name\";s:6:\"slider\";s:4:\"slug\";s:6:\"slider\";s:5:\"count\";i:742;}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";i:738;}s:9:\"analytics\";a:3:{s:4:\"name\";s:9:\"analytics\";s:4:\"slug\";s:9:\"analytics\";s:5:\"count\";i:721;}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";i:709;}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";i:694;}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";i:692;}s:4:\"form\";a:3:{s:4:\"name\";s:4:\"form\";s:4:\"slug\";s:4:\"form\";s:5:\"count\";i:684;}s:6:\"search\";a:3:{s:4:\"name\";s:6:\"search\";s:4:\"slug\";s:6:\"search\";s:5:\"count\";i:671;}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";i:657;}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";i:640;}s:4:\"menu\";a:3:{s:4:\"name\";s:4:\"menu\";s:4:\"slug\";s:4:\"menu\";s:5:\"count\";i:637;}s:8:\"category\";a:3:{s:4:\"name\";s:8:\"category\";s:4:\"slug\";s:8:\"category\";s:5:\"count\";i:628;}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"ajax\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";i:622;}s:6:\"editor\";a:3:{s:4:\"name\";s:6:\"editor\";s:4:\"slug\";s:6:\"editor\";s:5:\"count\";i:620;}s:5:\"embed\";a:3:{s:4:\"name\";s:5:\"embed\";s:4:\"slug\";s:5:\"embed\";s:5:\"count\";i:607;}s:3:\"css\";a:3:{s:4:\"name\";s:3:\"css\";s:4:\"slug\";s:3:\"css\";s:5:\"count\";i:579;}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";i:577;}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";i:569;}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";i:567;}s:12:\"contact-form\";a:3:{s:4:\"name\";s:12:\"contact form\";s:4:\"slug\";s:12:\"contact-form\";s:5:\"count\";i:563;}s:5:\"share\";a:3:{s:4:\"name\";s:5:\"share\";s:4:\"slug\";s:5:\"share\";s:5:\"count\";i:549;}s:5:\"theme\";a:3:{s:4:\"name\";s:5:\"theme\";s:4:\"slug\";s:5:\"theme\";s:5:\"count\";i:539;}s:7:\"comment\";a:3:{s:4:\"name\";s:7:\"comment\";s:4:\"slug\";s:7:\"comment\";s:5:\"count\";i:538;}s:7:\"payment\";a:3:{s:4:\"name\";s:7:\"payment\";s:4:\"slug\";s:7:\"payment\";s:5:\"count\";i:536;}s:10:\"responsive\";a:3:{s:4:\"name\";s:10:\"responsive\";s:4:\"slug\";s:10:\"responsive\";s:5:\"count\";i:532;}s:9:\"dashboard\";a:3:{s:4:\"name\";s:9:\"dashboard\";s:4:\"slug\";s:9:\"dashboard\";s:5:\"count\";i:527;}s:9:\"affiliate\";a:3:{s:4:\"name\";s:9:\"affiliate\";s:4:\"slug\";s:9:\"affiliate\";s:5:\"count\";i:524;}s:6:\"custom\";a:3:{s:4:\"name\";s:6:\"custom\";s:4:\"slug\";s:6:\"custom\";s:5:\"count\";i:523;}s:3:\"ads\";a:3:{s:4:\"name\";s:3:\"ads\";s:4:\"slug\";s:3:\"ads\";s:5:\"count\";i:517;}s:10:\"categories\";a:3:{s:4:\"name\";s:10:\"categories\";s:4:\"slug\";s:10:\"categories\";s:5:\"count\";i:507;}s:4:\"user\";a:3:{s:4:\"name\";s:4:\"user\";s:4:\"slug\";s:4:\"user\";s:5:\"count\";i:490;}s:7:\"contact\";a:3:{s:4:\"name\";s:7:\"contact\";s:4:\"slug\";s:7:\"contact\";s:5:\"count\";i:487;}s:3:\"api\";a:3:{s:4:\"name\";s:3:\"api\";s:4:\"slug\";s:3:\"api\";s:5:\"count\";i:486;}s:4:\"tags\";a:3:{s:4:\"name\";s:4:\"tags\";s:4:\"slug\";s:4:\"tags\";s:5:\"count\";i:483;}s:6:\"button\";a:3:{s:4:\"name\";s:6:\"button\";s:4:\"slug\";s:6:\"button\";s:5:\"count\";i:481;}s:15:\"payment-gateway\";a:3:{s:4:\"name\";s:15:\"payment gateway\";s:4:\"slug\";s:15:\"payment-gateway\";s:5:\"count\";i:469;}s:5:\"users\";a:3:{s:4:\"name\";s:5:\"users\";s:4:\"slug\";s:5:\"users\";s:5:\"count\";i:466;}s:6:\"mobile\";a:3:{s:4:\"name\";s:6:\"mobile\";s:4:\"slug\";s:6:\"mobile\";s:5:\"count\";i:461;}s:6:\"events\";a:3:{s:4:\"name\";s:6:\"events\";s:4:\"slug\";s:6:\"events\";s:5:\"count\";i:453;}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";i:434;}s:9:\"slideshow\";a:3:{s:4:\"name\";s:9:\"slideshow\";s:4:\"slug\";s:9:\"slideshow\";s:5:\"count\";i:426;}s:9:\"gutenberg\";a:3:{s:4:\"name\";s:9:\"gutenberg\";s:4:\"slug\";s:9:\"gutenberg\";s:5:\"count\";i:423;}s:9:\"marketing\";a:3:{s:4:\"name\";s:9:\"marketing\";s:4:\"slug\";s:9:\"marketing\";s:5:\"count\";i:422;}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";i:420;}s:10:\"navigation\";a:3:{s:4:\"name\";s:10:\"navigation\";s:4:\"slug\";s:10:\"navigation\";s:5:\"count\";i:420;}s:5:\"stats\";a:3:{s:4:\"name\";s:5:\"stats\";s:4:\"slug\";s:5:\"stats\";s:5:\"count\";i:417;}s:4:\"chat\";a:3:{s:4:\"name\";s:4:\"chat\";s:4:\"slug\";s:4:\"chat\";s:5:\"count\";i:417;}s:8:\"calendar\";a:3:{s:4:\"name\";s:8:\"calendar\";s:4:\"slug\";s:8:\"calendar\";s:5:\"count\";i:415;}s:10:\"statistics\";a:3:{s:4:\"name\";s:10:\"statistics\";s:4:\"slug\";s:10:\"statistics\";s:5:\"count\";i:407;}s:5:\"popup\";a:3:{s:4:\"name\";s:5:\"popup\";s:4:\"slug\";s:5:\"popup\";s:5:\"count\";i:403;}s:10:\"newsletter\";a:3:{s:4:\"name\";s:10:\"newsletter\";s:4:\"slug\";s:10:\"newsletter\";s:5:\"count\";i:397;}s:10:\"shortcodes\";a:3:{s:4:\"name\";s:10:\"shortcodes\";s:4:\"slug\";s:10:\"shortcodes\";s:5:\"count\";i:390;}s:4:\"news\";a:3:{s:4:\"name\";s:4:\"news\";s:4:\"slug\";s:4:\"news\";s:5:\"count\";i:388;}s:5:\"forms\";a:3:{s:4:\"name\";s:5:\"forms\";s:4:\"slug\";s:5:\"forms\";s:5:\"count\";i:384;}s:12:\"social-media\";a:3:{s:4:\"name\";s:12:\"social media\";s:4:\"slug\";s:12:\"social-media\";s:5:\"count\";i:382;}s:4:\"code\";a:3:{s:4:\"name\";s:4:\"code\";s:4:\"slug\";s:4:\"code\";s:5:\"count\";i:375;}s:8:\"redirect\";a:3:{s:4:\"name\";s:8:\"redirect\";s:4:\"slug\";s:8:\"redirect\";s:5:\"count\";i:372;}s:14:\"contact-form-7\";a:3:{s:4:\"name\";s:14:\"contact form 7\";s:4:\"slug\";s:14:\"contact-form-7\";s:5:\"count\";i:371;}s:7:\"plugins\";a:3:{s:4:\"name\";s:7:\"plugins\";s:4:\"slug\";s:7:\"plugins\";s:5:\"count\";i:370;}s:9:\"multisite\";a:3:{s:4:\"name\";s:9:\"multisite\";s:4:\"slug\";s:9:\"multisite\";s:5:\"count\";i:366;}s:3:\"url\";a:3:{s:4:\"name\";s:3:\"url\";s:4:\"slug\";s:3:\"url\";s:5:\"count\";i:361;}s:4:\"meta\";a:3:{s:4:\"name\";s:4:\"meta\";s:4:\"slug\";s:4:\"meta\";s:5:\"count\";i:353;}s:11:\"performance\";a:3:{s:4:\"name\";s:11:\"performance\";s:4:\"slug\";s:11:\"performance\";s:5:\"count\";i:352;}s:4:\"list\";a:3:{s:4:\"name\";s:4:\"list\";s:4:\"slug\";s:4:\"list\";s:5:\"count\";i:349;}s:12:\"notification\";a:3:{s:4:\"name\";s:12:\"notification\";s:4:\"slug\";s:12:\"notification\";s:5:\"count\";i:343;}s:8:\"tracking\";a:3:{s:4:\"name\";s:8:\"tracking\";s:4:\"slug\";s:8:\"tracking\";s:5:\"count\";i:334;}s:16:\"custom-post-type\";a:3:{s:4:\"name\";s:16:\"custom post type\";s:4:\"slug\";s:16:\"custom-post-type\";s:5:\"count\";i:330;}s:16:\"google-analytics\";a:3:{s:4:\"name\";s:16:\"google analytics\";s:4:\"slug\";s:16:\"google-analytics\";s:5:\"count\";i:330;}s:11:\"advertising\";a:3:{s:4:\"name\";s:11:\"advertising\";s:4:\"slug\";s:11:\"advertising\";s:5:\"count\";i:327;}s:5:\"cache\";a:3:{s:4:\"name\";s:5:\"cache\";s:4:\"slug\";s:5:\"cache\";s:5:\"count\";i:322;}s:6:\"simple\";a:3:{s:4:\"name\";s:6:\"simple\";s:4:\"slug\";s:6:\"simple\";s:5:\"count\";i:320;}s:4:\"html\";a:3:{s:4:\"name\";s:4:\"html\";s:4:\"slug\";s:4:\"html\";s:5:\"count\";i:319;}s:6:\"author\";a:3:{s:4:\"name\";s:6:\"author\";s:4:\"slug\";s:6:\"author\";s:5:\"count\";i:317;}}","no");
INSERT INTO `wp_options` VALUES("155","_site_transient_timeout_available_translations","1576605067","no");
INSERT INTO `wp_options` VALUES("156","_site_transient_available_translations","a:121:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-05 08:33:42\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-03 13:14:07\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.13\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.13/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-09 18:38:27\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:6:\"4.8.12\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.8.12/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-05 13:54:33\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-10-25 20:23:36\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.5/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-15 19:05:13\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-29 07:15:52\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-10 11:38:15\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-15 20:45:17\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-03 13:57:52\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:3:\"5.3\";s:7:\"updated\";s:19:\"2019-11-14 11:38:17\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-02 11:15:22\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.3.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 08:02:09\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 08:02:56\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.3.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-13 08:22:32\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 17:04:17\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 17:31:58\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 21:30:20\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.1.3\";s:7:\"updated\";s:19:\"2019-06-06 15:48:01\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.3/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 21:29:53\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-20 20:46:03\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.3/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 17:28:06\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-12 22:01:17\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 19:50:32\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-09 21:40:46\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_UY\";a:8:{s:8:\"language\";s:5:\"es_UY\";s:7:\"version\";s:3:\"5.3\";s:7:\"updated\";s:19:\"2019-11-12 04:43:11\";s:12:\"english_name\";s:17:\"Spanish (Uruguay)\";s:11:\"native_name\";s:19:\"Español de Uruguay\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3/es_UY.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"5.3\";s:7:\"updated\";s:19:\"2019-11-14 16:08:46\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-12-07 04:01:34\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.5/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-13 07:26:18\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:9:\"5.0-beta3\";s:7:\"updated\";s:19:\"2018-11-28 16:04:33\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0-beta3/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-08 17:55:03\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-06 20:09:43\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-02 09:08:55\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-02 12:30:18\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-06 09:23:29\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-01 17:58:42\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-05 10:25:55\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-13 12:23:33\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:3:\"hsb\";a:8:{s:8:\"language\";s:3:\"hsb\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 17:22:10\";s:12:\"english_name\";s:13:\"Upper Sorbian\";s:11:\"native_name\";s:17:\"Hornjoserbšćina\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.3.1/hsb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"hsb\";i:3;s:3:\"hsb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:4:\"Dale\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-19 14:36:40\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-07-28 13:16:13\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-29 12:18:19\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-13 00:31:40\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:5:\"5.1.4\";s:7:\"updated\";s:19:\"2019-11-04 08:57:25\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.4/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-09 07:34:10\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.3/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.13\";s:7:\"updated\";s:19:\"2019-12-04 12:22:34\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.13/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-11-05 01:54:57\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.5/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-10-19 19:23:46\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.5/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:6:\"4.7.15\";s:7:\"updated\";s:19:\"2019-05-10 10:24:08\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.15/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-09-08 12:57:25\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.3/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.8.11\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.11/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 16:57:42\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-13 07:08:00\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 17:51:33\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-15 20:22:22\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.3.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-10-24 08:39:27\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.5/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-04 22:00:41\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-04 21:18:26\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-14 08:20:00\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-17 12:00:58\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 20:02:36\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:69:\"https://downloads.wordpress.org/translation/core/5.3.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-30 11:34:07\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-11-28 17:06:16\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:3:\"snd\";a:8:{s:8:\"language\";s:3:\"snd\";s:7:\"version\";s:3:\"5.3\";s:7:\"updated\";s:19:\"2019-11-12 04:37:38\";s:12:\"english_name\";s:6:\"Sindhi\";s:11:\"native_name\";s:8:\"سنڌي\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/translation/core/5.3/snd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"sd\";i:2;s:2:\"sd\";i:3;s:3:\"snd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"اڳتي هلو\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-02 07:46:23\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.2.3\";s:7:\"updated\";s:19:\"2019-06-26 11:40:37\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.2.3/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-14 22:44:44\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-15 22:50:02\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-12 07:05:13\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"sw\";a:8:{s:8:\"language\";s:2:\"sw\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-10-22 00:19:41\";s:12:\"english_name\";s:7:\"Swahili\";s:11:\"native_name\";s:9:\"Kiswahili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.5/sw.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sw\";i:2;s:3:\"swa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Endelea\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.2.4\";s:7:\"updated\";s:19:\"2019-10-19 08:19:37\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.4/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-02 13:03:05\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.2.5\";s:7:\"updated\";s:19:\"2019-10-16 10:31:10\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.2.5/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.1.4\";s:7:\"updated\";s:19:\"2019-03-31 10:39:40\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.4/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-23 12:32:40\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.3/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-07 15:52:24\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.3.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-08 21:26:25\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.3.1\";s:7:\"updated\";s:19:\"2019-12-05 18:52:45\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.3.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.2.4\";s:7:\"updated\";s:19:\"2019-10-01 15:59:49\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.2.4/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","no");
INSERT INTO `wp_options` VALUES("157","new_admin_email","Email@mail.com","yes");
INSERT INTO `wp_options` VALUES("168","aiowpsec_db_version","1.9","yes");
INSERT INTO `wp_options` VALUES("169","aio_wp_security_configs","a:94:{s:19:\"aiowps_enable_debug\";s:0:\"\";s:36:\"aiowps_remove_wp_generator_meta_info\";s:1:\"1\";s:25:\"aiowps_prevent_hotlinking\";s:1:\"1\";s:28:\"aiowps_enable_login_lockdown\";s:1:\"1\";s:28:\"aiowps_allow_unlock_requests\";s:0:\"\";s:25:\"aiowps_max_login_attempts\";i:3;s:24:\"aiowps_retry_time_period\";i:5;s:26:\"aiowps_lockout_time_length\";i:60;s:28:\"aiowps_set_generic_login_msg\";s:0:\"\";s:26:\"aiowps_enable_email_notify\";s:0:\"\";s:20:\"aiowps_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_enable_forced_logout\";s:0:\"\";s:25:\"aiowps_logout_time_period\";s:2:\"60\";s:39:\"aiowps_enable_invalid_username_lockdown\";s:0:\"\";s:43:\"aiowps_instantly_lockout_specific_usernames\";a:0:{}s:32:\"aiowps_unlock_request_secret_key\";s:20:\"9boae3otjbi5x7b7q6kf\";s:26:\"aiowps_enable_whitelisting\";s:0:\"\";s:27:\"aiowps_allowed_ip_addresses\";s:0:\"\";s:27:\"aiowps_enable_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_custom_login_captcha\";s:1:\"1\";s:25:\"aiowps_captcha_secret_key\";s:20:\"aew2zhy60o1lbci0frvd\";s:42:\"aiowps_enable_manual_registration_approval\";s:1:\"1\";s:39:\"aiowps_enable_registration_page_captcha\";s:1:\"1\";s:27:\"aiowps_enable_random_prefix\";s:0:\"\";s:31:\"aiowps_enable_automated_backups\";s:1:\"1\";s:26:\"aiowps_db_backup_frequency\";i:2;s:25:\"aiowps_db_backup_interval\";s:1:\"2\";s:26:\"aiowps_backup_files_stored\";i:1;s:32:\"aiowps_send_backup_email_address\";s:0:\"\";s:27:\"aiowps_backup_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_disable_file_editing\";s:1:\"1\";s:37:\"aiowps_prevent_default_wp_file_access\";s:1:\"1\";s:22:\"aiowps_system_log_file\";s:9:\"error_log\";s:26:\"aiowps_enable_blacklisting\";s:0:\"\";s:26:\"aiowps_banned_ip_addresses\";s:0:\"\";s:28:\"aiowps_enable_basic_firewall\";s:1:\"1\";s:31:\"aiowps_enable_pingback_firewall\";s:1:\"1\";s:38:\"aiowps_disable_xmlrpc_pingback_methods\";s:1:\"1\";s:34:\"aiowps_block_debug_log_file_access\";s:1:\"1\";s:26:\"aiowps_disable_index_views\";s:1:\"1\";s:30:\"aiowps_disable_trace_and_track\";s:1:\"1\";s:28:\"aiowps_forbid_proxy_comments\";s:1:\"1\";s:29:\"aiowps_deny_bad_query_strings\";s:1:\"1\";s:34:\"aiowps_advanced_char_string_filter\";s:1:\"1\";s:25:\"aiowps_enable_5g_firewall\";s:1:\"1\";s:25:\"aiowps_enable_6g_firewall\";s:0:\"\";s:26:\"aiowps_enable_custom_rules\";s:0:\"\";s:19:\"aiowps_custom_rules\";s:0:\"\";s:25:\"aiowps_enable_404_logging\";s:1:\"1\";s:28:\"aiowps_enable_404_IP_lockout\";s:1:\"1\";s:30:\"aiowps_404_lockout_time_length\";i:60;s:28:\"aiowps_404_lock_redirect_url\";s:16:\"http://127.0.0.1\";s:31:\"aiowps_enable_rename_login_page\";s:0:\"\";s:28:\"aiowps_enable_login_honeypot\";s:1:\"1\";s:43:\"aiowps_enable_brute_force_attack_prevention\";s:0:\"\";s:30:\"aiowps_brute_force_secret_word\";s:0:\"\";s:24:\"aiowps_cookie_brute_test\";s:0:\"\";s:44:\"aiowps_cookie_based_brute_force_redirect_url\";s:16:\"http://127.0.0.1\";s:59:\"aiowps_brute_force_attack_prevention_pw_protected_exception\";s:0:\"\";s:51:\"aiowps_brute_force_attack_prevention_ajax_exception\";s:0:\"\";s:19:\"aiowps_site_lockout\";s:0:\"\";s:23:\"aiowps_site_lockout_msg\";s:61:\"This site is currently not available. Please try again later.\";s:30:\"aiowps_enable_spambot_blocking\";s:1:\"1\";s:29:\"aiowps_enable_comment_captcha\";s:1:\"1\";s:31:\"aiowps_enable_autoblock_spam_ip\";s:1:\"1\";s:33:\"aiowps_spam_ip_min_comments_block\";i:3;s:32:\"aiowps_enable_automated_fcd_scan\";s:0:\"\";s:25:\"aiowps_fcd_scan_frequency\";s:1:\"4\";s:24:\"aiowps_fcd_scan_interval\";s:1:\"2\";s:28:\"aiowps_fcd_exclude_filetypes\";s:0:\"\";s:24:\"aiowps_fcd_exclude_files\";s:0:\"\";s:26:\"aiowps_send_fcd_scan_email\";s:0:\"\";s:29:\"aiowps_fcd_scan_email_address\";s:15:\"9698114@mail.ru\";s:27:\"aiowps_fcds_change_detected\";b:0;s:22:\"aiowps_copy_protection\";s:0:\"\";s:40:\"aiowps_prevent_site_display_inside_frame\";s:1:\"1\";s:32:\"aiowps_prevent_users_enumeration\";s:1:\"1\";s:23:\"aiowps_last_backup_time\";s:19:\"2019-08-29 22:38:57\";s:35:\"aiowps_lockdown_enable_whitelisting\";s:0:\"\";s:36:\"aiowps_lockdown_allowed_ip_addresses\";s:0:\"\";s:35:\"aiowps_enable_registration_honeypot\";s:0:\"\";s:31:\"aiowps_enable_woo_login_captcha\";s:1:\"1\";s:34:\"aiowps_enable_woo_register_captcha\";s:1:\"1\";s:32:\"aiowps_place_custom_rules_at_top\";s:0:\"\";s:33:\"aiowps_enable_bp_register_captcha\";s:0:\"\";s:35:\"aiowps_enable_bbp_new_topic_captcha\";s:0:\"\";s:42:\"aiowps_disallow_unauthorized_rest_requests\";s:0:\"\";s:25:\"aiowps_ip_retrieve_method\";s:1:\"0\";s:35:\"aiowps_enable_lost_password_captcha\";s:1:\"1\";s:28:\"aiowps_block_fake_googlebots\";s:1:\"1\";s:25:\"aiowps_recaptcha_site_key\";s:0:\"\";s:27:\"aiowps_recaptcha_secret_key\";s:0:\"\";s:24:\"aiowps_default_recaptcha\";s:0:\"\";s:38:\"aiowps_enable_woo_lostpassword_captcha\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("170","_transient_timeout_users_online","1576600845","no");
INSERT INTO `wp_options` VALUES("171","_transient_users_online","a:1:{i:0;a:3:{s:7:\"user_id\";i:1;s:13:\"last_activity\";i:1576609845;s:10:\"ip_address\";s:9:\"127.0.0.1\";}}","no");
INSERT INTO `wp_options` VALUES("174","_site_transient_timeout_theme_roots","1576598414","no");
INSERT INTO `wp_options` VALUES("175","_site_transient_theme_roots","a:4:{s:8:\"dimtepla\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}","no");
INSERT INTO `wp_options` VALUES("183","wpseo","a:20:{s:15:\"ms_defaults_set\";b:0;s:7:\"version\";s:6:\"12.7.1\";s:20:\"disableadvanced_meta\";b:1;s:19:\"onpage_indexability\";b:1;s:11:\"baiduverify\";s:0:\"\";s:12:\"googleverify\";s:0:\"\";s:8:\"msverify\";s:0:\"\";s:12:\"yandexverify\";s:0:\"\";s:9:\"site_type\";s:0:\"\";s:20:\"has_multiple_authors\";s:0:\"\";s:16:\"environment_type\";s:0:\"\";s:23:\"content_analysis_active\";b:1;s:23:\"keyword_analysis_active\";b:1;s:21:\"enable_admin_bar_menu\";b:1;s:26:\"enable_cornerstone_content\";b:1;s:18:\"enable_xml_sitemap\";b:1;s:24:\"enable_text_link_counter\";b:1;s:22:\"show_onboarding_notice\";b:1;s:18:\"first_activated_on\";i:1576595626;s:13:\"myyoast-oauth\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("184","wpseo_titles","a:71:{s:10:\"title_test\";i:0;s:17:\"forcerewritetitle\";b:0;s:9:\"separator\";s:7:\"sc-dash\";s:16:\"title-home-wpseo\";s:42:\"%%sitename%% %%page%% %%sep%% %%sitedesc%%\";s:18:\"title-author-wpseo\";s:45:\"%%name%%, Автор в %%sitename%% %%page%%\";s:19:\"title-archive-wpseo\";s:38:\"%%date%% %%page%% %%sep%% %%sitename%%\";s:18:\"title-search-wpseo\";s:64:\"Вы искали %%searchphrase%% %%page%% %%sep%% %%sitename%%\";s:15:\"title-404-wpseo\";s:57:\"Страница не найдена %%sep%% %%sitename%%\";s:19:\"metadesc-home-wpseo\";s:0:\"\";s:21:\"metadesc-author-wpseo\";s:0:\"\";s:22:\"metadesc-archive-wpseo\";s:0:\"\";s:9:\"rssbefore\";s:0:\"\";s:8:\"rssafter\";s:84:\"Сообщение %%POSTLINK%% появились сначала на %%BLOGLINK%%.\";s:20:\"noindex-author-wpseo\";b:0;s:28:\"noindex-author-noposts-wpseo\";b:1;s:21:\"noindex-archive-wpseo\";b:1;s:14:\"disable-author\";b:0;s:12:\"disable-date\";b:0;s:19:\"disable-post_format\";b:0;s:18:\"disable-attachment\";b:1;s:23:\"is-media-purge-relevant\";b:0;s:20:\"breadcrumbs-404crumb\";s:54:\"Ошибка 404: страница не найдена\";s:29:\"breadcrumbs-display-blog-page\";b:1;s:20:\"breadcrumbs-boldlast\";b:0;s:25:\"breadcrumbs-archiveprefix\";s:19:\"Архивы для\";s:18:\"breadcrumbs-enable\";b:0;s:16:\"breadcrumbs-home\";s:31:\"Главная страница\";s:18:\"breadcrumbs-prefix\";s:0:\"\";s:24:\"breadcrumbs-searchprefix\";s:17:\"Вы искали\";s:15:\"breadcrumbs-sep\";s:7:\"&raquo;\";s:12:\"website_name\";s:0:\"\";s:11:\"person_name\";s:0:\"\";s:11:\"person_logo\";s:0:\"\";s:14:\"person_logo_id\";i:0;s:22:\"alternate_website_name\";s:0:\"\";s:12:\"company_logo\";s:0:\"\";s:15:\"company_logo_id\";i:0;s:12:\"company_name\";s:0:\"\";s:17:\"company_or_person\";s:7:\"company\";s:25:\"company_or_person_user_id\";b:0;s:17:\"stripcategorybase\";b:0;s:10:\"title-post\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-post\";s:0:\"\";s:12:\"noindex-post\";b:0;s:13:\"showdate-post\";b:0;s:23:\"display-metabox-pt-post\";b:1;s:23:\"post_types-post-maintax\";i:0;s:10:\"title-page\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:13:\"metadesc-page\";s:0:\"\";s:12:\"noindex-page\";b:0;s:13:\"showdate-page\";b:0;s:23:\"display-metabox-pt-page\";b:1;s:23:\"post_types-page-maintax\";i:0;s:16:\"title-attachment\";s:39:\"%%title%% %%page%% %%sep%% %%sitename%%\";s:19:\"metadesc-attachment\";s:0:\"\";s:18:\"noindex-attachment\";b:0;s:19:\"showdate-attachment\";b:0;s:29:\"display-metabox-pt-attachment\";b:1;s:29:\"post_types-attachment-maintax\";i:0;s:18:\"title-tax-category\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-category\";s:0:\"\";s:28:\"display-metabox-tax-category\";b:1;s:20:\"noindex-tax-category\";b:0;s:18:\"title-tax-post_tag\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:21:\"metadesc-tax-post_tag\";s:0:\"\";s:28:\"display-metabox-tax-post_tag\";b:1;s:20:\"noindex-tax-post_tag\";b:0;s:21:\"title-tax-post_format\";s:57:\"Архивы %%term_title%% %%page%% %%sep%% %%sitename%%\";s:24:\"metadesc-tax-post_format\";s:0:\"\";s:31:\"display-metabox-tax-post_format\";b:1;s:23:\"noindex-tax-post_format\";b:1;}","yes");
INSERT INTO `wp_options` VALUES("185","wpseo_social","a:19:{s:13:\"facebook_site\";s:0:\"\";s:13:\"instagram_url\";s:0:\"\";s:12:\"linkedin_url\";s:0:\"\";s:11:\"myspace_url\";s:0:\"\";s:16:\"og_default_image\";s:0:\"\";s:19:\"og_default_image_id\";s:0:\"\";s:18:\"og_frontpage_title\";s:0:\"\";s:17:\"og_frontpage_desc\";s:0:\"\";s:18:\"og_frontpage_image\";s:0:\"\";s:21:\"og_frontpage_image_id\";s:0:\"\";s:9:\"opengraph\";b:1;s:13:\"pinterest_url\";s:0:\"\";s:15:\"pinterestverify\";s:0:\"\";s:7:\"twitter\";b:1;s:12:\"twitter_site\";s:0:\"\";s:17:\"twitter_card_type\";s:19:\"summary_large_image\";s:11:\"youtube_url\";s:0:\"\";s:13:\"wikipedia_url\";s:0:\"\";s:10:\"fbadminapp\";s:0:\"\";}","yes");
INSERT INTO `wp_options` VALUES("186","wpseo_flush_rewrite","1","yes");
INSERT INTO `wp_options` VALUES("187","_transient_timeout_wpseo_link_table_inaccessible","1608131626","no");
INSERT INTO `wp_options` VALUES("188","_transient_wpseo_link_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("189","_transient_timeout_wpseo_meta_table_inaccessible","1608131626","no");
INSERT INTO `wp_options` VALUES("190","_transient_wpseo_meta_table_inaccessible","0","no");
INSERT INTO `wp_options` VALUES("201","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.3.1.zip\";s:6:\"locale\";s:5:\"ru_RU\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/ru_RU/wordpress-5.3.1.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.1\";s:7:\"version\";s:5:\"5.3.1\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1576596080;s:15:\"version_checked\";s:5:\"5.3.1\";s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("202","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1576596081;s:7:\"checked\";a:7:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:5:\"4.4.2\";s:33:\"classic-editor/classic-editor.php\";s:3:\"1.5\";s:22:\"cyr3lat/cyr-to-lat.php\";s:3:\"3.5\";s:21:\"imsanity/imsanity.php\";s:5:\"2.5.0\";s:31:\"query-monitor/query-monitor.php\";s:5:\"3.5.2\";s:27:\"woocommerce/woocommerce.php\";s:5:\"3.8.1\";s:24:\"wordpress-seo/wp-seo.php\";s:6:\"12.7.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:7:{s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:49:\"w.org/plugins/all-in-one-wp-security-and-firewall\";s:4:\"slug\";s:35:\"all-in-one-wp-security-and-firewall\";s:6:\"plugin\";s:51:\"all-in-one-wp-security-and-firewall/wp-security.php\";s:11:\"new_version\";s:5:\"4.4.2\";s:3:\"url\";s:66:\"https://wordpress.org/plugins/all-in-one-wp-security-and-firewall/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/all-in-one-wp-security-and-firewall.zip\";s:5:\"icons\";a:1:{s:2:\"1x\";s:88:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/icon-128x128.png?rev=1232826\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:91:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-1544x500.png?rev=1914011\";s:2:\"1x\";s:90:\"https://ps.w.org/all-in-one-wp-security-and-firewall/assets/banner-772x250.png?rev=1914013\";}s:11:\"banners_rtl\";a:0:{}}s:33:\"classic-editor/classic-editor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/classic-editor\";s:4:\"slug\";s:14:\"classic-editor\";s:6:\"plugin\";s:33:\"classic-editor/classic-editor.php\";s:11:\"new_version\";s:3:\"1.5\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/classic-editor/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/classic-editor.1.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-256x256.png?rev=1998671\";s:2:\"1x\";s:67:\"https://ps.w.org/classic-editor/assets/icon-128x128.png?rev=1998671\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:70:\"https://ps.w.org/classic-editor/assets/banner-1544x500.png?rev=1998671\";s:2:\"1x\";s:69:\"https://ps.w.org/classic-editor/assets/banner-772x250.png?rev=1998676\";}s:11:\"banners_rtl\";a:0:{}}s:22:\"cyr3lat/cyr-to-lat.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/cyr3lat\";s:4:\"slug\";s:7:\"cyr3lat\";s:6:\"plugin\";s:22:\"cyr3lat/cyr-to-lat.php\";s:11:\"new_version\";s:3:\"3.5\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/cyr3lat/\";s:7:\"package\";s:54:\"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:51:\"https://s.w.org/plugins/geopattern-icon/cyr3lat.svg\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}}s:21:\"imsanity/imsanity.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:22:\"w.org/plugins/imsanity\";s:4:\"slug\";s:8:\"imsanity\";s:6:\"plugin\";s:21:\"imsanity/imsanity.php\";s:11:\"new_version\";s:5:\"2.5.0\";s:3:\"url\";s:39:\"https://wordpress.org/plugins/imsanity/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/plugin/imsanity.2.5.0.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:61:\"https://ps.w.org/imsanity/assets/icon-256x256.png?rev=1094749\";s:2:\"1x\";s:61:\"https://ps.w.org/imsanity/assets/icon-128x128.png?rev=1170755\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:62:\"https://ps.w.org/imsanity/assets/banner-772x250.png?rev=900541\";}s:11:\"banners_rtl\";a:0:{}}s:31:\"query-monitor/query-monitor.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/query-monitor\";s:4:\"slug\";s:13:\"query-monitor\";s:6:\"plugin\";s:31:\"query-monitor/query-monitor.php\";s:11:\"new_version\";s:5:\"3.5.2\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/query-monitor/\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/plugin/query-monitor.3.5.2.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/query-monitor/assets/icon-256x256.png?rev=2056073\";s:2:\"1x\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";s:3:\"svg\";s:58:\"https://ps.w.org/query-monitor/assets/icon.svg?rev=2056073\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/query-monitor/assets/banner-1544x500.png?rev=1629576\";s:2:\"1x\";s:68:\"https://ps.w.org/query-monitor/assets/banner-772x250.png?rev=1731469\";}s:11:\"banners_rtl\";a:0:{}}s:27:\"woocommerce/woocommerce.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:6:\"plugin\";s:27:\"woocommerce/woocommerce.php\";s:11:\"new_version\";s:5:\"3.8.1\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/woocommerce/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/woocommerce.3.8.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-256x256.png?rev=2075035\";s:2:\"1x\";s:64:\"https://ps.w.org/woocommerce/assets/icon-128x128.png?rev=2075035\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:67:\"https://ps.w.org/woocommerce/assets/banner-1544x500.png?rev=2075035\";s:2:\"1x\";s:66:\"https://ps.w.org/woocommerce/assets/banner-772x250.png?rev=2075035\";}s:11:\"banners_rtl\";a:0:{}}s:24:\"wordpress-seo/wp-seo.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:27:\"w.org/plugins/wordpress-seo\";s:4:\"slug\";s:13:\"wordpress-seo\";s:6:\"plugin\";s:24:\"wordpress-seo/wp-seo.php\";s:11:\"new_version\";s:6:\"12.7.1\";s:3:\"url\";s:44:\"https://wordpress.org/plugins/wordpress-seo/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/wordpress-seo.12.7.1.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:66:\"https://ps.w.org/wordpress-seo/assets/icon-256x256.png?rev=1834347\";s:2:\"1x\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";s:3:\"svg\";s:58:\"https://ps.w.org/wordpress-seo/assets/icon.svg?rev=1946641\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500.png?rev=1843435\";s:2:\"1x\";s:68:\"https://ps.w.org/wordpress-seo/assets/banner-772x250.png?rev=1843435\";}s:11:\"banners_rtl\";a:2:{s:2:\"2x\";s:73:\"https://ps.w.org/wordpress-seo/assets/banner-1544x500-rtl.png?rev=1843435\";s:2:\"1x\";s:72:\"https://ps.w.org/wordpress-seo/assets/banner-772x250-rtl.png?rev=1843435\";}}}}","no");
INSERT INTO `wp_options` VALUES("203","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1576596614;s:7:\"checked\";a:4:{s:8:\"dimtepla\";s:0:\"\";s:14:\"twentynineteen\";s:3:\"1.4\";s:15:\"twentyseventeen\";s:3:\"2.2\";s:12:\"twentytwenty\";s:3:\"1.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("206","woocommerce_store_address","dimtepla.com","yes");
INSERT INTO `wp_options` VALUES("207","woocommerce_store_address_2","","yes");
INSERT INTO `wp_options` VALUES("208","woocommerce_store_city","dnepr","yes");
INSERT INTO `wp_options` VALUES("209","woocommerce_default_country","GB:*","yes");
INSERT INTO `wp_options` VALUES("210","woocommerce_store_postcode","","yes");
INSERT INTO `wp_options` VALUES("211","woocommerce_allowed_countries","all","yes");
INSERT INTO `wp_options` VALUES("212","woocommerce_all_except_countries","","yes");
INSERT INTO `wp_options` VALUES("213","woocommerce_specific_allowed_countries","","yes");
INSERT INTO `wp_options` VALUES("214","woocommerce_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("215","woocommerce_specific_ship_to_countries","","yes");
INSERT INTO `wp_options` VALUES("216","woocommerce_default_customer_address","geolocation","yes");
INSERT INTO `wp_options` VALUES("217","woocommerce_calc_taxes","no","yes");
INSERT INTO `wp_options` VALUES("218","woocommerce_enable_coupons","yes","yes");
INSERT INTO `wp_options` VALUES("219","woocommerce_calc_discounts_sequentially","no","no");
INSERT INTO `wp_options` VALUES("220","woocommerce_currency","GBP","yes");
INSERT INTO `wp_options` VALUES("221","woocommerce_currency_pos","left","yes");
INSERT INTO `wp_options` VALUES("222","woocommerce_price_thousand_sep",",","yes");
INSERT INTO `wp_options` VALUES("223","woocommerce_price_decimal_sep",".","yes");
INSERT INTO `wp_options` VALUES("224","woocommerce_price_num_decimals","2","yes");
INSERT INTO `wp_options` VALUES("225","woocommerce_shop_page_id","12","yes");
INSERT INTO `wp_options` VALUES("226","woocommerce_cart_redirect_after_add","no","yes");
INSERT INTO `wp_options` VALUES("227","woocommerce_enable_ajax_add_to_cart","yes","yes");
INSERT INTO `wp_options` VALUES("228","woocommerce_placeholder_image","11","yes");
INSERT INTO `wp_options` VALUES("229","woocommerce_weight_unit","kg","yes");
INSERT INTO `wp_options` VALUES("230","woocommerce_dimension_unit","cm","yes");
INSERT INTO `wp_options` VALUES("231","woocommerce_enable_reviews","yes","yes");
INSERT INTO `wp_options` VALUES("232","woocommerce_review_rating_verification_label","yes","no");
INSERT INTO `wp_options` VALUES("233","woocommerce_review_rating_verification_required","no","no");
INSERT INTO `wp_options` VALUES("234","woocommerce_enable_review_rating","yes","yes");
INSERT INTO `wp_options` VALUES("235","woocommerce_review_rating_required","yes","no");
INSERT INTO `wp_options` VALUES("236","woocommerce_manage_stock","yes","yes");
INSERT INTO `wp_options` VALUES("237","woocommerce_hold_stock_minutes","60","no");
INSERT INTO `wp_options` VALUES("238","woocommerce_notify_low_stock","yes","no");
INSERT INTO `wp_options` VALUES("239","woocommerce_notify_no_stock","yes","no");
INSERT INTO `wp_options` VALUES("240","woocommerce_stock_email_recipient","Email@mail.com","no");
INSERT INTO `wp_options` VALUES("241","woocommerce_notify_low_stock_amount","2","no");
INSERT INTO `wp_options` VALUES("242","woocommerce_notify_no_stock_amount","0","yes");
INSERT INTO `wp_options` VALUES("243","woocommerce_hide_out_of_stock_items","no","yes");
INSERT INTO `wp_options` VALUES("244","woocommerce_stock_format","","yes");
INSERT INTO `wp_options` VALUES("245","woocommerce_file_download_method","force","no");
INSERT INTO `wp_options` VALUES("246","woocommerce_downloads_require_login","no","no");
INSERT INTO `wp_options` VALUES("247","woocommerce_downloads_grant_access_after_payment","yes","no");
INSERT INTO `wp_options` VALUES("248","woocommerce_prices_include_tax","no","yes");
INSERT INTO `wp_options` VALUES("249","woocommerce_tax_based_on","shipping","yes");
INSERT INTO `wp_options` VALUES("250","woocommerce_shipping_tax_class","inherit","yes");
INSERT INTO `wp_options` VALUES("251","woocommerce_tax_round_at_subtotal","no","yes");
INSERT INTO `wp_options` VALUES("252","woocommerce_tax_classes","","yes");
INSERT INTO `wp_options` VALUES("253","woocommerce_tax_display_shop","excl","yes");
INSERT INTO `wp_options` VALUES("254","woocommerce_tax_display_cart","excl","yes");
INSERT INTO `wp_options` VALUES("255","woocommerce_price_display_suffix","","yes");
INSERT INTO `wp_options` VALUES("256","woocommerce_tax_total_display","itemized","no");
INSERT INTO `wp_options` VALUES("257","woocommerce_enable_shipping_calc","yes","no");
INSERT INTO `wp_options` VALUES("258","woocommerce_shipping_cost_requires_address","no","yes");
INSERT INTO `wp_options` VALUES("259","woocommerce_ship_to_destination","billing","no");
INSERT INTO `wp_options` VALUES("260","woocommerce_shipping_debug_mode","no","yes");
INSERT INTO `wp_options` VALUES("261","woocommerce_enable_guest_checkout","yes","no");
INSERT INTO `wp_options` VALUES("262","woocommerce_enable_checkout_login_reminder","no","no");
INSERT INTO `wp_options` VALUES("263","woocommerce_enable_signup_and_login_from_checkout","no","no");
INSERT INTO `wp_options` VALUES("264","woocommerce_enable_myaccount_registration","no","no");
INSERT INTO `wp_options` VALUES("265","woocommerce_registration_generate_username","yes","no");
INSERT INTO `wp_options` VALUES("266","woocommerce_registration_generate_password","yes","no");
INSERT INTO `wp_options` VALUES("267","woocommerce_erasure_request_removes_order_data","no","no");
INSERT INTO `wp_options` VALUES("268","woocommerce_erasure_request_removes_download_data","no","no");
INSERT INTO `wp_options` VALUES("269","woocommerce_allow_bulk_remove_personal_data","no","no");
INSERT INTO `wp_options` VALUES("270","woocommerce_registration_privacy_policy_text","Ваши личные данные будут использоваться для упрощения вашей работы с сайтом, управления доступом к вашей учётной записи и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("271","woocommerce_checkout_privacy_policy_text","Ваши личные данные будут использоваться для обработки ваших заказов, упрощения вашей работы с сайтом и для других целей, описанных в нашей [privacy_policy].","yes");
INSERT INTO `wp_options` VALUES("272","woocommerce_delete_inactive_accounts","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("273","woocommerce_trash_pending_orders","","no");
INSERT INTO `wp_options` VALUES("274","woocommerce_trash_failed_orders","","no");
INSERT INTO `wp_options` VALUES("275","woocommerce_trash_cancelled_orders","","no");
INSERT INTO `wp_options` VALUES("276","woocommerce_anonymize_completed_orders","a:2:{s:6:\"number\";s:0:\"\";s:4:\"unit\";s:6:\"months\";}","no");
INSERT INTO `wp_options` VALUES("277","woocommerce_email_from_name","dimtepla.com","no");
INSERT INTO `wp_options` VALUES("278","woocommerce_email_from_address","Email@mail.com","no");
INSERT INTO `wp_options` VALUES("279","woocommerce_email_header_image","","no");
INSERT INTO `wp_options` VALUES("280","woocommerce_email_footer_text","{site_title} &mdash; Built with {WooCommerce}","no");
INSERT INTO `wp_options` VALUES("281","woocommerce_email_base_color","#96588a","no");
INSERT INTO `wp_options` VALUES("282","woocommerce_email_background_color","#f7f7f7","no");
INSERT INTO `wp_options` VALUES("283","woocommerce_email_body_background_color","#ffffff","no");
INSERT INTO `wp_options` VALUES("284","woocommerce_email_text_color","#3c3c3c","no");
INSERT INTO `wp_options` VALUES("285","woocommerce_cart_page_id","13","no");
INSERT INTO `wp_options` VALUES("286","woocommerce_checkout_page_id","14","no");
INSERT INTO `wp_options` VALUES("287","woocommerce_myaccount_page_id","15","no");
INSERT INTO `wp_options` VALUES("288","woocommerce_terms_page_id","","no");
INSERT INTO `wp_options` VALUES("289","woocommerce_force_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("290","woocommerce_unforce_ssl_checkout","no","yes");
INSERT INTO `wp_options` VALUES("291","woocommerce_checkout_pay_endpoint","order-pay","yes");
INSERT INTO `wp_options` VALUES("292","woocommerce_checkout_order_received_endpoint","order-received","yes");
INSERT INTO `wp_options` VALUES("293","woocommerce_myaccount_add_payment_method_endpoint","add-payment-method","yes");
INSERT INTO `wp_options` VALUES("294","woocommerce_myaccount_delete_payment_method_endpoint","delete-payment-method","yes");
INSERT INTO `wp_options` VALUES("295","woocommerce_myaccount_set_default_payment_method_endpoint","set-default-payment-method","yes");
INSERT INTO `wp_options` VALUES("296","woocommerce_myaccount_orders_endpoint","orders","yes");
INSERT INTO `wp_options` VALUES("297","woocommerce_myaccount_view_order_endpoint","view-order","yes");
INSERT INTO `wp_options` VALUES("298","woocommerce_myaccount_downloads_endpoint","downloads","yes");
INSERT INTO `wp_options` VALUES("299","woocommerce_myaccount_edit_account_endpoint","edit-account","yes");
INSERT INTO `wp_options` VALUES("300","woocommerce_myaccount_edit_address_endpoint","edit-address","yes");
INSERT INTO `wp_options` VALUES("301","woocommerce_myaccount_payment_methods_endpoint","payment-methods","yes");
INSERT INTO `wp_options` VALUES("302","woocommerce_myaccount_lost_password_endpoint","lost-password","yes");
INSERT INTO `wp_options` VALUES("303","woocommerce_logout_endpoint","customer-logout","yes");
INSERT INTO `wp_options` VALUES("304","woocommerce_api_enabled","no","yes");
INSERT INTO `wp_options` VALUES("305","woocommerce_allow_tracking","no","no");
INSERT INTO `wp_options` VALUES("306","woocommerce_show_marketplace_suggestions","yes","no");
INSERT INTO `wp_options` VALUES("307","woocommerce_single_image_width","600","yes");
INSERT INTO `wp_options` VALUES("308","woocommerce_thumbnail_image_width","300","yes");
INSERT INTO `wp_options` VALUES("309","woocommerce_checkout_highlight_required_fields","yes","yes");
INSERT INTO `wp_options` VALUES("310","woocommerce_demo_store","no","no");
INSERT INTO `wp_options` VALUES("311","woocommerce_permalinks","a:5:{s:12:\"product_base\";s:7:\"product\";s:13:\"category_base\";s:16:\"product-category\";s:8:\"tag_base\";s:11:\"product-tag\";s:14:\"attribute_base\";s:0:\"\";s:22:\"use_verbose_page_rules\";b:0;}","yes");
INSERT INTO `wp_options` VALUES("312","current_theme_supports_woocommerce","yes","yes");
INSERT INTO `wp_options` VALUES("313","woocommerce_queue_flush_rewrite_rules","no","yes");
INSERT INTO `wp_options` VALUES("314","rewrite_rules","a:160:{s:19:\"sitemap_index\\.xml$\";s:19:\"index.php?sitemap=1\";s:31:\"([^/]+?)-sitemap([0-9]+)?\\.xml$\";s:51:\"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]\";s:24:\"([a-z]+)?-?sitemap\\.xsl$\";s:39:\"index.php?yoast-sitemap-xsl=$matches[1]\";s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:7:\"shop/?$\";s:27:\"index.php?post_type=product\";s:37:\"shop/feed/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:32:\"shop/(feed|rdf|rss|rss2|atom)/?$\";s:44:\"index.php?post_type=product&feed=$matches[1]\";s:24:\"shop/page/([0-9]{1,})/?$\";s:45:\"index.php?post_type=product&paged=$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:35:\"product/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:45:\"product/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:65:\"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:60:\"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:41:\"product/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:24:\"product/([^/]+)/embed/?$\";s:40:\"index.php?product=$matches[1]&embed=true\";s:28:\"product/([^/]+)/trackback/?$\";s:34:\"index.php?product=$matches[1]&tb=1\";s:48:\"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:43:\"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:46:\"index.php?product=$matches[1]&feed=$matches[2]\";s:36:\"product/([^/]+)/page/?([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&paged=$matches[2]\";s:43:\"product/([^/]+)/comment-page-([0-9]{1,})/?$\";s:47:\"index.php?product=$matches[1]&cpage=$matches[2]\";s:32:\"product/([^/]+)(?:/([0-9]+))?/?$\";s:46:\"index.php?product=$matches[1]&page=$matches[2]\";s:24:\"product/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:34:\"product/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:54:\"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:49:\"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:30:\"product/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"^wc-api/v([1-3]{1})/?$\";s:51:\"index.php?wc-api-version=$matches[1]&wc-api-route=/\";s:24:\"^wc-api/v([1-3]{1})(.*)?\";s:61:\"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]\";s:24:\"^wc-auth/v([1]{1})/(.*)?\";s:63:\"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]\";s:32:\"category/(.+?)/wc-api(/(.*))?/?$\";s:54:\"index.php?category_name=$matches[1]&wc-api=$matches[3]\";s:29:\"tag/([^/]+)/wc-api(/(.*))?/?$\";s:44:\"index.php?tag=$matches[1]&wc-api=$matches[3]\";s:33:\"product/([^/]+)/wc-api(/(.*))?/?$\";s:48:\"index.php?product=$matches[1]&wc-api=$matches[3]\";s:39:\"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:50:\"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:55:\"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:50:\"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_cat=$matches[1]&feed=$matches[2]\";s:31:\"product-category/(.+?)/embed/?$\";s:44:\"index.php?product_cat=$matches[1]&embed=true\";s:43:\"product-category/(.+?)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_cat=$matches[1]&paged=$matches[2]\";s:25:\"product-category/(.+?)/?$\";s:33:\"index.php?product_cat=$matches[1]\";s:52:\"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:47:\"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?product_tag=$matches[1]&feed=$matches[2]\";s:28:\"product-tag/([^/]+)/embed/?$\";s:44:\"index.php?product_tag=$matches[1]&embed=true\";s:40:\"product-tag/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?product_tag=$matches[1]&paged=$matches[2]\";s:22:\"product-tag/([^/]+)/?$\";s:33:\"index.php?product_tag=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:17:\"wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:26:\"comments/wc-api(/(.*))?/?$\";s:29:\"index.php?&wc-api=$matches[2]\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:29:\"search/(.+)/wc-api(/(.*))?/?$\";s:42:\"index.php?s=$matches[1]&wc-api=$matches[3]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:32:\"author/([^/]+)/wc-api(/(.*))?/?$\";s:52:\"index.php?author_name=$matches[1]&wc-api=$matches[3]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:54:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:82:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:41:\"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$\";s:66:\"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:28:\"([0-9]{4})/wc-api(/(.*))?/?$\";s:45:\"index.php?year=$matches[1]&wc-api=$matches[3]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:62:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$\";s:99:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]\";s:62:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:73:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:28:\"(.?.+?)/order-pay(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&order-pay=$matches[3]\";s:33:\"(.?.+?)/order-received(/(.*))?/?$\";s:57:\"index.php?pagename=$matches[1]&order-received=$matches[3]\";s:25:\"(.?.+?)/orders(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&orders=$matches[3]\";s:29:\"(.?.+?)/view-order(/(.*))?/?$\";s:53:\"index.php?pagename=$matches[1]&view-order=$matches[3]\";s:28:\"(.?.+?)/downloads(/(.*))?/?$\";s:52:\"index.php?pagename=$matches[1]&downloads=$matches[3]\";s:31:\"(.?.+?)/edit-account(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-account=$matches[3]\";s:31:\"(.?.+?)/edit-address(/(.*))?/?$\";s:55:\"index.php?pagename=$matches[1]&edit-address=$matches[3]\";s:34:\"(.?.+?)/payment-methods(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&payment-methods=$matches[3]\";s:32:\"(.?.+?)/lost-password(/(.*))?/?$\";s:56:\"index.php?pagename=$matches[1]&lost-password=$matches[3]\";s:34:\"(.?.+?)/customer-logout(/(.*))?/?$\";s:58:\"index.php?pagename=$matches[1]&customer-logout=$matches[3]\";s:37:\"(.?.+?)/add-payment-method(/(.*))?/?$\";s:61:\"index.php?pagename=$matches[1]&add-payment-method=$matches[3]\";s:40:\"(.?.+?)/delete-payment-method(/(.*))?/?$\";s:64:\"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]\";s:45:\"(.?.+?)/set-default-payment-method(/(.*))?/?$\";s:69:\"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]\";s:25:\"(.?.+?)/wc-api(/(.*))?/?$\";s:49:\"index.php?pagename=$matches[1]&wc-api=$matches[3]\";s:31:\".?.+?/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:42:\".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$\";s:51:\"index.php?attachment=$matches[1]&wc-api=$matches[3]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `wp_options` VALUES("315","_transient_wc_attribute_taxonomies","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("316","product_cat_children","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("317","default_product_cat","15","yes");
INSERT INTO `wp_options` VALUES("320","woocommerce_version","3.8.1","yes");
INSERT INTO `wp_options` VALUES("321","woocommerce_db_version","3.8.1","yes");
INSERT INTO `wp_options` VALUES("322","woocommerce_admin_notices","a:1:{i:1;s:20:\"no_secure_connection\";}","yes");
INSERT INTO `wp_options` VALUES("323","_transient_woocommerce_webhook_ids_status_active","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("324","widget_woocommerce_widget_cart","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("325","widget_woocommerce_layered_nav_filters","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("326","widget_woocommerce_layered_nav","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("327","widget_woocommerce_price_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("328","widget_woocommerce_product_categories","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("329","widget_woocommerce_product_search","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("330","widget_woocommerce_product_tag_cloud","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("331","widget_woocommerce_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("332","widget_woocommerce_recently_viewed_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("333","widget_woocommerce_top_rated_products","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("334","widget_woocommerce_recent_reviews","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("335","widget_woocommerce_rating_filter","a:1:{s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `wp_options` VALUES("338","_transient_timeout_external_ip_address_127.0.0.1","1577200884","no");
INSERT INTO `wp_options` VALUES("339","_transient_external_ip_address_127.0.0.1","93.78.16.78","no");
INSERT INTO `wp_options` VALUES("342","woocommerce_meta_box_errors","a:0:{}","yes");
INSERT INTO `wp_options` VALUES("343","_transient_wc_count_comments","O:8:\"stdClass\":7:{s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:8:\"approved\";s:1:\"1\";s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("344","_transient_as_comment_count","O:8:\"stdClass\":7:{s:8:\"approved\";s:1:\"1\";s:14:\"total_comments\";i:1;s:3:\"all\";i:1;s:9:\"moderated\";i:0;s:4:\"spam\";i:0;s:5:\"trash\";i:0;s:12:\"post-trashed\";i:0;}","yes");
INSERT INTO `wp_options` VALUES("346","woocommerce_product_type","both","yes");
INSERT INTO `wp_options` VALUES("348","_transient_timeout_wc_low_stock_count","1579188156","no");
INSERT INTO `wp_options` VALUES("349","_transient_wc_low_stock_count","0","no");
INSERT INTO `wp_options` VALUES("350","_transient_timeout_wc_outofstock_count","1579188156","no");
INSERT INTO `wp_options` VALUES("351","_transient_wc_outofstock_count","0","no");
INSERT INTO `wp_options` VALUES("352","_transient_timeout_wc_report_sales_by_date","1576682578","no");
INSERT INTO `wp_options` VALUES("353","_transient_wc_report_sales_by_date","a:8:{s:32:\"785153dd5de9eed9a5b9278ec074e260\";a:0:{}s:32:\"3e92f434a7dc9ebfc846388fc85b0206\";a:0:{}s:32:\"68e7dfb28f6bb7053e4d308c3efa8332\";a:0:{}s:32:\"8dcf542998f39be0817291f2e0027db7\";N;s:32:\"41a40f063e95b58e38fb7dfef93baaba\";a:0:{}s:32:\"8c8101e027275d2c80467edfa35984fa\";a:0:{}s:32:\"7657fac3c53287901c905b35d33e43da\";a:0:{}s:32:\"08f0525ce5a8cb47db4ee43cf061118d\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("354","_transient_timeout_wc_admin_report","1576682578","no");
INSERT INTO `wp_options` VALUES("355","_transient_wc_admin_report","a:1:{s:32:\"fcc35a9692b6a69ce4e5306cbbdbf2ce\";a:0:{}}","no");
INSERT INTO `wp_options` VALUES("356","_transient_timeout_wpseo-statistics-totals","1576682557","no");
INSERT INTO `wp_options` VALUES("357","_transient_wpseo-statistics-totals","a:1:{i:1;a:2:{s:6:\"scores\";a:1:{i:0;a:4:{s:8:\"seo_rank\";s:2:\"na\";s:5:\"label\";s:85:\"Записи <strong>без</strong> фокусного ключевого слова\";s:5:\"count\";i:1;s:4:\"link\";s:96:\"http://dimtepla.com/wp-admin/edit.php?post_status=publish&#038;post_type=post&#038;seo_filter=na\";}}s:8:\"division\";a:5:{s:3:\"bad\";i:0;s:2:\"ok\";i:0;s:4:\"good\";i:0;s:2:\"na\";i:1;s:7:\"noindex\";i:0;}}}","no");
INSERT INTO `wp_options` VALUES("362","_transient_timeout__woocommerce_helper_subscriptions","1576597514","no");
INSERT INTO `wp_options` VALUES("363","_transient__woocommerce_helper_subscriptions","a:0:{}","no");
INSERT INTO `wp_options` VALUES("364","_transient_timeout__woocommerce_helper_updates","1576639814","no");
INSERT INTO `wp_options` VALUES("365","_transient__woocommerce_helper_updates","a:4:{s:4:\"hash\";s:32:\"d751713988987e9331980363e24189ce\";s:7:\"updated\";i:1576596614;s:8:\"products\";a:0:{}s:6:\"errors\";a:1:{i:0;s:10:\"http-error\";}}","no");
INSERT INTO `wp_options` VALUES("375","_transient_doing_cron","1576599045.2139589786529541015625","yes");


DROP TABLE IF EXISTS `wp_postmeta`;

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("2","3","_wp_page_template","default");
INSERT INTO `wp_postmeta` VALUES("3","5","_wp_attached_file","2019/12/2020-landscape-1.png");
INSERT INTO `wp_postmeta` VALUES("4","5","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:769;s:4:\"file\";s:28:\"2019/12/2020-landscape-1.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-300x192.png\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"2020-landscape-1-1024x656.png\";s:5:\"width\";i:1024;s:6:\"height\";i:656;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-768x492.png\";s:5:\"width\";i:768;s:6:\"height\";i:492;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");
INSERT INTO `wp_postmeta` VALUES("5","5","_starter_content_theme","twentytwenty");
INSERT INTO `wp_postmeta` VALUES("6","5","_customize_draft_post_name","%d0%be%d0%b1%d0%bd%d0%be%d0%b2%d0%bb%d1%91%d0%bd%d0%bd%d0%b0%d1%8f-umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8");
INSERT INTO `wp_postmeta` VALUES("7","6","_thumbnail_id","5");
INSERT INTO `wp_postmeta` VALUES("8","6","_customize_draft_post_name","umoma-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d0%b2%d0%b0%d0%b5%d1%82-%d0%b4%d0%b2%d0%b5%d1%80%d0%b8");
INSERT INTO `wp_postmeta` VALUES("9","6","_customize_changeset_uuid","7db81598-e10c-429b-bd52-12500997e739");
INSERT INTO `wp_postmeta` VALUES("10","7","_customize_draft_post_name","%d0%be-%d0%bd%d0%b0%d1%81");
INSERT INTO `wp_postmeta` VALUES("11","7","_customize_changeset_uuid","7db81598-e10c-429b-bd52-12500997e739");
INSERT INTO `wp_postmeta` VALUES("12","8","_customize_draft_post_name","%d0%ba%d0%be%d0%bd%d1%82%d0%b0%d0%ba%d1%82%d1%8b");
INSERT INTO `wp_postmeta` VALUES("13","8","_customize_changeset_uuid","7db81598-e10c-429b-bd52-12500997e739");
INSERT INTO `wp_postmeta` VALUES("14","9","_customize_draft_post_name","%d0%b1%d0%bb%d0%be%d0%b3");
INSERT INTO `wp_postmeta` VALUES("15","9","_customize_changeset_uuid","7db81598-e10c-429b-bd52-12500997e739");
INSERT INTO `wp_postmeta` VALUES("16","11","_wp_attached_file","woocommerce-placeholder.png");
INSERT INTO `wp_postmeta` VALUES("17","11","_wp_attachment_metadata","a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:1200;s:4:\"file\";s:27:\"woocommerce-placeholder.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:37:\"woocommerce-placeholder-1024x1024.png\";s:5:\"width\";i:1024;s:6:\"height\";i:1024;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:35:\"woocommerce-placeholder-768x768.png\";s:5:\"width\";i:768;s:6:\"height\";i:768;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}");


DROP TABLE IF EXISTS `wp_posts`;

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_posts` VALUES("1","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:paragraph -->
<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>
<!-- /wp:paragraph -->","Привет, мир!","","publish","open","open","","%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80","","","2019-12-17 17:41:23","2019-12-17 14:41:23","","0","http://dimtepla.com/?p=1","0","post","","1");
INSERT INTO `wp_posts` VALUES("2","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:paragraph -->
<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>...или так:</p>
<!-- /wp:paragraph -->

<!-- wp:quote -->
<blockquote class=\"wp-block-quote\"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>
<!-- /wp:quote -->

<!-- wp:paragraph -->
<p>Перейдите <a href=\"http://dimtepla.com/wp-admin/\">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>
<!-- /wp:paragraph -->","Пример страницы","","publish","closed","open","","sample-page","","","2019-12-17 17:41:23","2019-12-17 14:41:23","","0","http://dimtepla.com/?page_id=2","0","page","","0");
INSERT INTO `wp_posts` VALUES("3","1","2019-12-17 17:41:23","2019-12-17 14:41:23","<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Наш адрес сайта: http://dimtepla.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие персональные данные мы собираем и с какой целью</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Комментарии</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email (\"хеш\") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Медиафайлы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Формы контактов</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Куки</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность \"Запомнить меня\", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Встраиваемое содержимое других вебсайтов</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Веб-аналитика</h3><!-- /wp:heading --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда мы отправляем ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Ваша контактная информация</h2><!-- /wp:heading --><!-- wp:heading --><h2>Дополнительная информация</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Как мы защищаем ваши данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие принимаются процедуры против взлома данных</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>От каких третьих сторон мы получаем данные</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Какие автоматические решения принимаются на основе данных пользователей</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Требования к раскрытию отраслевых нормативных требований</h3><!-- /wp:heading -->","Политика конфиденциальности","","draft","closed","open","","privacy-policy","","","2019-12-17 17:41:23","2019-12-17 14:41:23","","0","http://dimtepla.com/?page_id=3","0","page","","0");
INSERT INTO `wp_posts` VALUES("4","1","2019-12-17 17:41:37","0000-00-00 00:00:00","","Черновик","","auto-draft","open","open","","","","","2019-12-17 17:41:37","0000-00-00 00:00:00","","0","http://dimtepla.com/?p=4","0","post","","0");
INSERT INTO `wp_posts` VALUES("5","1","2019-12-17 17:45:15","0000-00-00 00:00:00","","Обновлённая UMoMA открывает двери","","auto-draft","open","closed","","","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/wp-content/uploads/2019/12/2020-landscape-1.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("6","1","2019-12-17 17:45:15","0000-00-00 00:00:00","<!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">Первоклассное место для современного искусства в северной Швеции. Открыто с 10:00 до 18:00, ежедневно в летние месяцы.</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:columns {\"align\":\"wide\"} --><div class=\"wp-block-columns alignwide\"><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-1.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Дни работы</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-3.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Театр действий</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Жизнь которую вы заслужили</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 августа - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-4.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>От Синьяка до Матисса</h3><!-- /wp:heading --><!-- wp:paragraph --><p>1 октября - 1 декабря</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Читать далее</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-landscape-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\",\"textColor\":\"accent\"} --><h2 class=\"has-accent-color has-text-align-center\">\"Киборги, как установила философ Донна Харауэй, не почтительны. Они не помнят космос.\"</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:paragraph {\"dropCap\":true} --><p class=\"has-drop-cap\">На семи этажах потрясающей архитектуры UMoMA представляет выставку международного современного искусства, иногда наряду с историческими ретроспективами искусства. Экзистенциальные, политические и философские проблемы являются неотъемлемой частью нашей программы. В качестве посетителя вы приглашены на экскурсии, выступления артистов, лекции, показы фильмов и другие мероприятия с бесплатным входом.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Выставки проводятся UMoMA в сотрудничестве с художниками и музеями по всему миру, они часто привлекают международное внимание. UMoMA получили специальную награду от Европейского музея года и вошли в число лучших кандидатов на премию «Шведский музей года», а также на приз музея Совета Европы.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:group {\"customBackgroundColor\":\"#ffffff\",\"align\":\"wide\"} --><div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">Вступайте и получайте эксклюзивные предложения!</h2><!-- /wp:heading --><!-- wp:paragraph {\"align\":\"center\"} --><p class=\"has-text-align-center\">Члены клуба получают доступ к эксклюзивным выставкам и продажам. Оплата членства ежегодно, 99.99$</p><!-- /wp:paragraph --><!-- wp:button {\"align\":\"center\"} --><div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Вступайте в клуб</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div></div><!-- /wp:group --><!-- wp:gallery {\"ids\":[39,38],\"align\":\"wide\"} --><figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" alt=\"\" data-id=\"39\" data-full-url=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" data-link=\"assets/images/2020-square-2/\" class=\"wp-image-39\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" alt=\"\" data-id=\"38\" data-full-url=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" data-link=\"http://dimtepla.com/wp-content/themes/twentytwenty/assets/images/2020-square-1/\" class=\"wp-image-38\"/></figure></li></ul></figure><!-- /wp:gallery -->","UMoMA открывает двери","","auto-draft","closed","closed","","","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?page_id=6","0","page","","0");
INSERT INTO `wp_posts` VALUES("7","1","2019-12-17 17:45:15","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>Вы можете быть художником, который желает здесь представить себя и свои работы или представителем бизнеса с описанием миссии.</p>
<!-- /wp:paragraph -->","О нас","","auto-draft","closed","closed","","","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?page_id=7","0","page","","0");
INSERT INTO `wp_posts` VALUES("8","1","2019-12-17 17:45:15","0000-00-00 00:00:00","<!-- wp:paragraph -->
<p>Это страница с основной контактной информацией, такой как адрес и номер телефона. Вы также можете попробовать добавить форму контактов с помощью плагина.</p>
<!-- /wp:paragraph -->","Контакты","","auto-draft","closed","closed","","","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?page_id=8","0","page","","0");
INSERT INTO `wp_posts` VALUES("9","1","2019-12-17 17:45:15","0000-00-00 00:00:00","","Блог","","auto-draft","closed","closed","","","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?page_id=9","0","page","","0");
INSERT INTO `wp_posts` VALUES("10","1","2019-12-17 17:45:15","0000-00-00 00:00:00","{
    \"widget_text[2]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjEzOiLQniDRgdCw0LnRgtC1IjtzOjQ6InRleHQiO3M6MjA1OiLQl9C00LXRgdGMINC80L7QttC10YIg0LHRi9GC0Ywg0L7RgtC70LjRh9C90L7QtSDQvNC10YHRgtC+INC00LvRjyDRgtC+0LPQviwg0YfRgtC+0LHRiyDQv9GA0LXQtNGB0YLQsNCy0LjRgtGMINGB0LXQsdGPLCDRgdCy0L7QuSDRgdCw0LnRgiDQuNC70Lgg0LLRi9GA0LDQt9C40YLRjCDQutCw0LrQuNC1LdGC0L4g0LHQu9Cw0LPQvtC00LDRgNC90L7RgdGC0LguIjtzOjY6ImZpbHRlciI7YjoxO3M6NjoidmlzdWFsIjtiOjE7fQ==\",
            \"title\": \"\\u041e \\u0441\\u0430\\u0439\\u0442\\u0435\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"9aa4d69563abc94184db46e178a1d195\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"sidebars_widgets[sidebar-1]\": {
        \"starter_content\": true,
        \"value\": [
            \"text-2\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"widget_text[3]\": {
        \"starter_content\": true,
        \"value\": {
            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjIxOiLQndCw0LnQtNC40YLQtSDQvdCw0YEiO3M6NDoidGV4dCI7czoyMjY6IjxzdHJvbmc+0JDQtNGA0LXRgTwvc3Ryb25nPgoxMjMg0JzQtdC50L0g0YHRgtGA0LjRggrQndGM0Y4g0JnQvtGA0LosIE5ZIDEwMDAxCgo8c3Ryb25nPtCn0LDRgdGLPC9zdHJvbmc+CtCf0L7QvdC10LTQtdC70YzQvdC40LombWRhc2g70L/Rj9GC0L3QuNGG0LA6IDk6MDAmbmRhc2g7MTc6MDAK0KHRg9Cx0LHQvtGC0LAg0Lgg0LLQvtGB0LrRgNC10YHQtdC90YzQtTogMTE6MDAmbmRhc2g7MTU6MDAiO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",
            \"title\": \"\\u041d\\u0430\\u0439\\u0434\\u0438\\u0442\\u0435 \\u043d\\u0430\\u0441\",
            \"is_widget_customizer_js_value\": true,
            \"instance_hash_key\": \"2f825142a9e19881f5486c4e310fe772\"
        },
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"sidebars_widgets[sidebar-2]\": {
        \"starter_content\": true,
        \"value\": [
            \"text-3\"
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menus_created_posts\": {
        \"starter_content\": true,
        \"value\": [
            5,
            6,
            7,
            8,
            9
        ],
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-1]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\",
            \"url\": \"http://dimtepla.com/\",
            \"position\": 0,
            \"nav_menu_term_id\": -1,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-2]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 7,
            \"position\": 1,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u041e \\u043d\\u0430\\u0441\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-3]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 9,
            \"position\": 2,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u0411\\u043b\\u043e\\u0433\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-4]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 8,
            \"position\": 3,
            \"nav_menu_term_id\": -1,
            \"title\": \"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"twentytwenty::nav_menu_locations[primary]\": {
        \"starter_content\": true,
        \"value\": -1,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u041e\\u0441\\u043d\\u043e\\u0432\\u043d\\u043e\\u0435\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-5]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"custom\",
            \"title\": \"\\u0413\\u043b\\u0430\\u0432\\u043d\\u0430\\u044f \\u0441\\u0442\\u0440\\u0430\\u043d\\u0438\\u0446\\u0430\",
            \"url\": \"http://dimtepla.com/\",
            \"position\": 0,
            \"nav_menu_term_id\": -5,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-6]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 7,
            \"position\": 1,
            \"nav_menu_term_id\": -5,
            \"title\": \"\\u041e \\u043d\\u0430\\u0441\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-7]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 9,
            \"position\": 2,
            \"nav_menu_term_id\": -5,
            \"title\": \"\\u0411\\u043b\\u043e\\u0433\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-8]\": {
        \"starter_content\": true,
        \"value\": {
            \"type\": \"post_type\",
            \"object\": \"page\",
            \"object_id\": 8,
            \"position\": 3,
            \"nav_menu_term_id\": -5,
            \"title\": \"\\u041a\\u043e\\u043d\\u0442\\u0430\\u043a\\u0442\\u044b\"
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"twentytwenty::nav_menu_locations[expanded]\": {
        \"starter_content\": true,
        \"value\": -5,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu[-9]\": {
        \"starter_content\": true,
        \"value\": {
            \"name\": \"\\u041c\\u0435\\u043d\\u044e \\u0441\\u043e\\u0446\\u0438\\u0430\\u043b\\u044c\\u043d\\u044b\\u0445 \\u0441\\u0441\\u044b\\u043b\\u043e\\u043a\"
        },
        \"type\": \"nav_menu\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-9]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Yelp\",
            \"url\": \"https://www.yelp.com\",
            \"position\": 0,
            \"nav_menu_term_id\": -9,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-10]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Facebook\",
            \"url\": \"https://www.facebook.com/wordpress\",
            \"position\": 1,
            \"nav_menu_term_id\": -9,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-11]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Twitter\",
            \"url\": \"https://twitter.com/wordpress\",
            \"position\": 2,
            \"nav_menu_term_id\": -9,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-12]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"Instagram\",
            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",
            \"position\": 3,
            \"nav_menu_term_id\": -9,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"nav_menu_item[-13]\": {
        \"starter_content\": true,
        \"value\": {
            \"title\": \"E-mail\",
            \"url\": \"mailto:wordpress@example.com\",
            \"position\": 4,
            \"nav_menu_term_id\": -9,
            \"object_id\": 0
        },
        \"type\": \"nav_menu_item\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"twentytwenty::nav_menu_locations[social]\": {
        \"starter_content\": true,
        \"value\": -9,
        \"type\": \"theme_mod\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"show_on_front\": {
        \"starter_content\": true,
        \"value\": \"page\",
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"page_on_front\": {
        \"starter_content\": true,
        \"value\": 6,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    },
    \"page_for_posts\": {
        \"starter_content\": true,
        \"value\": 9,
        \"type\": \"option\",
        \"user_id\": 1,
        \"date_modified_gmt\": \"2019-12-17 14:45:15\"
    }
}","","","auto-draft","closed","closed","","7db81598-e10c-429b-bd52-12500997e739","","","2019-12-17 17:45:15","0000-00-00 00:00:00","","0","http://dimtepla.com/?p=10","0","customize_changeset","","0");
INSERT INTO `wp_posts` VALUES("11","1","2019-12-17 18:21:23","2019-12-17 15:21:23","","woocommerce-placeholder","","inherit","open","closed","","woocommerce-placeholder","","","2019-12-17 18:21:23","2019-12-17 15:21:23","","0","http://dimtepla.com/wp-content/uploads/2019/12/woocommerce-placeholder.png","0","attachment","image/png","0");
INSERT INTO `wp_posts` VALUES("12","1","2019-12-17 18:22:30","2019-12-17 15:22:30","","Магазин","","publish","closed","closed","","shop","","","2019-12-17 18:22:30","2019-12-17 15:22:30","","0","http://dimtepla.com/shop/","0","page","","0");
INSERT INTO `wp_posts` VALUES("13","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->","Корзина","","publish","closed","closed","","cart","","","2019-12-17 18:22:30","2019-12-17 15:22:30","","0","http://dimtepla.com/cart/","0","page","","0");
INSERT INTO `wp_posts` VALUES("14","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->","Оформление заказа","","publish","closed","closed","","checkout","","","2019-12-17 18:22:30","2019-12-17 15:22:30","","0","http://dimtepla.com/checkout/","0","page","","0");
INSERT INTO `wp_posts` VALUES("15","1","2019-12-17 18:22:30","2019-12-17 15:22:30","<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->","Мой аккаунт","","publish","closed","closed","","my-account","","","2019-12-17 18:22:30","2019-12-17 15:22:30","","0","http://dimtepla.com/my-account/","0","page","","0");


DROP TABLE IF EXISTS `wp_term_relationships`;

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_relationships` VALUES("1","1","0");


DROP TABLE IF EXISTS `wp_term_taxonomy`;

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `wp_term_taxonomy` VALUES("2","2","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("3","3","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("4","4","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("5","5","product_type","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("6","6","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("7","7","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("8","8","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("9","9","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("10","10","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("11","11","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("12","12","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("13","13","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("14","14","product_visibility","","0","0");
INSERT INTO `wp_term_taxonomy` VALUES("15","15","product_cat","","0","0");


DROP TABLE IF EXISTS `wp_termmeta`;

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_terms`;

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_terms` VALUES("1","Без рубрики","%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8","0");
INSERT INTO `wp_terms` VALUES("2","simple","simple","0");
INSERT INTO `wp_terms` VALUES("3","grouped","grouped","0");
INSERT INTO `wp_terms` VALUES("4","variable","variable","0");
INSERT INTO `wp_terms` VALUES("5","external","external","0");
INSERT INTO `wp_terms` VALUES("6","exclude-from-search","exclude-from-search","0");
INSERT INTO `wp_terms` VALUES("7","exclude-from-catalog","exclude-from-catalog","0");
INSERT INTO `wp_terms` VALUES("8","featured","featured","0");
INSERT INTO `wp_terms` VALUES("9","outofstock","outofstock","0");
INSERT INTO `wp_terms` VALUES("10","rated-1","rated-1","0");
INSERT INTO `wp_terms` VALUES("11","rated-2","rated-2","0");
INSERT INTO `wp_terms` VALUES("12","rated-3","rated-3","0");
INSERT INTO `wp_terms` VALUES("13","rated-4","rated-4","0");
INSERT INTO `wp_terms` VALUES("14","rated-5","rated-5","0");
INSERT INTO `wp_terms` VALUES("15","Uncategorized","uncategorized","0");


DROP TABLE IF EXISTS `wp_usermeta`;

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_usermeta` VALUES("1","1","nickname","admin");
INSERT INTO `wp_usermeta` VALUES("2","1","first_name","");
INSERT INTO `wp_usermeta` VALUES("3","1","last_name","");
INSERT INTO `wp_usermeta` VALUES("4","1","description","");
INSERT INTO `wp_usermeta` VALUES("5","1","rich_editing","true");
INSERT INTO `wp_usermeta` VALUES("6","1","syntax_highlighting","true");
INSERT INTO `wp_usermeta` VALUES("7","1","comment_shortcuts","false");
INSERT INTO `wp_usermeta` VALUES("8","1","admin_color","fresh");
INSERT INTO `wp_usermeta` VALUES("9","1","use_ssl","0");
INSERT INTO `wp_usermeta` VALUES("10","1","show_admin_bar_front","true");
INSERT INTO `wp_usermeta` VALUES("11","1","locale","");
INSERT INTO `wp_usermeta` VALUES("12","1","wp_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `wp_usermeta` VALUES("13","1","wp_user_level","10");
INSERT INTO `wp_usermeta` VALUES("14","1","dismissed_wp_pointers","");
INSERT INTO `wp_usermeta` VALUES("15","1","show_welcome_panel","1");
INSERT INTO `wp_usermeta` VALUES("16","1","session_tokens","a:1:{s:64:\"0fd3baaf35fb986474753b8916b0301af8b8544899fab653ded43074f02e4b5c\";a:4:{s:10:\"expiration\";i:1577803296;s:2:\"ip\";s:9:\"127.0.0.1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36 OPR/65.0.3467.48\";s:5:\"login\";i:1576593696;}}");
INSERT INTO `wp_usermeta` VALUES("17","1","wp_dashboard_quick_press_last_post_id","4");
INSERT INTO `wp_usermeta` VALUES("18","1","community-events-location","a:1:{s:2:\"ip\";s:9:\"127.0.0.0\";}");
INSERT INTO `wp_usermeta` VALUES("19","1","wp_yoast_notifications","a:1:{i:0;a:2:{s:7:\"message\";s:578:\"Yoast SEO и WooCommerce могут работать лучше, если вы добавите вспомогательный плагин. Пожалуйста, установите Yoast WooCommerce SEO, чтобы сделать вашу жизнь проще. <a href=\"https://yoa.st/1o0?php_version=7.2&platform=wordpress&platform_version=5.3.1&software=free&software_version=12.7.1&days_active=0-1&user_language=ru_RU\" aria-label=\"Больше информации о Yoast WooCommerce SEO\" target=\"_blank\" rel=\"noopener noreferrer\">Больше информации</a>.\";s:7:\"options\";a:9:{s:4:\"type\";s:7:\"warning\";s:2:\"id\";s:44:\"wpseo-suggested-plugin-yoast-woocommerce-seo\";s:5:\"nonce\";N;s:8:\"priority\";d:0.5;s:9:\"data_json\";a:0:{}s:13:\"dismissal_key\";N;s:12:\"capabilities\";a:1:{i:0;s:15:\"install_plugins\";}s:16:\"capability_check\";s:3:\"all\";s:14:\"yoast_branding\";b:0;}}}");
INSERT INTO `wp_usermeta` VALUES("20","1","_woocommerce_tracks_anon_id","woo:GD4DqZd0Zogjo6aeYzWUSkrL");
INSERT INTO `wp_usermeta` VALUES("21","1","dismissed_install_notice","1");
INSERT INTO `wp_usermeta` VALUES("22","1","dismissed_wc_admin_notice","1");


DROP TABLE IF EXISTS `wp_users`;

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_users` VALUES("1","admin","$P$BWOwp7wQtu0iLmPLcElx11z122FPmS.","admin","Email@mail.com","","2019-12-17 14:41:23","","0","admin");


DROP TABLE IF EXISTS `wp_wc_download_log`;

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`),
  CONSTRAINT `fk_wp_wc_download_log_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `wp_woocommerce_downloadable_product_permissions` (`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(10,2) DEFAULT NULL,
  `max_price` decimal(10,2) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_wc_tax_rate_classes` VALUES("1","Пониженная ставка","%d0%bf%d0%be%d0%bd%d0%b8%d0%b6%d0%b5%d0%bd%d0%bd%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");
INSERT INTO `wp_wc_tax_rate_classes` VALUES("2","Нулевая ставка","%d0%bd%d1%83%d0%bb%d0%b5%d0%b2%d0%b0%d1%8f-%d1%81%d1%82%d0%b0%d0%b2%d0%ba%d0%b0");


DROP TABLE IF EXISTS `wp_wc_webhooks`;

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_log`;

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_order_items`;

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_sessions`;

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_woocommerce_sessions` VALUES("1","1","a:7:{s:4:\"cart\";s:6:\"a:0:{}\";s:11:\"cart_totals\";s:367:\"a:15:{s:8:\"subtotal\";i:0;s:12:\"subtotal_tax\";i:0;s:14:\"shipping_total\";i:0;s:12:\"shipping_tax\";i:0;s:14:\"shipping_taxes\";a:0:{}s:14:\"discount_total\";i:0;s:12:\"discount_tax\";i:0;s:19:\"cart_contents_total\";i:0;s:17:\"cart_contents_tax\";i:0;s:19:\"cart_contents_taxes\";a:0:{}s:9:\"fee_total\";i:0;s:7:\"fee_tax\";i:0;s:9:\"fee_taxes\";a:0:{}s:5:\"total\";i:0;s:9:\"total_tax\";i:0;}\";s:15:\"applied_coupons\";s:6:\"a:0:{}\";s:22:\"coupon_discount_totals\";s:6:\"a:0:{}\";s:26:\"coupon_discount_tax_totals\";s:6:\"a:0:{}\";s:21:\"removed_cart_contents\";s:6:\"a:0:{}\";s:8:\"customer\";s:702:\"a:26:{s:2:\"id\";s:1:\"1\";s:13:\"date_modified\";s:0:\"\";s:8:\"postcode\";s:0:\"\";s:4:\"city\";s:0:\"\";s:9:\"address_1\";s:0:\"\";s:7:\"address\";s:0:\"\";s:9:\"address_2\";s:0:\"\";s:5:\"state\";s:0:\"\";s:7:\"country\";s:2:\"UA\";s:17:\"shipping_postcode\";s:0:\"\";s:13:\"shipping_city\";s:0:\"\";s:18:\"shipping_address_1\";s:0:\"\";s:16:\"shipping_address\";s:0:\"\";s:18:\"shipping_address_2\";s:0:\"\";s:14:\"shipping_state\";s:0:\"\";s:16:\"shipping_country\";s:2:\"UA\";s:13:\"is_vat_exempt\";s:0:\"\";s:19:\"calculated_shipping\";s:0:\"\";s:10:\"first_name\";s:0:\"\";s:9:\"last_name\";s:0:\"\";s:7:\"company\";s:0:\"\";s:5:\"phone\";s:0:\"\";s:5:\"email\";s:14:\"Email@mail.com\";s:19:\"shipping_first_name\";s:0:\"\";s:18:\"shipping_last_name\";s:0:\"\";s:16:\"shipping_company\";s:0:\"\";}\";}","1576769039");


DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_links`;

CREATE TABLE `wp_yoast_seo_links` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL,
  `target_post_id` bigint(20) unsigned NOT NULL,
  `type` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `link_direction` (`post_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;



DROP TABLE IF EXISTS `wp_yoast_seo_meta`;

CREATE TABLE `wp_yoast_seo_meta` (
  `object_id` bigint(20) unsigned NOT NULL,
  `internal_link_count` int(10) unsigned DEFAULT NULL,
  `incoming_link_count` int(10) unsigned DEFAULT NULL,
  UNIQUE KEY `object_id` (`object_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

INSERT INTO `wp_yoast_seo_meta` VALUES("12","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("13","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("14","0","0");
INSERT INTO `wp_yoast_seo_meta` VALUES("15","0","0");


